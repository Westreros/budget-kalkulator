import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Increase payload limit for receipt photos (up to 10MB)
  app.use(express.json({ limit: '10mb' }));

  // Server-side AI Receipt Scanner (OCR + Automatic 50/30/20 Categorization)
  app.post('/api/scan-receipt', async (req, res) => {
    try {
      const { base64Image, mimeType, receiptText, availableCategories } = req.body;

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
        // Fallback deterministic parser if API key is not configured
        return res.json({
          storeName: 'Biedronka (Tryb Demo OCR)',
          date: new Date().toISOString().split('T')[0],
          items: [
            { name: 'Chleb żytni, Mleko, Warzywa, Pierś z kurczaka', amount: 86.4, bucket: 'needs', suggestedCategory: 'Jedzenie & Supermarket' },
            { name: 'Chemia domowa i płyn do naczyń', amount: 24.9, bucket: 'needs', suggestedCategory: 'Jedzenie & Supermarket' },
            { name: 'Chipsy, Czekolada, Napoje gazowane, Piwo', amount: 42.5, bucket: 'fun', suggestedCategory: 'Kawiarnie & Restauracje' }
          ],
          needsTotal: 111.3,
          funTotal: 42.5,
          grandTotal: 153.8
        });
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });

      const catListStr = Array.isArray(availableCategories) && availableCategories.length > 0
        ? availableCategories.join(', ')
        : 'Jedzenie & Supermarket, Mieszkanie & Czynsz, Transport & Paliwo, Zdrowie & Leki, Kawiarnie & Restauracje, Rozrywka & Kino, Zakupy & Ubrania';

      const prompt = `Przeanalizuj ten polski paragon fiskalny.
Twoim zadaniem jest:
1. Odczytać nazwę sklepu (np. Biedronka, Lidl, Żabka, Orlen, Rossmann) oraz datę zakupu (format YYYY-MM-DD).
2. Rozbić pozycje z paragonu na grupy według reguły budżetowej 50/30/20:
   - "needs" (Potrzeby): podstawowe jedzenie (pieczywo, nabiał, mięso, warzywa, owoce, woda, artykuły sypkie), chemia gospodarcza, kosmetyki podstawowe, leki, paliwo.
   - "fun" (Zachcianki): słodycze, chipsy, słone przekąski, alkohol, piwo, słodkie napoje gazowane, energetyki, używki, zabawki, zachcianki.
3. Dopasować każdą grupę do jednej z dostępnych kategorii użytkownika: [${catListStr}].
4. Zwrócić zagregowane pozycje (maksymalnie 2-4 czytelne grupy z sumami częściowymi, aby nie zaśmiecać dziennika 30 pojedynczymi bułkami).`;

      const parts: any[] = [];
      if (base64Image && mimeType) {
        parts.push({
          inlineData: {
            data: base64Image,
            mimeType
          }
        });
      }
      if (receiptText) {
        parts.push({ text: `Tekst paragonu:\n${receiptText}` });
      }
      parts.push({ text: prompt });

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: { parts },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              storeName: {
                type: Type.STRING,
                description: 'Nazwa sklepu z paragonu, np. Biedronka, Lidl'
              },
              date: {
                type: Type.STRING,
                description: 'Data zakupu w formacie YYYY-MM-DD'
              },
              items: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: {
                      type: Type.STRING,
                      description: 'Krótki opis grupy produktów (np. Podstawowe artykuły spożywcze / Słodycze i przekąski)'
                    },
                    amount: {
                      type: Type.NUMBER,
                      description: 'Suma częściowa w PLN'
                    },
                    bucket: {
                      type: Type.STRING,
                      description: 'needs lub fun'
                    },
                    suggestedCategory: {
                      type: Type.STRING,
                      description: 'Dopasowana nazwa kategorii użytkownika'
                    }
                  },
                  required: ['name', 'amount', 'bucket', 'suggestedCategory']
                }
              },
              needsTotal: { type: Type.NUMBER },
              funTotal: { type: Type.NUMBER },
              grandTotal: { type: Type.NUMBER }
            },
            required: ['storeName', 'date', 'items', 'needsTotal', 'funTotal', 'grandTotal']
          }
        }
      });

      const rawJson = response.text?.trim() || '{}';
      const parsed = JSON.parse(rawJson);
      return res.json(parsed);
    } catch (error: any) {
      console.error('Receipt scan error:', error);
      return res.status(500).json({
        error: error?.message || 'Nie udało się przeanalizować paragonu.'
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`WiseWallet Pro Server running on http://localhost:${PORT}`);
  });
}

startServer();

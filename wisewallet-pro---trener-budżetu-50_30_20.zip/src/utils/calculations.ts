import {
  BudgetConfig,
  BudgetDistribution,
  Subscription,
  SinkingFundSummary,
  HistoryEntry,
  Category,
  HealthAudit,
  HealthAuditIssue
} from '../types/budget';

export const POLISH_MONTHS = [
  'Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec',
  'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'
];

export function calculateTotalIncome(config: BudgetConfig): number {
  const baseSalary = Math.max(0, Number(config.income) || 0);
  const partnerSalary = config.household?.enabled
    ? Math.max(0, Number(config.household.partnerNetIncome) || 0)
    : 0;
  const b800 = Math.max(0, Number(config.benefits800) || 0) * 800;
  const bHome = Math.max(0, Number(config.benefitsActiveHome) || 0) * 500;
  const bWork = Math.max(0, Number(config.benefitsActiveWork) || 0) * 1500;
  const other = Math.max(0, Number(config.otherIncome) || 0);
  return baseSalary + partnerSalary + b800 + bHome + bWork + other;
}

export function calculateBudgetDistribution(config: BudgetConfig): BudgetDistribution {
  const totalIncome = calculateTotalIncome(config);
  const baseSalary = Math.max(0, Number(config.income) || 0);
  const partnerSalary = config.household?.enabled
    ? Math.max(0, Number(config.household.partnerNetIncome) || 0)
    : 0;
  const benefitsTotal =
    totalIncome - baseSalary - partnerSalary - (Math.max(0, Number(config.otherIncome) || 0));

  let needsPct = 50;
  let savingsPct = 30;
  let funPct = 20;

  if (config.customRatiosEnabled && config.isPremium) {
    needsPct = config.customNeedsPct;
    savingsPct = config.customSavingsPct;
    funPct = config.customFunPct;
  } else if (config.rushEmergencyFund) {
    // Szybka poduszka - agresywne oszczędzanie (50% potrzeby, 40% oszczędności, 10% zachcianki)
    needsPct = 50;
    savingsPct = 40;
    funPct = 10;
  }

  const needsTarget = Math.round(totalIncome * (needsPct / 100));
  const funTarget = Math.round(totalIncome * (funPct / 100));
  const savingsTarget = Math.max(0, totalIncome - needsTarget - funTarget);

  // Sub-podział kosztów życia
  const housingTarget = Math.round(totalIncome * 0.30);
  const foodTarget = Math.round(totalIncome * 0.15);
  const transportTarget = Math.round(totalIncome * 0.05);
  const loansTarget = Math.max(0, needsTarget - housingTarget - foodTarget - transportTarget);

  const emergencyFundTarget = needsTarget * (config.emergencyFundMonths || 6);

  return {
    totalIncome,
    baseSalary,
    partnerSalary,
    benefitsTotal,
    needsTarget,
    needsPct,
    funTarget,
    funPct,
    savingsTarget,
    savingsPct,
    housingTarget,
    foodTarget,
    transportTarget,
    loansTarget,
    emergencyFundTarget
  };
}

export function getCycleMonthsCount(cycle: Subscription['cycle']): number {
  switch (cycle) {
    case 'annual': return 12;
    case 'semi_annual': return 6;
    case 'quarterly': return 3;
    default: return 1;
  }
}

export function getCycleLabelPL(cycle: Subscription['cycle']): string {
  switch (cycle) {
    case 'annual': return 'Rocznie';
    case 'semi_annual': return 'Półrocznie';
    case 'quarterly': return 'Kwartalnie';
    default: return 'Miesięcznie';
  }
}

export function isSubDueInMonth(sub: Subscription, monthNum: number): boolean {
  if (sub.cycle === 'monthly') return true;
  const dueM = Math.max(1, Math.min(12, Number(sub.dueMonth) || 1));
  const m = Math.max(1, Math.min(12, Number(monthNum)));
  const step = getCycleMonthsCount(sub.cycle);
  return ((m - dueM) % step + step) % step === 0;
}

export function getSubNextDueInfo(
  sub: Subscription,
  refYear: number,
  refMonth: number
): { monthsInclusive: number; dueMonth: number; dueYear: number } {
  if (sub.cycle === 'monthly') {
    return { monthsInclusive: 1, dueMonth: refMonth, dueYear: refYear };
  }

  for (let offset = 0; offset < 12; offset++) {
    const rawM = refMonth - 1 + offset;
    const m = (rawM % 12) + 1;
    const y = refYear + Math.floor(rawM / 12);
    if (isSubDueInMonth(sub, m)) {
      return { monthsInclusive: offset + 1, dueMonth: m, dueYear: y };
    }
  }

  return { monthsInclusive: 12, dueMonth: Number(sub.dueMonth) || 1, dueYear: refYear };
}

export function calculateSinkingFundAllocation(
  sub: Subscription,
  refYear: number,
  refMonth: number
): SinkingFundSummary {
  const amt = Number(sub.amount) || 0;
  const step = getCycleMonthsCount(sub.cycle);
  const standardMonthly = Math.round(amt / step);

  if (sub.cycle === 'monthly') {
    return {
      monthlyAllocation: amt,
      monthsUntilDue: 1,
      nextDueYear: refYear,
      nextDueMonth: refMonth,
      totalNeeded: amt,
      isDueThisMonth: true,
      standardMonthly: amt
    };
  }

  const isDueThisMonth = isSubDueInMonth(sub, refMonth);
  const curPeriod = `${refYear}-${String(refMonth).padStart(2, '0')}`;

  if (sub.lastPaidMonth === curPeriod || (sub.lastPaidMonth && sub.lastPaidMonth < curPeriod)) {
    const nextInfo = getSubNextDueInfo(sub, refYear, refMonth);
    return {
      monthlyAllocation: standardMonthly,
      monthsUntilDue: nextInfo.monthsInclusive,
      nextDueYear: nextInfo.dueYear,
      nextDueMonth: nextInfo.dueMonth,
      totalNeeded: amt,
      isDueThisMonth,
      standardMonthly
    };
  }

  const saved = Math.max(0, Number(sub.savedSoFar) || 0);
  const needed = Math.max(0, amt - saved);

  let startY = refYear;
  let startM = refMonth;
  if (sub.createdMonth) {
    const parts = sub.createdMonth.split('-');
    if (parts.length === 2) {
      startY = parseInt(parts[0], 10);
      startM = parseInt(parts[1], 10);
    }
  }

  const info = getSubNextDueInfo(sub, startY, startM);
  const allocation = Math.round(needed / Math.max(1, info.monthsInclusive));

  const currentNextInfo = getSubNextDueInfo(sub, refYear, refMonth);

  return {
    monthlyAllocation: Math.max(0, allocation),
    monthsUntilDue: currentNextInfo.monthsInclusive,
    nextDueYear: currentNextInfo.dueYear,
    nextDueMonth: currentNextInfo.dueMonth,
    totalNeeded: amt,
    isDueThisMonth,
    standardMonthly
  };
}

export function getPreviousMonthStr(year: number, month: number): string {
  const d = new Date(year, month - 2, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function calculateRollover(
  entries: HistoryEntry[],
  categories: Category[],
  config: BudgetConfig,
  currentYear: number,
  currentMonth: number
): number {
  const prevMonth = getPreviousMonthStr(currentYear, currentMonth);
  const prevLogs = entries.filter(e => e.month === prevMonth);
  if (prevLogs.length === 0) return 0;

  const distribution = calculateBudgetDistribution(config);
  const targetFun = distribution.funTarget;

  const categoryBucketMap = new Map<string, Category['bucket']>();
  categories.forEach(c => categoryBucketMap.set(c.name, c.bucket));

  let spentPrevFun = 0;
  prevLogs.forEach(e => {
    const b = categoryBucketMap.get(e.category) || 'needs';
    if (b === 'fun') {
      spentPrevFun += Number(e.amount) || 0;
    }
  });

  return Math.max(0, targetFun - spentPrevFun);
}

export function calculateNoSpendStreak(
  entries: HistoryEntry[],
  categories: Category[],
  currentYear: number,
  currentMonth: number,
  todayDay: number
): { streak: number; streakQuality: 'zero' | 'bronze' | 'silver' | 'gold' | 'flame' } {
  const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
  const categoryBucketMap = new Map<string, Category['bucket']>();
  categories.forEach(c => categoryBucketMap.set(c.name, c.bucket));

  const funDays = new Set<number>();
  let hasAnyLogs = false;
  let firstLogDay = todayDay;

  entries.forEach(e => {
    if (e.month === curPeriod) {
      hasAnyLogs = true;
      const bucket = categoryBucketMap.get(e.category) || 'needs';
      if (e.exactDate) {
        const parts = e.exactDate.split('-');
        if (parts.length === 3) {
          const dayNum = parseInt(parts[2], 10);
          if (!isNaN(dayNum)) {
            if (dayNum < firstLogDay) firstLogDay = dayNum;
            if (bucket === 'fun') {
              funDays.add(dayNum);
            }
          }
        }
      }
    }
  });

  if (!hasAnyLogs) {
    return { streak: 0, streakQuality: 'zero' };
  }

  let streak = 0;
  for (let day = todayDay; day >= firstLogDay; day--) {
    if (funDays.has(day)) {
      break;
    }
    streak++;
  }

  let streakQuality: 'zero' | 'bronze' | 'silver' | 'gold' | 'flame' = 'zero';
  if (streak >= 14) streakQuality = 'flame';
  else if (streak >= 7) streakQuality = 'gold';
  else if (streak >= 3) streakQuality = 'silver';
  else if (streak >= 1) streakQuality = 'bronze';

  return { streak, streakQuality };
}

export function calculateSavingsStreak(
  entries: HistoryEntry[],
  categories: Category[],
  config: BudgetConfig
): number {
  const distribution = calculateBudgetDistribution(config);
  const idealSavings = distribution.savingsTarget;
  if (idealSavings <= 0 || entries.length === 0) return 0;

  const categoryBucketMap = new Map<string, Category['bucket']>();
  categories.forEach(c => categoryBucketMap.set(c.name, c.bucket));

  const periodMap = new Map<string, number>();
  entries.forEach(e => {
    const bucket = categoryBucketMap.get(e.category);
    if (bucket === 'savings') {
      periodMap.set(e.month, (periodMap.get(e.month) || 0) + Number(e.amount));
    }
  });

  const sortedPeriods = Array.from(periodMap.keys()).sort().reverse();
  let streak = 0;
  for (const period of sortedPeriods) {
    if ((periodMap.get(period) || 0) >= idealSavings) {
      streak++;
    } else {
      break;
    }
  }

  return streak;
}

export function auditBudgetHealth(
  config: BudgetConfig,
  entries: HistoryEntry[],
  subscriptions: Subscription[],
  categories: Category[],
  currentYear: number,
  currentMonth: number
): HealthAudit {
  const distribution = calculateBudgetDistribution(config);
  const totalIncome = distribution.totalIncome;

  const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
  const categoryBucketMap = new Map<string, Category['bucket']>();
  categories.forEach(c => categoryBucketMap.set(c.name, c.bucket));

  let actualNeeds = 0;
  let actualFun = 0;
  let actualSavings = 0;

  entries.filter(e => e.month === curPeriod).forEach(e => {
    const b = categoryBucketMap.get(e.category) || 'needs';
    if (b === 'needs') actualNeeds += Number(e.amount) || 0;
    else if (b === 'fun') actualFun += Number(e.amount) || 0;
    else if (b === 'savings') actualSavings += Number(e.amount) || 0;
  });

  let totalMonthlySubscriptions = 0;
  let irregularSubCount = 0;
  subscriptions.forEach(sub => {
    const alloc = calculateSinkingFundAllocation(sub, currentYear, currentMonth);
    totalMonthlySubscriptions += alloc.monthlyAllocation;
    if (sub.cycle !== 'monthly') irregularSubCount++;
  });

  const actualNeedsRatio = totalIncome > 0 ? (actualNeeds / totalIncome) * 100 : 0;
  const actualFunRatio = totalIncome > 0 ? (actualFun / totalIncome) * 100 : 0;
  const actualSavingsRatio = totalIncome > 0 ? (actualSavings / totalIncome) * 100 : 0;
  const subscriptionBurdenRatio = totalIncome > 0 ? (totalMonthlySubscriptions / totalIncome) * 100 : 0;

  const currentSavings = Number(config.currentSavings) || 0;
  const survivalMonthly = distribution.needsTarget;
  const emergencyFundCoverMonths = survivalMonthly > 0 ? currentSavings / survivalMonthly : 0;

  let score = 100;
  const issues: HealthAuditIssue[] = [];

  // Check 1: Poduszka finansowa
  if (emergencyFundCoverMonths < 1) {
    score -= 25;
    issues.push({
      id: 'emergency-critical',
      type: 'critical',
      title: 'Krytyczny brak poduszki bezpieczeństwa',
      message: `Twoja obecna poduszka pokrywa tylko ${(emergencyFundCoverMonths * 30).toFixed(0)} dni kosztów życia. Przy utracie dochodu grozi natychmiastowy dług.`,
      actionRecommendation: 'Włącz „Tryb Szybkiej Poduszki” (40% na oszczędności, 10% na fun), dopóki nie uzbierasz minimum 3 miesięcy kosztów życia.'
    });
  } else if (emergencyFundCoverMonths < 3) {
    score -= 10;
    issues.push({
      id: 'emergency-warning',
      type: 'warning',
      title: 'Poduszka poniżej zalecanego minimum',
      message: `Posiadasz ${emergencyFundCoverMonths.toFixed(1)} mies. bufora. Rekomendacja ekspertów to minimum 3-6 miesięcy.`,
      actionRecommendation: 'Kontynuuj systematyczne wpłaty do Skarbonki Poduszki Finansowej.'
    });
  } else {
    issues.push({
      id: 'emergency-praise',
      type: 'praise',
      title: 'Solidna poduszka finansowa',
      message: `Zabezpieczone ${emergencyFundCoverMonths.toFixed(1)} miesięcy przetrwania! Twój spokój psychiczny jest chroniony.`
    });
  }

  // Check 2: Obciążenie stałymi opłatami
  if (subscriptionBurdenRatio > 35) {
    score -= 20;
    issues.push({
      id: 'sub-high',
      type: 'critical',
      title: 'Wysokie stałe obciążenie (Subskrypcyjna inflacja)',
      message: `Aż ${subscriptionBurdenRatio.toFixed(1)}% Twoich zarobków pochłaniają stałe abonamenty i opłaty cykliczne (${totalMonthlySubscriptions.toLocaleString('pl-PL')} zł/mc).`,
      actionRecommendation: 'Zrób audyt subskrypcji: anuluj nieużywane platformy VOD, zoptymalizuj pakiety telco/ubezpieczenia.'
    });
  } else if (subscriptionBurdenRatio > 20) {
    score -= 8;
    issues.push({
      id: 'sub-medium',
      type: 'tip',
      title: 'Zauważalne stałe opłaty',
      message: `Stałe opłaty pochłaniają ${subscriptionBurdenRatio.toFixed(1)}% dochodu. Warto raz na pół roku renegocjować umowy.`
    });
  }

  // Check 3: Sinking funds
  if (subscriptions.length > 0 && irregularSubCount === 0) {
    issues.push({
      id: 'sinking-tip',
      type: 'tip',
      title: 'Dodaj opłaty roczne (OC, ubezpieczenia, podatki)',
      message: 'Nie dodałeś żadnych opłat kwartalnych ani rocznych. Ich nagłe pojawienie się często rozbija miesięczny budżet!',
      actionRecommendation: 'Skorzystaj z kalkulatora Sinking Funds w zakładce Opłaty, by rozłożyć OC lub święta na 12 rat.'
    });
  }

  // Check 4: Przekroczenie potrzeb
  if (actualNeedsRatio > 65) {
    score -= 20;
    issues.push({
      id: 'needs-overload',
      type: 'critical',
      title: 'Koszty życia zjadają ponad 65% dochodu',
      message: `Brak elastyczności. Jeśli koszty bazowe są tak wysokie, każda niespodzianka powoduje dziurę w budżecie.`,
      actionRecommendation: 'Przeanalizuj koszty mieszkania, raty kredytowe i koszyk zakupowy (marki własne, planowanie posiłków).'
    });
  }

  // Check 5: Passa bez zbędnych wydatków
  const streakData = calculateNoSpendStreak(entries, categories, currentYear, currentMonth, 15);
  if (streakData.streak >= 5) {
    issues.push({
      id: 'streak-praise',
      type: 'praise',
      title: `Świetna samokontrola: ${streakData.streak} dni bez zachcianek!`,
      message: 'Unikanie impulsywnych mikro-wydatków przynosi rocznie tysiące złotych oszczędności.'
    });
  }

  score = Math.max(10, Math.min(100, score));

  let grade: HealthAudit['grade'] = 'A+';
  if (score >= 90) grade = 'A+';
  else if (score >= 80) grade = 'A';
  else if (score >= 65) grade = 'B';
  else if (score >= 50) grade = 'C';
  else grade = 'D';

  let summary = 'Twój budżet jest w doskonałej kondycji. Pilnujesz celów i nie dajesz się inflacji stylu życia.';
  if (grade === 'B') summary = 'Dobra kondycja, ale z kilkoma obszarami wymagającymi uszczelnienia portfela.';
  else if (grade === 'C') summary = 'Twój budżet jest napięty. Stałe koszty lub brak poduszki stwarzają ryzyko zadłużenia.';
  else if (grade === 'D') summary = 'Wymagana natychmiastowa rekonfiguracja nawyków i cięcie wydatków.';

  return {
    score,
    grade,
    summary,
    issues,
    metrics: {
      actualNeedsRatio,
      actualFunRatio,
      actualSavingsRatio,
      emergencyFundCoverMonths,
      subscriptionBurdenRatio
    }
  };
}

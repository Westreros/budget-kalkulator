import { Category } from '../types/budget';

export interface ParsedBankSms {
  amount: number | null;
  merchant: string;
  date: string; // YYYY-MM-DD
  suggestedCategory: string;
  confidence: 'high' | 'medium' | 'low';
}

export interface DebtItem {
  id: string;
  name: string;
  balance: number; // PLN
  interestRate: number; // Annual % e.g. 18.5
  minPayment: number; // Monthly minimum payment PLN
}

export interface DebtPayoffResult {
  strategy: 'snowball' | 'avalanche';
  monthsToPayoff: number;
  baselineMonths: number;
  monthsSaved: number;
  totalInterestPaid: number;
  baselineInterestPaid: number;
  interestSaved: number;
  totalPaid: number;
  payoffOrder: Array<{
    id: string;
    name: string;
    paidOffInMonth: number;
    interestPaid: number;
  }>;
}

export interface StreakDiscountInfo {
  basePriceMonthly: number;
  streakDays: number;
  discountPercent: number;
  finalPriceMonthly: number;
  savedPerMonth: number;
  freeMonthUnlocked: boolean;
}

const MERCHANT_CATEGORY_RULES: Array<{ keywords: string[]; category: string; cleanName?: string }> = [
  { keywords: ['biedronka', 'jmp'], category: 'Jedzenie & Supermarket', cleanName: 'Biedronka' },
  { keywords: ['lidl'], category: 'Jedzenie & Supermarket', cleanName: 'Lidl' },
  { keywords: ['zabka', 'żabka'], category: 'Jedzenie & Supermarket', cleanName: 'Żabka' },
  { keywords: ['auchan', 'carrefour', 'kaufland', 'dino', 'netto', 'stokrotka'], category: 'Jedzenie & Supermarket' },
  { keywords: ['orlen', 'bp ', 'shell', 'circle k', 'moya', 'amic', 'uber', 'bolt', 'jakdojade', 'pkp'], category: 'Transport & Paliwo' },
  { keywords: ['rossmann', 'hebe', 'aptek', 'doz', 'gemini', 'luxmed', 'medicover'], category: 'Zdrowie & Leki' },
  { keywords: ['mcdonald', 'kfc', 'starbucks', 'costa', 'pizza', 'restauracja', 'bistro', 'sushi', 'kebab', 'pyszne', 'glovo', 'wolt'], category: 'Kawiarnie & Restauracje' },
  { keywords: ['netflix', 'spotify', 'hbo', 'disney', 'canal+', 'cinema', 'helios', 'multikino', 'steam', 'playstation'], category: 'Rozrywka & Kino' },
  { keywords: ['allegro', 'amazon', 'zara', 'h&m', 'reserved', 'zalando', 'ikea', 'castorama', 'leroy', 'empik', 'media expert', 'rtv euro'], category: 'Zakupy & Ubrania' }
];

export function parseBankNotification(
  rawText: string,
  categories: Category[],
  fallbackDate?: string
): ParsedBankSms {
  const today = fallbackDate || new Date().toISOString().split('T')[0];
  const text = rawText.trim();
  if (!text) {
    return {
      amount: null,
      merchant: '',
      date: today,
      suggestedCategory: categories[0]?.name || 'Jedzenie & Supermarket',
      confidence: 'low'
    };
  }

  // 1. Extract amount (e.g. "142,50 PLN", "45.99 zl", "kwota: 89,00zł", "-120.50 PLN")
  const amountRegex = /(?:kwota[:\s]*|transakcja[:\s]*|płatność[:\s]*|obciążenie[:\s]*|-)?(\d{1,6}(?:[.,]\d{1,2})?)\s*(?:pln|zł|zl|eur|usd)/i;
  const fallbackAmountRegex = /(\d{1,5}[.,]\d{2})/;
  let amount: number | null = null;

  const amtMatch = text.match(amountRegex) || text.match(fallbackAmountRegex);
  if (amtMatch && amtMatch[1]) {
    const parsed = parseFloat(amtMatch[1].replace(',', '.'));
    if (!isNaN(parsed) && parsed > 0) {
      amount = parsed;
    }
  }

  // 2. Extract date (YYYY-MM-DD or DD.MM.YYYY or DD-MM-YYYY)
  let date = today;
  const isoMatch = text.match(/(\d{4})-(\d{2})-(\d{2})/);
  const plMatch = text.match(/(\d{2})[./-](\d{2})[./-](\d{4})/);
  if (isoMatch) {
    date = `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;
  } else if (plMatch) {
    date = `${plMatch[3]}-${plMatch[2]}-${plMatch[1]}`;
  }

  // 3. Extract merchant / store name
  let merchant = '';
  const merchantPatterns = [
    /(?:w|u|sklep|miejsce|odbiorca|punkt)[:\s]+([A-Za-z0-9ąćęłńóśźżĄĆĘŁŃÓŚŹŻ\s.*&-]{3,35}?)(?:\s+dnia|\s+data|\s+kwota|\s+dostępne|\.|,|$)/i,
    /(?:PLN|zł|zl)\s+(?:w\s+)?([A-Za-z0-9ąćęłńóśźżĄĆĘŁŃÓŚŹŻ\s.*&-]{3,30}?)(?:\s+dnia|\.|,|$)/i
  ];

  for (const pattern of merchantPatterns) {
    const m = text.match(pattern);
    if (m && m[1]) {
      merchant = m[1].trim();
      break;
    }
  }

  // Match against known Polish merchants
  const lowerText = text.toLowerCase();
  let suggestedCategory = categories[0]?.name || 'Jedzenie & Supermarket';
  let confidence: 'high' | 'medium' | 'low' = amount !== null ? 'medium' : 'low';

  for (const rule of MERCHANT_CATEGORY_RULES) {
    if (rule.keywords.some(k => lowerText.includes(k))) {
      const foundCat = categories.find(c => c.name === rule.category);
      if (foundCat) {
        suggestedCategory = foundCat.name;
      } else {
        suggestedCategory = rule.category;
      }
      if (rule.cleanName && !merchant) {
        merchant = rule.cleanName;
      }
      confidence = amount !== null ? 'high' : 'medium';
      break;
    }
  }

  if (!merchant) {
    merchant = 'Zakup z powiadomienia SMS';
  }

  return {
    amount,
    merchant,
    date,
    suggestedCategory,
    confidence
  };
}

function simulatePayoff(
  debts: DebtItem[],
  extraMonthlyPayment: number,
  strategy: 'snowball' | 'avalanche'
): {
  months: number;
  totalInterest: number;
  payoffOrder: Array<{ id: string; name: string; paidOffInMonth: number; interestPaid: number }>;
} {
  const activeDebts = debts
    .filter(d => d.balance > 0)
    .map(d => ({
      ...d,
      currentBalance: d.balance,
      interestAccumulated: 0,
      paidOffMonth: 0
    }));

  if (activeDebts.length === 0) {
    return { months: 0, totalInterest: 0, payoffOrder: [] };
  }

  let month = 0;
  const maxMonths = 360; // 30 years cap
  const payoffOrder: Array<{ id: string; name: string; paidOffInMonth: number; interestPaid: number }> = [];

  while (activeDebts.some(d => d.currentBalance > 0.01) && month < maxMonths) {
    month++;

    // Sort priority according to strategy
    activeDebts.sort((a, b) => {
      if (strategy === 'snowball') {
        return a.currentBalance - b.currentBalance;
      }
      return b.interestRate - a.interestRate;
    });

    // Step 1: Add monthly interest to each active debt
    for (const d of activeDebts) {
      if (d.currentBalance <= 0.01) continue;
      const monthlyInterest = d.currentBalance * (d.interestRate / 100 / 12);
      d.currentBalance += monthlyInterest;
      d.interestAccumulated += monthlyInterest;
    }

    // Step 2: Pay minimum payments on all active debts, accumulating freed-up minimums into snowball pool
    let extraPool = Math.max(0, extraMonthlyPayment);

    for (const d of activeDebts) {
      if (d.currentBalance <= 0.01) {
        // Freed minimum payment rolls into the extra pool!
        extraPool += d.minPayment;
        continue;
      }

      const payment = Math.min(d.currentBalance, d.minPayment);
      d.currentBalance -= payment;
      if (d.minPayment > payment) {
        extraPool += d.minPayment - payment;
      }

      if (d.currentBalance <= 0.01 && d.paidOffMonth === 0) {
        d.currentBalance = 0;
        d.paidOffMonth = month;
        payoffOrder.push({
          id: d.id,
          name: d.name,
          paidOffInMonth: month,
          interestPaid: Math.round(d.interestAccumulated)
        });
      }
    }

    // Step 3: Apply extraPool to highest-priority debt(s)
    for (const d of activeDebts) {
      if (d.currentBalance <= 0.01 || extraPool <= 0.01) continue;
      const payment = Math.min(d.currentBalance, extraPool);
      d.currentBalance -= payment;
      extraPool -= payment;

      if (d.currentBalance <= 0.01 && d.paidOffMonth === 0) {
        d.currentBalance = 0;
        d.paidOffMonth = month;
        payoffOrder.push({
          id: d.id,
          name: d.name,
          paidOffInMonth: month,
          interestPaid: Math.round(d.interestAccumulated)
        });
      }
    }
  }

  const totalInterest = Math.round(
    activeDebts.reduce((sum, d) => sum + d.interestAccumulated, 0)
  );

  return {
    months: month,
    totalInterest,
    payoffOrder
  };
}

export function calculateDebtPayoffPlan(
  debts: DebtItem[],
  extraMonthlyPayment: number,
  strategy: 'snowball' | 'avalanche'
): DebtPayoffResult {
  // Baseline without extra payment and without snowballing freed minimums
  const baseline = simulatePayoff(debts, 0, strategy);
  const optimized = simulatePayoff(debts, extraMonthlyPayment, strategy);

  const totalPrincipal = debts.reduce((acc, d) => acc + d.balance, 0);
  const monthsSaved = Math.max(0, baseline.months - optimized.months);
  const interestSaved = Math.max(0, baseline.totalInterest - optimized.totalInterest);

  return {
    strategy,
    monthsToPayoff: optimized.months,
    baselineMonths: baseline.months,
    monthsSaved,
    totalInterestPaid: optimized.totalInterest,
    baselineInterestPaid: baseline.totalInterest,
    interestSaved,
    totalPaid: Math.round(totalPrincipal + optimized.totalInterest),
    payoffOrder: optimized.payoffOrder
  };
}

export function calculateStreakDiscount(
  streakDays: number,
  savingsMonthsStreak: number = 0,
  basePriceMonthly: number = 29
): StreakDiscountInfo {
  // Every day of no-spend streak gives 2% discount up to 50% max
  const discountPercent = Math.min(50, Math.max(0, streakDays * 2));
  const finalPriceMonthly = Number((basePriceMonthly * (1 - discountPercent / 100)).toFixed(2));
  const savedPerMonth = Number((basePriceMonthly - finalPriceMonthly).toFixed(2));
  const freeMonthUnlocked = savingsMonthsStreak >= 6 || streakDays >= 25;

  return {
    basePriceMonthly,
    streakDays,
    discountPercent,
    finalPriceMonthly,
    savedPerMonth,
    freeMonthUnlocked
  };
}

import { HistoryEntry, Category, BudgetConfig } from '../types/budget';
import { calculateBudgetDistribution } from './calculations';

/**
 * Zaawansowane animacje dopaminowe (Złote Monety & Jackpot 30 monet)
 * Zachowane 1:1 z oryginalnego kodu WiseWallet
 */
export function triggerCoinDrop(containerId: string, amount: number, isJackpot: boolean = false): void {
  if (typeof document === 'undefined') return;
  const container = containerId === 'body' ? document.body : document.getElementById(containerId);
  if (!container) return;

  if (containerId !== 'body' && window.getComputedStyle(container).position === 'static') {
    container.style.position = 'relative';
  }

  const coinCount = isJackpot ? 30 : amount >= 500 ? 5 : amount >= 200 ? 3 : 1;

  for (let i = 0; i < coinCount; i++) {
    const coin = document.createElement('div');
    coin.innerHTML =
      '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#fcd34d" stroke="#d97706" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 18V6"/></svg>';

    if (isJackpot) {
      coin.className = 'coin-jackpot';
      const angle = Math.random() * 180 * (Math.PI / 180);
      const power = 80 + Math.random() * 150;
      coin.style.setProperty('--tx', `${Math.cos(angle) * power}px`);
      coin.style.setProperty('--ty', `${-Math.abs(Math.sin(angle) * power * 1.5)}px`);
      coin.style.setProperty('--rot', `${Math.random() * 720 - 360}deg`);
      coin.style.animationDelay = `${Math.random() * 0.3}s`;
    } else {
      coin.className = 'coin-drop';
      coin.style.right = `${10 + Math.random() * 40}px`;
      coin.style.animationDelay = `${i * 0.15}s`;
    }

    container.appendChild(coin);
    setTimeout(() => coin.remove(), 2000);
  }
}

/**
 * Sprawdza czy po dodaniu wpłaty oszczędnościowej osiągnięto 100% miesięcznego celu oszczędnościowego
 * i odpala eksplozję 30 złotych monet (Jackpot) na środku ekranu.
 */
export function checkGlobalSavingsJackpot(
  addedAmount: number,
  entries: HistoryEntry[],
  categories: Category[],
  config: BudgetConfig
): void {
  if (addedAmount <= 0) return;

  const d = new Date();
  const curPeriod = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  const dist = calculateBudgetDistribution(config);
  const idealSavings = dist.savingsTarget;

  if (idealSavings <= 0) return;

  const bucketMap = new Map<string, Category['bucket']>();
  categories.forEach(c => bucketMap.set(c.name, c.bucket));

  let currentSavingsThisMonth = 0;
  entries.forEach(e => {
    if (e.month === curPeriod) {
      const b = bucketMap.get(e.category) || (e.category === 'Oszczędności' ? 'savings' : 'needs');
      if (b === 'savings') {
        currentSavingsThisMonth += Number(e.amount);
      }
    }
  });

  const totalAfterAdd = currentSavingsThisMonth + addedAmount;
  if (totalAfterAdd >= idealSavings && currentSavingsThisMonth < idealSavings) {
    triggerCoinDrop('body', 0, true);
  }
}

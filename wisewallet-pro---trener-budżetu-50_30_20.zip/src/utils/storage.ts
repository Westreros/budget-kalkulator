import { BudgetConfig, Category, Subscription, SavingsGoal, HistoryEntry } from '../types/budget';
import { DebtItem } from './premiumLogic';

// --- FEATURE FLAGS & FREE TIER LIMITS (CENTRUM DOWODZENIA) ---
export const APP_CONFIG = {
  guestBannerActive: true,
  guestLimitsActive: false,
  maxGuestExpenses: 15,
  maxGuestGoals: 2,
  maxGuestSubs: 1,
  freeMaxGoals: 2
};

export const DEFAULT_CONFIG: BudgetConfig = {
  income: 0,
  benefits800: 0,
  benefitsActiveHome: 0,
  benefitsActiveWork: 0,
  otherIncome: 0,
  rushEmergencyFund: false,
  currentSavings: 0,
  emergencyFundMonths: 6,
  customRatiosEnabled: false,
  customNeedsPct: 50,
  customSavingsPct: 30,
  customFunPct: 20,
  currency: 'PLN',
  extraDebtPayment: 400,
  isPremium: false,
  household: {
    enabled: false,
    myName: 'Marcin',
    partnerName: 'Ania',
    partnerNetIncome: 0,
    shareCode: 'WW-RODZINA-2026',
    activeAuthor: 'Marcin'
  }
};

export const DEMO_CONFIG: BudgetConfig = {
  ...DEFAULT_CONFIG,
  income: 7500,
  benefits800: 1,
  currentSavings: 18000,
  household: {
    enabled: false,
    myName: 'Marcin',
    partnerName: 'Ania',
    partnerNetIncome: 5500,
    shareCode: 'WW-RODZINA-2026',
    activeAuthor: 'Marcin'
  }
};

export const DEFAULT_DEBTS: DebtItem[] = [];

export const DEMO_DEBTS: DebtItem[] = [
  { id: 'debt-1', name: 'Karta Kredytowa Visa', balance: 4200, interestRate: 18.5, minPayment: 210 },
  { id: 'debt-2', name: 'Kredyt Gotówkowy', balance: 12500, interestRate: 11.4, minPayment: 420 },
  { id: 'debt-3', name: 'Raty 0% RTV Euro AGD', balance: 1800, interestRate: 0, minPayment: 180 }
];

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'cat-1', name: 'Mieszkanie & Czynsz', bucket: 'needs', isDefault: true },
  { id: 'cat-2', name: 'Jedzenie & Supermarket', bucket: 'needs', isDefault: true },
  { id: 'cat-3', name: 'Transport & Paliwo', bucket: 'needs', isDefault: true },
  { id: 'cat-4', name: 'Zdrowie & Leki', bucket: 'needs', isDefault: true },
  { id: 'cat-5', name: 'Raty & Kredyty', bucket: 'needs', isDefault: true },
  { id: 'cat-6', name: 'Kawiarnie & Restauracje', bucket: 'fun', isDefault: true },
  { id: 'cat-7', name: 'Rozrywka & Kino', bucket: 'fun', isDefault: true },
  { id: 'cat-8', name: 'Zakupy & Ubrania', bucket: 'fun', isDefault: true },
  { id: 'cat-9', name: 'Hobby & Sport', bucket: 'fun', isDefault: true },
  { id: 'cat-10', name: 'Poduszka Bezpieczeństwa', bucket: 'savings', isDefault: true },
  { id: 'cat-11', name: 'Inwestycje (ETF / IKE)', bucket: 'savings', isDefault: true },
  { id: 'cat-12', name: 'Fundusz Wakacyjny', bucket: 'savings', isDefault: true },
  { id: 'cat-13', name: 'Oszczędności', bucket: 'savings', isDefault: true }
];

export const DEFAULT_GOALS: SavingsGoal[] = [];

export const DEMO_GOALS: SavingsGoal[] = [
  { id: 'goal-1', name: 'Wakacje w Grecji', target: 6000, saved: 3400, color: '#0284c7' },
  { id: 'goal-2', name: 'Wymiana Laptopa', target: 4500, saved: 2100, color: '#7c3aed' }
];

export const DEFAULT_SUBSCRIPTIONS: Subscription[] = [];

export const DEMO_SUBSCRIPTIONS: Subscription[] = [
  {
    id: 'sub-1',
    name: 'Czynsz spółdzielnia',
    amount: 850,
    category: 'Mieszkanie & Czynsz',
    dayOfMonth: 10,
    cycle: 'monthly'
  },
  {
    id: 'sub-2',
    name: 'Internet światłowód',
    amount: 79,
    category: 'Mieszkanie & Czynsz',
    dayOfMonth: 15,
    cycle: 'monthly'
  },
  {
    id: 'sub-3',
    name: 'Netflix & Spotify',
    amount: 90,
    category: 'Rozrywka & Kino',
    dayOfMonth: 5,
    cycle: 'monthly'
  },
  {
    id: 'sub-4',
    name: 'Ubezpieczenie OC / AC',
    amount: 1400,
    category: 'Transport & Paliwo',
    dayOfMonth: 20,
    cycle: 'annual',
    dueMonth: 11,
    savedSoFar: 900,
    createdMonth: '2026-05'
  }
];

export function getInitialEntries(): HistoryEntry[] {
  return [];
}

export function getDemoEntries(): HistoryEntry[] {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const ym = `${y}-${m}`;

  return [
    {
      id: 'h-1',
      exactDate: `${ym}-02`,
      month: ym,
      category: 'Jedzenie & Supermarket',
      name: 'Biedronka zakupy tygodniowe',
      amount: 284,
      addedBy: 'Marcin'
    },
    {
      id: 'h-2',
      exactDate: `${ym}-05`,
      month: ym,
      category: 'Kawiarnie & Restauracje',
      name: 'Kawiarnia z przyjaciółmi',
      amount: 68,
      addedBy: 'Ania'
    },
    {
      id: 'h-3',
      exactDate: `${ym}-08`,
      month: ym,
      category: 'Transport & Paliwo',
      name: 'Stacja Orlen PB95',
      amount: 260,
      addedBy: 'Marcin'
    },
    {
      id: 'h-4',
      exactDate: `${ym}-10`,
      month: ym,
      category: 'Mieszkanie & Czynsz',
      name: 'Czynsz spółdzielnia (Opłata stała)',
      amount: 850,
      isSubscription: true,
      addedBy: 'Marcin'
    },
    {
      id: 'h-5',
      exactDate: `${ym}-12`,
      month: ym,
      category: 'Poduszka Bezpieczeństwa',
      name: 'Wpłata na cel: Poduszka Finansowa',
      amount: 800,
      addedBy: 'Marcin'
    }
  ];
}

const STORAGE_KEY = 'wisewallet_pro_data_v4';
const LEGACY_SETTINGS_KEY = 'walletwise_settings';

export interface AppStoredState {
  config: BudgetConfig;
  categories: Category[];
  goals: SavingsGoal[];
  subscriptions: Subscription[];
  entries: HistoryEntry[];
  debts: DebtItem[];
  activeTab: string;
}

/**
 * Konwertuje obiekt `walletwise_settings` (z oryginalnego index.html / Supabase user_metadata.budget_settings)
 * na pełny stan aplikacji React, zachowując 100% kompatybilności wstecznej.
 */
export function parseLegacySettingsObject(
  s: any,
  fallbackState?: AppStoredState
): Partial<AppStoredState> {
  if (!s || typeof s !== 'object') return {};

  const baseConfig = fallbackState?.config || DEFAULT_CONFIG;
  const config: BudgetConfig = {
    ...baseConfig,
    ...(s.config || {}),
    income: s.income !== undefined ? parseFloat(s.income) || 0 : baseConfig.income,
    benefits800: s.kids800 !== undefined ? parseInt(s.kids800, 10) || 0 : baseConfig.benefits800,
    benefitsActiveHome:
      s.kidsActiveHome !== undefined
        ? parseInt(s.kidsActiveHome, 10) || 0
        : baseConfig.benefitsActiveHome,
    benefitsActiveWork:
      s.kidsActiveWork !== undefined
        ? parseInt(s.kidsActiveWork, 10) || 0
        : baseConfig.benefitsActiveWork,
    currentSavings:
      s.currentSavings !== undefined ? parseFloat(s.currentSavings) || 0 : baseConfig.currentSavings,
    rushEmergencyFund:
      s.rushEmergencyFund !== undefined ? Boolean(s.rushEmergencyFund) : baseConfig.rushEmergencyFund,
    otherIncome: s.otherIncome !== undefined ? parseFloat(s.otherIncome) || 0 : baseConfig.otherIncome,
    emergencyFundMonths:
      s.emergencyFundMonths !== undefined ? Number(s.emergencyFundMonths) || 6 : baseConfig.emergencyFundMonths,
    customRatiosEnabled:
      s.customRatiosEnabled !== undefined ? Boolean(s.customRatiosEnabled) : baseConfig.customRatiosEnabled,
    customNeedsPct: s.customNeedsPct !== undefined ? Number(s.customNeedsPct) : baseConfig.customNeedsPct,
    customSavingsPct:
      s.customSavingsPct !== undefined ? Number(s.customSavingsPct) : baseConfig.customSavingsPct,
    customFunPct: s.customFunPct !== undefined ? Number(s.customFunPct) : baseConfig.customFunPct,
    currency: s.currency || baseConfig.currency,
    extraDebtPayment:
      s.extraDebtPayment !== undefined ? Number(s.extraDebtPayment) : baseConfig.extraDebtPayment,
    isPremium: s.isPremium !== undefined ? Boolean(s.isPremium) : Boolean(baseConfig.isPremium),
    household: {
      ...DEFAULT_CONFIG.household!,
      ...(baseConfig.household || {}),
      ...(s.household || {})
    }
  };

  let categories: Category[] | undefined;
  if (Array.isArray(s.categories) && s.categories.length > 0) {
    categories = s.categories.map((c: any, idx: number) => ({
      id: c.id ? String(c.id) : `cat-legacy-${idx}-${c.name}`,
      name: String(c.name),
      bucket: c.bucket === 'fun' || c.bucket === 'savings' ? c.bucket : 'needs',
      isDefault: Boolean(c.isDefault)
    }));
  }

  let goals: SavingsGoal[] | undefined;
  if (Array.isArray(s.goals)) {
    goals = s.goals.map((g: any, idx: number) => ({
      id: g.id !== undefined ? String(g.id) : `goal-legacy-${idx}`,
      name: String(g.name || 'Cel'),
      target: Number(g.target) || 0,
      saved: Number(g.saved) || 0,
      color: g.color
    }));
  }

  let subscriptions: Subscription[] | undefined;
  if (Array.isArray(s.subscriptions)) {
    subscriptions = s.subscriptions.map((sub: any, idx: number) => ({
      id: sub.id !== undefined ? String(sub.id) : `sub-legacy-${idx}`,
      name: String(sub.name || 'Opłata'),
      amount: Number(sub.amount) || 0,
      category: String(sub.category || 'Inne'),
      dayOfMonth: Number(sub.dayOfMonth) || 10,
      cycle: sub.cycle || 'monthly',
      dueMonth: sub.dueMonth !== undefined ? Number(sub.dueMonth) : undefined,
      savedSoFar: sub.savedSoFar !== undefined ? Number(sub.savedSoFar) : 0,
      createdMonth: sub.createdMonth || undefined,
      lastPaidMonth: sub.lastPaidMonth || null
    }));
  }

  let entries: HistoryEntry[] | undefined;
  if (Array.isArray(s.historyLogs)) {
    entries = s.historyLogs.map((h: any, idx: number) => mapSupabaseHistoryRowToEntry(h, idx));
  }

  let debts: DebtItem[] | undefined;
  if (Array.isArray(s.debts)) {
    debts = s.debts;
  }

  return {
    config,
    ...(categories ? { categories } : {}),
    ...(goals ? { goals } : {}),
    ...(subscriptions ? { subscriptions } : {}),
    ...(entries ? { entries } : {}),
    ...(debts ? { debts } : {})
  };
}

/**
 * Mapuje rekord z tabeli `history_logs` w Supabase (lub z oryginalnego `historyLogs` w localStorage)
 * na obiekt `HistoryEntry`.
 */
export function mapSupabaseHistoryRowToEntry(row: any, idx: number = 0): HistoryEntry {
  const month = String(
    row.month ||
      `${row.year || new Date().getFullYear()}-${String(row.month_num || row.monthNum || '01').padStart(2, '0')}`
  );
  const exactDate = String(row.exact_date || row.exactDate || `${month}-01`);
  const name = String(row.name || 'Wydatek');
  return {
    id: row.id !== undefined ? String(row.id) : `entry-${Date.now()}-${idx}`,
    exactDate,
    month,
    category: String(row.category || 'Inne'),
    name,
    amount: Number(row.amount) || 0,
    isSubscription: Boolean(row.isSubscription || name.endsWith('(Opłata stała)')),
    addedBy: row.addedBy || undefined
  };
}

/**
 * Buduje obiekt `budget_settings` kompatybilny 1:1 z `walletwise_settings` oraz
 * `supabase.auth.updateUser({ data: { budget_settings: s } })`.
 */
export function buildLegacySettingsPayload(data: AppStoredState, includeHistoryLogs: boolean = false) {
  const payload: Record<string, any> = {
    income: String(data.config.income ?? 0),
    kids800: String(data.config.benefits800 ?? 0),
    kidsActiveHome: String(data.config.benefitsActiveHome ?? 0),
    kidsActiveWork: String(data.config.benefitsActiveWork ?? 0),
    currentSavings: String(data.config.currentSavings ?? 0),
    rushEmergencyFund: Boolean(data.config.rushEmergencyFund),
    otherIncome: data.config.otherIncome ?? 0,
    emergencyFundMonths: data.config.emergencyFundMonths ?? 6,
    customRatiosEnabled: Boolean(data.config.customRatiosEnabled),
    customNeedsPct: data.config.customNeedsPct ?? 50,
    customSavingsPct: data.config.customSavingsPct ?? 30,
    customFunPct: data.config.customFunPct ?? 20,
    currency: data.config.currency || 'PLN',
    extraDebtPayment: data.config.extraDebtPayment ?? 400,
    isPremium: Boolean(data.config.isPremium),
    household: data.config.household,
    categories: data.categories.map(c => ({ id: c.id, name: c.name, bucket: c.bucket })),
    goals: data.goals.map(g => ({
      id: isNaN(Number(g.id)) ? g.id : Number(g.id),
      name: g.name,
      target: g.target,
      saved: g.saved
    })),
    subscriptions: data.subscriptions.map(sub => ({
      id: isNaN(Number(sub.id)) ? sub.id : Number(sub.id),
      name: sub.name,
      amount: sub.amount,
      category: sub.category,
      dayOfMonth: sub.dayOfMonth,
      cycle: sub.cycle || 'monthly',
      dueMonth: sub.dueMonth || 1,
      savedSoFar: sub.savedSoFar || 0,
      createdMonth: sub.createdMonth,
      lastPaidMonth: sub.lastPaidMonth || null
    })),
    debts: data.debts || DEFAULT_DEBTS
  };

  if (includeHistoryLogs) {
    payload.historyLogs = data.entries.map(e => {
      const parts = (e.exactDate || `${e.month}-01`).split('-');
      return {
        id: isNaN(Number(e.id)) ? e.id : Number(e.id),
        month: e.month,
        year: parts[0],
        month_num: parts[1],
        monthNum: parts[1],
        exact_date: e.exactDate,
        category: e.category,
        name: e.name,
        amount: e.amount,
        addedBy: e.addedBy
      };
    });
  }

  return payload;
}

export function loadStoredData(): AppStoredState {
  try {
    // 1. Check v3 / v2 storage first
    const rawV3 = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('wisewallet_pro_data_v2');
    if (rawV3) {
      const parsed = JSON.parse(rawV3);
      return {
        config: {
          ...DEFAULT_CONFIG,
          ...(parsed.config || {}),
          household: { ...DEFAULT_CONFIG.household!, ...(parsed.config?.household || {}) }
        },
        categories:
          parsed.categories && parsed.categories.length > 0 ? parsed.categories : DEFAULT_CATEGORIES,
        goals: parsed.goals || DEFAULT_GOALS,
        subscriptions: parsed.subscriptions || DEFAULT_SUBSCRIPTIONS,
        entries: parsed.entries || getInitialEntries(),
        debts: parsed.debts || DEFAULT_DEBTS,
        activeTab: parsed.activeTab || 'calculator'
      };
    }

    // 2. Fallback to original `walletwise_settings` if present in browser
    const rawLegacy = localStorage.getItem(LEGACY_SETTINGS_KEY);
    if (rawLegacy) {
      const parsedLegacy = JSON.parse(rawLegacy);
      const converted = parseLegacySettingsObject(parsedLegacy);
      return {
        config: converted.config || DEFAULT_CONFIG,
        categories:
          converted.categories && converted.categories.length > 0
            ? converted.categories
            : DEFAULT_CATEGORIES,
        goals: converted.goals || DEFAULT_GOALS,
        subscriptions: converted.subscriptions || DEFAULT_SUBSCRIPTIONS,
        entries: converted.entries || getInitialEntries(),
        debts: converted.debts || DEFAULT_DEBTS,
        activeTab: 'calculator'
      };
    }
  } catch (err) {
    console.error('Failed to load local storage:', err);
  }

  return {
    config: DEFAULT_CONFIG,
    categories: DEFAULT_CATEGORIES,
    goals: DEFAULT_GOALS,
    subscriptions: DEFAULT_SUBSCRIPTIONS,
    entries: getInitialEntries(),
    debts: DEFAULT_DEBTS,
    activeTab: 'calculator'
  };
}

export function saveStoredData(data: AppStoredState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    // Zachowujemy także oryginalny klucz `walletwise_settings` dla 100% kompatybilności
    const legacyPayload = buildLegacySettingsPayload(data, true);
    localStorage.setItem(LEGACY_SETTINGS_KEY, JSON.stringify(legacyPayload));
  } catch (err) {
    console.error('Failed to save to local storage:', err);
  }
}

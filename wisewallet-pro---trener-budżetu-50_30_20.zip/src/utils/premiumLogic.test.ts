import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseBankNotification,
  calculateDebtPayoffPlan,
  calculateStreakDiscount,
  DebtItem
} from './premiumLogic';
import {
  DEFAULT_CATEGORIES,
  parseLegacySettingsObject,
  mapSupabaseHistoryRowToEntry
} from './storage';

test('parseBankNotification extracts amount, merchant, date and category from Polish bank SMS', () => {
  const sms = 'mBank: Transakcja kartą 142,50 PLN w BIEDRONKA WARSZAWA dnia 24.10.2026.';
  const parsed = parseBankNotification(sms, DEFAULT_CATEGORIES, '2026-10-20');

  assert.equal(parsed.amount, 142.5);
  assert.equal(parsed.date, '2026-10-24');
  assert.equal(parsed.suggestedCategory, 'Jedzenie & Supermarket');
  assert.equal(parsed.confidence, 'high');
});

test('parseBankNotification categorizes fuel station SMS', () => {
  const sms = 'PKO BP: Płatność BLIK 265.00 PLN w STACJA ORLEN KRAKOW dnia 2026-10-22';
  const parsed = parseBankNotification(sms, DEFAULT_CATEGORIES);

  assert.equal(parsed.amount, 265);
  assert.equal(parsed.date, '2026-10-22');
  assert.equal(parsed.suggestedCategory, 'Transport & Paliwo');
});

test('calculateDebtPayoffPlan compares snowball and avalanche strategies', () => {
  const sampleDebts: DebtItem[] = [
    { id: 'd1', name: 'Karta Kredytowa', balance: 4000, interestRate: 20, minPayment: 200 },
    { id: 'd2', name: 'Pożyczka Gotówkowa', balance: 10000, interestRate: 12, minPayment: 350 },
    { id: 'd3', name: 'Raty 0% Laptop', balance: 1500, interestRate: 0, minPayment: 150 }
  ];

  const snowball = calculateDebtPayoffPlan(sampleDebts, 500, 'snowball');
  const avalanche = calculateDebtPayoffPlan(sampleDebts, 500, 'avalanche');

  // Snowball pays off smallest balance (d3: 1500 PLN) first
  assert.equal(snowball.payoffOrder[0].id, 'd3');

  // Avalanche pays off highest interest rate (d1: 20%) first and saves more or equal interest
  assert.equal(avalanche.payoffOrder[0].id, 'd1');
  assert.equal(avalanche.totalInterestPaid <= snowball.totalInterestPaid, true);
  assert.equal(avalanche.monthsSaved > 0, true);
});

test('calculateStreakDiscount computes progressive discount up to 50%', () => {
  const d10 = calculateStreakDiscount(10, 2, 29);
  assert.equal(d10.discountPercent, 20);
  assert.equal(d10.finalPriceMonthly, 23.2);
  assert.equal(d10.freeMonthUnlocked, false);

  const d30 = calculateStreakDiscount(30, 6, 29);
  assert.equal(d30.discountPercent, 50);
  assert.equal(d30.finalPriceMonthly, 14.5);
  assert.equal(d30.freeMonthUnlocked, true);
});

test('parseLegacySettingsObject and mapSupabaseHistoryRowToEntry preserve original Supabase schema 1:1', () => {
  const legacySettings = {
    income: '8200',
    kids800: '2',
    kidsActiveHome: '1',
    kidsActiveWork: '0',
    currentSavings: '15000',
    rushEmergencyFund: true,
    categories: [{ name: 'Czynsz', bucket: 'needs' }, { name: 'Kino', bucket: 'fun' }],
    goals: [{ id: 101, name: 'Wakacje w Rzymie', target: 5000, saved: 1200 }],
    subscriptions: [
      {
        id: 202,
        name: 'Ubezpieczenie OC',
        amount: 1200,
        category: 'Czynsz',
        dayOfMonth: 15,
        cycle: 'annual',
        dueMonth: 5,
        savedSoFar: 400
      }
    ]
  };

  const parsed = parseLegacySettingsObject(legacySettings);
  assert.equal(parsed.config?.income, 8200);
  assert.equal(parsed.config?.benefits800, 2);
  assert.equal(parsed.config?.benefitsActiveHome, 1);
  assert.equal(parsed.config?.currentSavings, 15000);
  assert.equal(parsed.config?.rushEmergencyFund, true);
  assert.equal(parsed.goals?.[0].name, 'Wakacje w Rzymie');
  assert.equal(parsed.subscriptions?.[0].cycle, 'annual');

  const row = {
    id: 555,
    month: '2026-10',
    year: '2026',
    month_num: '10',
    exact_date: '2026-10-14',
    category: 'Kino',
    name: 'Multikino bilety',
    amount: 75
  };
  const entry = mapSupabaseHistoryRowToEntry(row);
  assert.equal(entry.id, '555');
  assert.equal(entry.exactDate, '2026-10-14');
  assert.equal(entry.month, '2026-10');
  assert.equal(entry.amount, 75);
});

import { createClient, SupabaseClient } from '@supabase/supabase-js';

let supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  if (supabaseInstance) return supabaseInstance;

  try {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const isLocalOrPreview =
      !origin ||
      origin.includes('localhost') ||
      origin.includes('127.0.0.1') ||
      origin.includes('run.app') ||
      origin.includes('github.io');

    // Use 1st-party /baza rewrite on Vercel custom domains to prevent AdBlocker / Brave Shields blocks
    const envUrl = import.meta.env.VITE_SUPABASE_URL;
    const defaultUrl = isLocalOrPreview
      ? 'https://kbzspdwizcwpzlvytdzw.supabase.co'
      : `${origin}/baza`;

    const supabaseUrl = envUrl || defaultUrl;
    const supabaseKey =
      import.meta.env.VITE_SUPABASE_ANON_KEY ||
      'sb_publishable_nPfkgQfKOapm-t9OqWZ4KA__KuU0jqB';

    supabaseInstance = createClient(supabaseUrl, supabaseKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true
      }
    });

    return supabaseInstance;
  } catch (err) {
    console.error('Supabase init error:', err);
    return null;
  }
}

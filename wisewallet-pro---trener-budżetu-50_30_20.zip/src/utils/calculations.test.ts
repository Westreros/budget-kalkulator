import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateTotalIncome,
  calculateBudgetDistribution,
  calculateSinkingFundAllocation,
  isSubDueInMonth,
  getSubNextDueInfo,
  calculateRollover,
  calculateNoSpendStreak,
  auditBudgetHealth
} from './calculations';
import { BudgetConfig, Subscription, HistoryEntry, Category } from '../types/budget';

const baseConfig: BudgetConfig = {
  income: 6000,
  benefits800: 1, // 800 PLN
  benefitsActiveHome: 0,
  benefitsActiveWork: 1, // 1500 PLN
  otherIncome: 200,
  rushEmergencyFund: false,
  currentSavings: 15000,
  emergencyFundMonths: 6,
  customRatiosEnabled: false,
  customNeedsPct: 50,
  customSavingsPct: 20,
  customFunPct: 30,
  currency: 'PLN'
};

test('calculateTotalIncome sums salary, social programs and other income', () => {
  const total = calculateTotalIncome(baseConfig);
  // 6000 + 800 + 0 + 1500 + 200 = 8500
  assert.equal(total, 8500);
});

test('calculateBudgetDistribution splits 50/30/20 standardly', () => {
  const dist = calculateBudgetDistribution(baseConfig);
  assert.equal(dist.totalIncome, 8500);
  assert.equal(dist.needsTarget, 4250); // 50%
  assert.equal(dist.savingsTarget, 2550); // 30%
  assert.equal(dist.funTarget, 1700); // 20%
  assert.equal(dist.emergencyFundTarget, 4250 * 6);
});

test('calculateBudgetDistribution applies rush emergency mode correctly', () => {
  const rushConfig: BudgetConfig = { ...baseConfig, rushEmergencyFund: true };
  const dist = calculateBudgetDistribution(rushConfig);
  assert.equal(dist.needsTarget, 4250); // 50%
  assert.equal(dist.funTarget, 850); // 10%
  assert.equal(dist.savingsTarget, 3400); // 40%
});

test('calculateBudgetDistribution applies custom ratios when PRO is enabled', () => {
  const customConfig: BudgetConfig = {
    ...baseConfig,
    isPremium: true,
    customRatiosEnabled: true,
    customNeedsPct: 60,
    customSavingsPct: 25,
    customFunPct: 15
  };
  const dist = calculateBudgetDistribution(customConfig);
  assert.equal(dist.needsTarget, 5100); // 60%
  assert.equal(dist.funTarget, 1275); // 15%
  assert.equal(dist.savingsTarget, 2125); // 25%
});

test('isSubDueInMonth accurately calculates cycles', () => {
  const annualSub: Subscription = {
    id: 'sub-1',
    name: 'Ubezpieczenie OC',
    amount: 1200,
    category: 'Transport',
    dayOfMonth: 15,
    cycle: 'annual',
    dueMonth: 10
  };

  assert.equal(isSubDueInMonth(annualSub, 10), true);
  assert.equal(isSubDueInMonth(annualSub, 9), false);
  assert.equal(isSubDueInMonth(annualSub, 11), false);

  const quarterlySub: Subscription = {
    id: 'sub-2',
    name: 'Woda / Media',
    amount: 300,
    category: 'Mieszkanie',
    dayOfMonth: 1,
    cycle: 'quarterly',
    dueMonth: 3 // Mar, Jun, Sep, Dec
  };

  assert.equal(isSubDueInMonth(quarterlySub, 3), true);
  assert.equal(isSubDueInMonth(quarterlySub, 6), true);
  assert.equal(isSubDueInMonth(quarterlySub, 9), true);
  assert.equal(isSubDueInMonth(quarterlySub, 12), true);
  assert.equal(isSubDueInMonth(quarterlySub, 4), false);
});

test('calculateSinkingFundAllocation computes monthly reservation', () => {
  const sub: Subscription = {
    id: 'sub-annual',
    name: 'Ubezpieczenie OC',
    amount: 1200,
    category: 'Transport',
    dayOfMonth: 20,
    cycle: 'annual',
    dueMonth: 12,
    savedSoFar: 200,
    createdMonth: '2026-06'
  };

  // From 2026-06 to 2026-12 is 7 months. Needed: 1000 PLN. 1000 / 7 ≈ 143 PLN/mc
  const alloc = calculateSinkingFundAllocation(sub, 2026, 6);
  assert.equal(alloc.totalNeeded, 1200);
  assert.equal(alloc.standardMonthly, 100);
  assert.equal(alloc.monthlyAllocation > 0, true);
});

test('calculateRollover carries unspent fun money from previous month', () => {
  const categories: Category[] = [
    { id: '1', name: 'Rozrywka', bucket: 'fun' },
    { id: '2', name: 'Czynsz', bucket: 'needs' }
  ];

  // In previous month (2026-09), user spent only 500 PLN on fun
  const entries: HistoryEntry[] = [
    { id: 'e1', exactDate: '2026-09-05', month: '2026-09', category: 'Rozrywka', name: 'Kino', amount: 500 },
    { id: 'e2', exactDate: '2026-09-10', month: '2026-09', category: 'Czynsz', name: 'Czynsz', amount: 2000 }
  ];

  const rollover = calculateRollover(entries, categories, baseConfig, 2026, 10);
  // funTarget = 1700 PLN (20% of 8500). Spent 500 PLN. Rollover = 1200 PLN.
  assert.equal(rollover, 1200);
});

test('calculateNoSpendStreak counts consecutive zero-fun-spending days and resets to 0 on fun day', () => {
  const categories: Category[] = [
    { id: '1', name: 'Kawiarnia', bucket: 'fun' },
    { id: '2', name: 'Biedronka', bucket: 'needs' }
  ];

  const entries: HistoryEntry[] = [
    { id: 'e1', exactDate: '2026-10-10', month: '2026-10', category: 'Kawiarnia', name: 'Kawa', amount: 25 },
    { id: 'e2', exactDate: '2026-10-12', month: '2026-10', category: 'Biedronka', name: 'Jedzenie', amount: 150 }
  ];

  // Today is 2026-10-15. Last fun was on 10th. Days 15, 14, 13, 12, 11 had no fun expense = 5 days streak!
  const streakRes = calculateNoSpendStreak(entries, categories, 2026, 10, 15);
  assert.equal(streakRes.streak, 5);
  assert.equal(streakRes.streakQuality, 'silver');

  // If today is 2026-10-10 (same day as fun expense), streak resets to 0!
  const streakOnFunDay = calculateNoSpendStreak(entries, categories, 2026, 10, 10);
  assert.equal(streakOnFunDay.streak, 0);
});

test('auditBudgetHealth produces actionable diagnosis', () => {
  const audit = auditBudgetHealth(
    baseConfig,
    [],
    [],
    [],
    2026,
    10
  );

  assert.equal(typeof audit.score, 'number');
  assert.equal(audit.issues.length > 0, true);
  assert.equal(['A+', 'A', 'B', 'C', 'D'].includes(audit.grade), true);
});

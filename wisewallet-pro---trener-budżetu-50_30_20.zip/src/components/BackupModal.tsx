import React from 'react';
import { AppStoredState } from '../utils/storage';
import { X, Download, Upload, FileSpreadsheet, RotateCcw, ShieldCheck } from 'lucide-react';

interface BackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentState: AppStoredState;
  onRestoreState: (state: AppStoredState) => void;
  onResetDefault: () => void;
}

export const BackupModal: React.FC<BackupModalProps> = ({
  isOpen,
  onClose,
  currentState,
  onRestoreState,
  onResetDefault
}) => {
  if (!isOpen) return null;

  const handleDownloadJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(currentState, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `wisewallet_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleDownloadCSV = () => {
    let csv = 'Data;Miesiac;Kategoria;Nazwa/Opis;Kwota\n';
    currentState.entries.forEach(e => {
      csv += `${e.exactDate || e.month};${e.month};"${e.category}";"${e.name}";${e.amount}\n`;
    });

    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `dziennik_wydatkow_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const handleUploadJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      try {
        const parsed = JSON.parse(String(evt.target?.result));
        if (parsed && parsed.config && parsed.entries) {
          onRestoreState(parsed);
          alert('Pomyślnie przywrócono stan z kopii zapasowej!');
          onClose();
        } else {
          alert('Niepoprawny format pliku kopii zapasowej.');
        }
      } catch (err) {
        alert('Błąd odczytu pliku JSON.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-emerald-600" />
            <h3 className="text-lg font-bold text-slate-900">Kopia Zapasowa i Eksport</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="mb-5 text-xs text-slate-500 leading-relaxed">
          Wszystkie Twoje finanse są bezpiecznie zapisywane na Twoim urządzeniu. Pobierz kopię zapasową w pliku JSON lub wyeksportuj transakcje do Excela/CSV.
        </p>

        <div className="space-y-3">
          {/* Download JSON */}
          <button
            type="button"
            onClick={handleDownloadJSON}
            className="flex w-full items-center justify-between rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 text-xs font-bold text-slate-800 transition-all hover:border-blue-400 hover:bg-blue-50/50"
          >
            <div className="flex items-center gap-2.5">
              <Download className="h-4 w-4 text-blue-600" />
              <div className="text-left">
                <span className="block text-sm">Pobierz pełną kopię (JSON)</span>
                <span className="text-[11px] font-medium text-slate-500">Zawiera dochody, opłaty, skarbonki i dziennik</span>
              </div>
            </div>
            <span className="rounded-md bg-blue-100 px-2 py-0.5 text-[10px] font-extrabold text-blue-800">.json</span>
          </button>

          {/* Download CSV */}
          <button
            type="button"
            onClick={handleDownloadCSV}
            className="flex w-full items-center justify-between rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 text-xs font-bold text-slate-800 transition-all hover:border-emerald-400 hover:bg-emerald-50/50"
          >
            <div className="flex items-center gap-2.5">
              <FileSpreadsheet className="h-4 w-4 text-emerald-600" />
              <div className="text-left">
                <span className="block text-sm">Eksport Dziennika do CSV</span>
                <span className="text-[11px] font-medium text-slate-500">Otwórz w Excelu, Google Sheets lub Numbers</span>
              </div>
            </div>
            <span className="rounded-md bg-emerald-100 px-2 py-0.5 text-[10px] font-extrabold text-emerald-800">.csv</span>
          </button>

          {/* Upload JSON */}
          <label className="flex w-full cursor-pointer items-center justify-between rounded-xl border border-dashed border-slate-300 bg-white p-3.5 text-xs font-bold text-slate-800 transition-all hover:border-blue-500 hover:bg-slate-50">
            <div className="flex items-center gap-2.5">
              <Upload className="h-4 w-4 text-indigo-600" />
              <div className="text-left">
                <span className="block text-sm">Wczytaj kopię z pliku</span>
                <span className="text-[11px] font-medium text-slate-500">Przywróć dane z pliku .json</span>
              </div>
            </div>
            <input type="file" accept=".json" onChange={handleUploadJSON} className="hidden" />
          </label>
        </div>

        <div className="mt-6 border-t border-slate-100 pt-4 flex items-center justify-between">
          <button
            type="button"
            onClick={() => {
              if (confirm('Czy na pewno chcesz przywrócić domyślne dane demonstracyjne? Twoje obecne wpisy zostaną zastąpione.')) {
                onResetDefault();
                onClose();
              }
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-rose-600 hover:text-rose-700"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Przywróć dane demo
          </button>

          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800"
          >
            Zamknij
          </button>
        </div>
      </div>
    </div>
  );
};

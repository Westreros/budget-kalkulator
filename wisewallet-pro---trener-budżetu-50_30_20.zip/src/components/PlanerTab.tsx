import React from 'react';
import { BudgetConfig, BudgetDistribution } from '../types/budget';
import {
  Landmark,
  ShoppingCart,
  PartyPopper,
  PiggyBank,
  Zap,
  Sliders,
  ShieldCheck,
  TrendingUp,
  Home,
  Utensils,
  Car,
  CreditCard,
  Crown
} from 'lucide-react';

interface PlanerTabProps {
  config: BudgetConfig;
  onConfigChange: (newConfig: BudgetConfig) => void;
  distribution: BudgetDistribution;
  rolloverAmount: number;
  onRequirePremium: (reason: string) => void;
}

export const PlanerTab: React.FC<PlanerTabProps> = ({
  config,
  onConfigChange,
  distribution,
  rolloverAmount,
  onRequirePremium
}) => {
  const currency = config.currency || 'PLN';
  const isPremium = Boolean(config.isPremium);
  const totalFunMonthly = distribution.funTarget + rolloverAmount;
  const dailyFun = Math.round(totalFunMonthly / 30);

  const handleCustomRatioChange = (field: 'customNeedsPct' | 'customSavingsPct' | 'customFunPct', value: number) => {
    const val = Math.max(5, Math.min(85, value));
    if (field === 'customNeedsPct') {
      const remaining = 100 - val;
      const currentFunRatio = config.customFunPct / (config.customFunPct + config.customSavingsPct || 1);
      const newFun = Math.round(remaining * currentFunRatio);
      const newSavings = remaining - newFun;
      onConfigChange({
        ...config,
        customNeedsPct: val,
        customFunPct: newFun,
        customSavingsPct: newSavings
      });
    } else if (field === 'customSavingsPct') {
      const remaining = 100 - config.customNeedsPct;
      const newSavings = Math.min(remaining - 5, val);
      const newFun = remaining - newSavings;
      onConfigChange({
        ...config,
        customSavingsPct: newSavings,
        customFunPct: newFun
      });
    } else {
      const remaining = 100 - config.customNeedsPct;
      const newFun = Math.min(remaining - 5, val);
      const newSavings = remaining - newFun;
      onConfigChange({
        ...config,
        customFunPct: newFun,
        customSavingsPct: newSavings
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero row metrics */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Metric 1: Dochód */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 p-5 text-white shadow-lg">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400">
            <span className="flex items-center gap-1.5">
              <Landmark className="h-4 w-4 text-sky-400" /> Pełny Budżet
            </span>
            <span className="rounded-md bg-white/10 px-2 py-0.5 text-sky-300">Netto</span>
          </div>
          <div className="my-2.5 text-3xl font-black tracking-tight text-sky-400">
            {distribution.totalIncome.toLocaleString('pl-PL')} <span className="text-lg font-bold text-white">{currency}</span>
          </div>
          <p className="text-xs text-slate-300">
            {distribution.benefitsTotal > 0
              ? `${distribution.baseSalary.toLocaleString('pl-PL')} ${currency} pensji + ${distribution.benefitsTotal.toLocaleString('pl-PL')} ${currency} świadczeń`
              : 'Sama pensja podstawowa (brak świadczeń)'}
          </p>
        </div>

        {/* Metric 2: Koszty życia */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500">
            <span className="flex items-center gap-1.5">
              <ShoppingCart className="h-4 w-4 text-blue-600" /> Potrzeby ({distribution.needsPct}%)
            </span>
            <span className="rounded-md bg-blue-50 px-2 py-0.5 text-blue-700 font-extrabold">Stałe</span>
          </div>
          <div className="my-2.5 text-3xl font-black tracking-tight text-slate-900">
            {distribution.needsTarget.toLocaleString('pl-PL')} <span className="text-lg font-bold text-slate-500">{currency}</span>
          </div>
          <p className="text-xs text-slate-500">Mieszkanie, jedzenie, transport i raty kredytów.</p>
        </div>

        {/* Metric 3: Oszczędności */}
        <div className="rounded-2xl border border-emerald-200/80 bg-emerald-50/40 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-emerald-700">
            <span className="flex items-center gap-1.5">
              <PiggyBank className="h-4 w-4 text-emerald-600" /> Oszczędności ({distribution.savingsPct}%)
            </span>
            <span className="rounded-md bg-emerald-100 px-2 py-0.5 text-emerald-800 font-extrabold">Bogacenie</span>
          </div>
          <div className="my-2.5 text-3xl font-black tracking-tight text-emerald-700">
            {distribution.savingsTarget.toLocaleString('pl-PL')} <span className="text-lg font-bold text-emerald-600/80">{currency}</span>
          </div>
          <p className="text-xs text-emerald-800/80">Poduszka, fundusze celowe i inwestycje.</p>
        </div>

        {/* Metric 4: Zachcianki */}
        <div className="rounded-2xl border border-purple-200/80 bg-purple-50/40 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-purple-700">
            <span className="flex items-center gap-1.5">
              <PartyPopper className="h-4 w-4 text-purple-600" /> Zachcianki ({distribution.funPct}%)
            </span>
            <span className="rounded-md bg-purple-100 px-2 py-0.5 text-purple-800 font-extrabold">{dailyFun} {currency}/dzień</span>
          </div>
          <div className="my-2.5 text-3xl font-black tracking-tight text-purple-700">
            {totalFunMonthly.toLocaleString('pl-PL')} <span className="text-lg font-bold text-purple-600/80">{currency}</span>
          </div>
          <p className="text-xs text-purple-800/80">
            {rolloverAmount > 0
              ? `W tym +${rolloverAmount.toLocaleString('pl-PL')} ${currency} ze śnieżnej kuli z zeszłego m-ca!`
              : 'Kino, kawiarnia, hobby i przyjemności.'}
          </p>
        </div>
      </div>

      {/* Main Grid: Inputs vs Model Distribution */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left column: Inputs (7 cols) */}
        <div className="space-y-6 lg:col-span-7">
          <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-xs">
            <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-slate-900">
              <Landmark className="h-5 w-5 text-blue-600" /> 1. Dochody i Świadczenia Rodzinne
            </h2>

            <div className="space-y-4">
              <div>
                <label htmlFor="income-input" className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  Pensja netto (na rękę)
                </label>
                <div className="relative mt-1">
                  <input
                    id="income-input"
                    type="number"
                    min="0"
                    step="any"
                    value={config.income || ''}
                    onChange={e => onConfigChange({ ...config, income: parseFloat(e.target.value) || 0 })}
                    placeholder="np. 7000"
                    className="w-full rounded-xl border border-slate-300 bg-slate-50/50 px-4 py-2.5 pr-14 text-base font-semibold text-slate-900 outline-none transition-all focus:border-blue-600 focus:bg-white focus:ring-4 focus:ring-blue-100"
                  />
                  <span className="pointer-events-none absolute inset-y-0 right-4 flex items-center text-xs font-bold text-slate-400">
                    {currency}
                  </span>
                </div>
              </div>

              {/* Programy rodzinne */}
              <div className="rounded-xl border border-slate-200/90 bg-slate-50/60 p-4">
                <span className="block text-xs font-extrabold uppercase tracking-wider text-slate-700">
                  Polskie Programy Społeczne & Rodzinne (Liczba dzieci)
                </span>
                <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <div>
                    <label htmlFor="benefit-800" className="block text-xs font-semibold text-slate-600">
                      800+ (800 zł / dziecko)
                    </label>
                    <input
                      id="benefit-800"
                      type="number"
                      min="0"
                      max="10"
                      placeholder="0"
                      value={config.benefits800 || ''}
                      onChange={e => onConfigChange({ ...config, benefits800: parseInt(e.target.value, 10) || 0 })}
                      className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-800 outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="benefit-home" className="block text-xs font-semibold text-slate-600">
                      Aktywnie w domu (500 zł)
                    </label>
                    <input
                      id="benefit-home"
                      type="number"
                      min="0"
                      max="10"
                      placeholder="0"
                      value={config.benefitsActiveHome || ''}
                      onChange={e => onConfigChange({ ...config, benefitsActiveHome: parseInt(e.target.value, 10) || 0 })}
                      className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-800 outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="benefit-work" className="block text-xs font-semibold text-slate-600">
                      Aktywni w pracy (1500 zł)
                    </label>
                    <input
                      id="benefit-work"
                      type="number"
                      min="0"
                      max="10"
                      placeholder="0"
                      value={config.benefitsActiveWork || ''}
                      onChange={e => onConfigChange({ ...config, benefitsActiveWork: parseInt(e.target.value, 10) || 0 })}
                      className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-800 outline-none focus:border-blue-500"
                    />
                  </div>
                </div>

                <div className="mt-3">
                  <label htmlFor="other-income" className="block text-xs font-semibold text-slate-600">
                    Inne dochody (premie, zlecenia, dywidendy)
                  </label>
                  <div className="relative mt-1">
                    <input
                      id="other-income"
                      type="number"
                      min="0"
                      step="any"
                      value={config.otherIncome || ''}
                      onChange={e => onConfigChange({ ...config, otherIncome: parseFloat(e.target.value) || 0 })}
                      placeholder="0"
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 pr-12 text-sm font-semibold text-slate-800 outline-none focus:border-blue-500"
                    />
                    <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-xs font-bold text-slate-400">
                      {currency}
                    </span>
                  </div>
                </div>
              </div>

              {/* Tryby strategii budżetowej */}
              <div className="space-y-3 pt-2">
                <span className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  Strategia podziału środków
                </span>

                <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
                  {/* Option 1: Standard 50/20/30 */}
                  <button
                    type="button"
                    onClick={() => onConfigChange({ ...config, rushEmergencyFund: false, customRatiosEnabled: false })}
                    className={`flex flex-col rounded-xl border p-3 text-left transition-all ${
                      !config.rushEmergencyFund && !config.customRatiosEnabled
                        ? 'border-blue-600 bg-blue-50/60 shadow-xs ring-2 ring-blue-600/20'
                        : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-xs font-black text-slate-900">Standard 50/20/30</span>
                    <span className="mt-1 text-xs text-slate-500">50% potrzeby, 20% fun, 30% oszczędności</span>
                  </button>

                  {/* Option 2: Tryb Szybkiej Poduszki */}
                  <button
                    type="button"
                    onClick={() => onConfigChange({ ...config, rushEmergencyFund: true, customRatiosEnabled: false })}
                    className={`flex flex-col rounded-xl border p-3 text-left transition-all ${
                      config.rushEmergencyFund && !config.customRatiosEnabled
                        ? 'border-emerald-600 bg-emerald-50/60 shadow-xs ring-2 ring-emerald-600/20'
                        : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-1 text-xs font-black text-emerald-800">
                      <Zap className="h-3.5 w-3.5 fill-emerald-600 text-emerald-600" />
                      Szybka Poduszka
                    </div>
                    <span className="mt-1 text-xs text-slate-500">50% potrzeby, 40% oszczędności, 10% fun</span>
                  </button>

                  {/* Option 3: Własne Proporcje (PRO) */}
                  <button
                    type="button"
                    onClick={() => {
                      if (!isPremium) {
                        onRequirePremium('Własne proporcje suwaków budżetu');
                        return;
                      }
                      onConfigChange({ ...config, customRatiosEnabled: true, rushEmergencyFund: false });
                    }}
                    className={`flex flex-col rounded-xl border p-3 text-left transition-all ${
                      config.customRatiosEnabled && isPremium
                        ? 'border-indigo-600 bg-indigo-50/60 shadow-xs ring-2 ring-indigo-600/20'
                        : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 text-xs font-black text-indigo-900">
                      <span className="flex items-center gap-1">
                        <Sliders className="h-3.5 w-3.5 text-indigo-600" />
                        Własne Proporcje
                      </span>
                      {!isPremium && (
                        <span className="inline-flex items-center gap-0.5 rounded-full bg-amber-100 px-1.5 py-0.5 text-[9px] font-black text-amber-800">
                          <Crown className="h-2.5 w-2.5 text-amber-600" /> PRO
                        </span>
                      )}
                    </div>
                    <span className="mt-1 text-xs text-slate-500">Dostosuj suwakami pod swoje warunki</span>
                  </button>
                </div>

                {/* Custom sliders if enabled */}
                {config.customRatiosEnabled && isPremium && (
                  <div className="rounded-xl border border-indigo-200 bg-indigo-50/40 p-4 space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold text-indigo-900">
                      <span>Koszty życia (Potrzeby): {config.customNeedsPct}%</span>
                      <span>{Math.round(distribution.totalIncome * (config.customNeedsPct / 100)).toLocaleString('pl-PL')} {currency}</span>
                    </div>
                    <input
                      type="range"
                      min="30"
                      max="75"
                      value={config.customNeedsPct}
                      onChange={e => handleCustomRatioChange('customNeedsPct', parseInt(e.target.value, 10))}
                      className="w-full accent-blue-600"
                    />

                    <div className="flex items-center justify-between text-xs font-bold text-emerald-900">
                      <span>Oszczędności / Inwestycje: {config.customSavingsPct}%</span>
                      <span>{Math.round(distribution.totalIncome * (config.customSavingsPct / 100)).toLocaleString('pl-PL')} {currency}</span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="50"
                      value={config.customSavingsPct}
                      onChange={e => handleCustomRatioChange('customSavingsPct', parseInt(e.target.value, 10))}
                      className="w-full accent-emerald-600"
                    />

                    <div className="flex items-center justify-between text-xs font-bold text-purple-900">
                      <span>Zachcianki (Fun Money): {config.customFunPct}%</span>
                      <span>{Math.round(distribution.totalIncome * (config.customFunPct / 100)).toLocaleString('pl-PL')} {currency}</span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="40"
                      value={config.customFunPct}
                      onChange={e => handleCustomRatioChange('customFunPct', parseInt(e.target.value, 10))}
                      className="w-full accent-purple-600"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right column: Target Allocations & Emergency Fund (5 cols) */}
        <div className="space-y-6 lg:col-span-5">
          {/* Ideal Breakdown Card */}
          <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-xs">
            <h2 className="mb-3 flex items-center justify-between text-lg font-bold text-slate-900">
              <span className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-indigo-600" /> 2. Model Podziału Budżetu
              </span>
              <span className="text-xs font-extrabold text-slate-400">Cele m-ca</span>
            </h2>
            <p className="mb-5 text-xs text-slate-500">
              Sub-limity wyznaczają bezpieczną granicę dla najważniejszych filarów wydatków:
            </p>

            <div className="space-y-4">
              {/* Mieszkanie */}
              <div>
                <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                  <span className="flex items-center gap-1.5"><Home className="h-3.5 w-3.5 text-slate-500" /> Mieszkanie & Opłaty</span>
                  <span>{distribution.housingTarget.toLocaleString('pl-PL')} {currency} (30%)</span>
                </div>
                <div className="mt-1.5 h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full bg-slate-600 transition-all duration-500" style={{ width: '30%' }}></div>
                </div>
              </div>

              {/* Jedzenie */}
              <div>
                <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                  <span className="flex items-center gap-1.5"><Utensils className="h-3.5 w-3.5 text-blue-600" /> Jedzenie & Supermarket</span>
                  <span>{distribution.foodTarget.toLocaleString('pl-PL')} {currency} (15%)</span>
                </div>
                <div className="mt-1.5 h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full bg-blue-600 transition-all duration-500" style={{ width: '15%' }}></div>
                </div>
              </div>

              {/* Transport */}
              <div>
                <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                  <span className="flex items-center gap-1.5"><Car className="h-3.5 w-3.5 text-amber-600" /> Transport & Paliwo</span>
                  <span>{distribution.transportTarget.toLocaleString('pl-PL')} {currency} (5%)</span>
                </div>
                <div className="mt-1.5 h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full bg-amber-500 transition-all duration-500" style={{ width: '5%' }}></div>
                </div>
              </div>

              {/* Raty i Długi */}
              {distribution.loansTarget > 0 && (
                <div>
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                    <span className="flex items-center gap-1.5"><CreditCard className="h-3.5 w-3.5 text-slate-400" /> Raty kredytów & Pożyczki</span>
                    <span>{distribution.loansTarget.toLocaleString('pl-PL')} {currency} ({Math.round((distribution.loansTarget / (distribution.totalIncome || 1)) * 100)}%)</span>
                  </div>
                  <div className="mt-1.5 h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                    <div className="h-full bg-slate-400 transition-all duration-500" style={{ width: '10%' }}></div>
                  </div>
                </div>
              )}

              {/* Inwestycje / Oszczędności */}
              <div className="pt-2">
                <div className="flex items-center justify-between text-xs font-black text-emerald-700">
                  <span className="flex items-center gap-1.5"><PiggyBank className="h-3.5 w-3.5 text-emerald-600" /> Inwestycje & Poduszka</span>
                  <span>{distribution.savingsTarget.toLocaleString('pl-PL')} {currency} ({distribution.savingsPct}%)</span>
                </div>
                <div className="mt-1.5 h-3 w-full overflow-hidden rounded-full bg-emerald-100/70">
                  <div
                    className="h-full bg-emerald-600 transition-all duration-500"
                    style={{ width: `${Math.min(100, distribution.savingsPct)}%` }}
                  ></div>
                </div>
              </div>

              {/* Zachcianki */}
              <div>
                <div className="flex items-center justify-between text-xs font-black text-purple-700">
                  <span className="flex items-center gap-1.5"><PartyPopper className="h-3.5 w-3.5 text-purple-600" /> Zachcianki (Fun Money)</span>
                  <span>{distribution.funTarget.toLocaleString('pl-PL')} {currency} ({distribution.funPct}%)</span>
                </div>
                <div className="mt-1.5 h-3 w-full overflow-hidden rounded-full bg-purple-100/70">
                  <div
                    className="h-full bg-purple-600 transition-all duration-500"
                    style={{ width: `${Math.min(100, distribution.funPct)}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>

          {/* Poduszka Finansowa Configuration */}
          <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-xs">
            <div className="flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-base font-bold text-slate-900">
                <ShieldCheck className="h-5 w-5 text-emerald-600" /> Cel Poduszki Bezpieczeństwa
              </h3>
              <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-bold text-emerald-800">
                {config.emergencyFundMonths} m-cy
              </span>
            </div>

            <p className="mt-2 text-xs text-slate-500">
              Poduszka to suma kosztów przetrwania (Potrzeby) na wypadek utraty dochodu.
            </p>

            <div className="mt-4 flex gap-2">
              {[3, 6, 9, 12].map(m => (
                <button
                  key={m}
                  type="button"
                  onClick={() => onConfigChange({ ...config, emergencyFundMonths: m })}
                  className={`flex-1 rounded-xl py-1.5 text-xs font-bold transition-all ${
                    config.emergencyFundMonths === m
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {m} m-cy
                </button>
              ))}
            </div>

            <div className="mt-4 rounded-xl bg-slate-50 p-3">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
                <span>Rekomendowany cel poduszki:</span>
                <strong className="text-slate-900">{distribution.emergencyFundTarget.toLocaleString('pl-PL')} {currency}</strong>
              </div>
              <div className="mt-2">
                <label htmlFor="current-savings-input" className="block text-xs font-bold text-slate-700">
                  Aktualnie zgromadzone środki bezpieczeństwa:
                </label>
                <div className="relative mt-1">
                  <input
                    id="current-savings-input"
                    type="number"
                    min="0"
                    step="any"
                    placeholder="0"
                    value={config.currentSavings || ''}
                    onChange={e => onConfigChange({ ...config, currentSavings: parseFloat(e.target.value) || 0 })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 pr-12 text-sm font-bold text-slate-900 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
                  />
                  <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-xs font-bold text-slate-400">
                    {currency}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

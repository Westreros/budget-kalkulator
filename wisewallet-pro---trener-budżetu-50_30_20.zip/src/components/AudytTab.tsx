import React, { useState, useMemo } from 'react';
import { HealthAudit, BudgetConfig, BudgetDistribution } from '../types/budget';
import {
  DebtItem,
  calculateDebtPayoffPlan,
  calculateStreakDiscount
} from '../utils/premiumLogic';
import {
  Sparkles,
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  Lightbulb,
  Calculator,
  Layers,
  HeartPulse,
  Snowflake,
  Flame,
  Plus,
  Trash2,
  Crown,
  FileText,
  Printer,
  TrendingDown
} from 'lucide-react';

interface AudytTabProps {
  audit: HealthAudit;
  config: BudgetConfig;
  onConfigChange: (newConfig: BudgetConfig) => void;
  distribution: BudgetDistribution;
  debts: DebtItem[];
  onAddDebt: (debt: Omit<DebtItem, 'id'>) => void;
  onDeleteDebt: (id: string) => void;
  streakDays: number;
  savingsMonthsStreak: number;
}

export const AudytTab: React.FC<AudytTabProps> = ({
  audit,
  config,
  onConfigChange,
  distribution,
  debts,
  onAddDebt,
  onDeleteDebt,
  streakDays,
  savingsMonthsStreak
}) => {
  const currency = config.currency || 'PLN';

  // Debt Strategy state
  const [debtStrategy, setDebtStrategy] = useState<'snowball' | 'avalanche'>('snowball');
  const [newDebtName, setNewDebtName] = useState('');
  const [newDebtBalance, setNewDebtBalance] = useState('');
  const [newDebtRate, setNewDebtRate] = useState('');
  const [newDebtMin, setNewDebtMin] = useState('');

  // Interactive Scenario Simulator state
  const [extraSaveMonthly, setExtraSaveMonthly] = useState<number>(300);
  const [investmentReturnRate, setInvestmentReturnRate] = useState<number>(6);

  const extraDebtPayment = config.extraDebtPayment ?? 400;

  const debtPlan = useMemo(() => {
    return calculateDebtPayoffPlan(debts, extraDebtPayment, debtStrategy);
  }, [debts, extraDebtPayment, debtStrategy]);

  const discountInfo = useMemo(() => {
    return calculateStreakDiscount(streakDays, savingsMonthsStreak, 29);
  }, [streakDays, savingsMonthsStreak]);

  const handleAddDebtSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const bal = parseFloat(newDebtBalance);
    const rate = parseFloat(newDebtRate) || 0;
    const minP = parseFloat(newDebtMin);
    if (!newDebtName.trim() || isNaN(bal) || bal <= 0 || isNaN(minP) || minP <= 0) {
      alert('Podaj nazwę zobowiązania, saldo oraz ratę minimalną.');
      return;
    }
    onAddDebt({
      name: newDebtName.trim(),
      balance: bal,
      interestRate: rate,
      minPayment: minP
    });
    setNewDebtName('');
    setNewDebtBalance('');
    setNewDebtRate('');
    setNewDebtMin('');
  };

  // Compound interest calculation
  const calculateCompoundFuture = (monthly: number, annualRatePct: number, years: number) => {
    const monthlyRate = annualRatePct / 100 / 12;
    const totalMonths = years * 12;
    if (monthlyRate === 0) return monthly * totalMonths;
    return Math.round(monthly * ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate));
  };

  const future1Year = calculateCompoundFuture(extraSaveMonthly, investmentReturnRate, 1);
  const future3Years = calculateCompoundFuture(extraSaveMonthly, investmentReturnRate, 3);
  const future5Years = calculateCompoundFuture(extraSaveMonthly, investmentReturnRate, 5);
  const future10Years = calculateCompoundFuture(extraSaveMonthly, investmentReturnRate, 10);

  const handlePrintPdfReport = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Health Score Hero + PDF Report Export */}
      <div className="rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2">
            <HeartPulse className="h-5 w-5 text-rose-500" />
            <h2 className="text-lg font-bold text-slate-900">
              Audyt Kondycji Portfela & Raport Miesięczny
            </h2>
          </div>

          <button
            type="button"
            onClick={handlePrintPdfReport}
            className="flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-bold text-white shadow-xs transition-all hover:bg-slate-800"
          >
            <Printer className="h-3.5 w-3.5" />
            Eksportuj Raport PDF (Dla Partnera / Banku)
          </button>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-12 items-center">
          <div className="md:col-span-4 flex flex-col items-center justify-center text-center border-b md:border-b-0 md:border-r border-slate-100 pb-6 md:pb-0 md:pr-6">
            <div className="relative flex h-32 w-32 items-center justify-center rounded-full bg-slate-50 border-4 border-slate-100 shadow-inner">
              <div className="text-center">
                <span className="text-4xl font-black tracking-tight text-slate-900">
                  {audit.score}
                </span>
                <span className="block text-xs font-black uppercase text-slate-400">/ 100 pkt</span>
              </div>
            </div>

            <div className="mt-3">
              <span className="inline-block rounded-full bg-blue-100 px-3 py-0.5 text-xs font-black text-blue-800">
                Ocena ogólna: {audit.grade}
              </span>
              <p className="mt-1 text-xs font-semibold text-slate-500">Kondycja Finansowa Portfela</p>
            </div>
          </div>

          <div className="md:col-span-8 space-y-3">
            <p className="text-sm font-medium text-slate-600 leading-relaxed">
              {audit.summary}
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2 sm:grid-cols-4">
              <div className="rounded-xl bg-slate-50 p-3">
                <span className="block text-[11px] font-bold uppercase text-slate-400">Poduszka</span>
                <strong className="text-sm font-black text-slate-900">
                  {audit.metrics.emergencyFundCoverMonths.toFixed(1)} mies.
                </strong>
              </div>
              <div className="rounded-xl bg-slate-50 p-3">
                <span className="block text-[11px] font-bold uppercase text-slate-400">Potrzeby</span>
                <strong className="text-sm font-black text-slate-900">
                  {audit.metrics.actualNeedsRatio.toFixed(0)}%
                </strong>
              </div>
              <div className="rounded-xl bg-slate-50 p-3">
                <span className="block text-[11px] font-bold uppercase text-slate-400">Opłaty stałe</span>
                <strong className="text-sm font-black text-slate-900">
                  {audit.metrics.subscriptionBurdenRatio.toFixed(0)}%
                </strong>
              </div>
              <div className="rounded-xl bg-slate-50 p-3">
                <span className="block text-[11px] font-bold uppercase text-slate-400">Oszczędności</span>
                <strong className="text-sm font-black text-slate-900">
                  {audit.metrics.actualSavingsRatio.toFixed(0)}%
                </strong>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* MODULE 3: Strategia Spłaty Długów (Debt Snowball / Avalanche) */}
      <div className="rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-blue-600" />
              <h3 className="text-lg font-bold text-slate-900">
                Strategia Spłaty Długów (Śnieżna Kula vs Lawina)
              </h3>
            </div>
            <p className="mt-0.5 text-xs text-slate-500">
              Wpisz swoje zobowiązania i zobacz, jak nadpłata skróci czas spłaty i obniży odsetki bankowe.
            </p>
          </div>

          <div className="flex rounded-xl bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setDebtStrategy('snowball')}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                debtStrategy === 'snowball'
                  ? 'bg-white text-blue-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Snowflake className="h-3.5 w-3.5" />
              Śnieżna Kula (Od najmniejszego)
            </button>
            <button
              type="button"
              onClick={() => setDebtStrategy('avalanche')}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                debtStrategy === 'avalanche'
                  ? 'bg-white text-amber-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Flame className="h-3.5 w-3.5" />
              Lawina (Od najdroższego %)
            </button>
          </div>
        </div>

        {/* Highlight Banner */}
        <div className="mb-5 rounded-2xl border border-emerald-200 bg-gradient-to-r from-emerald-50 to-teal-50/60 p-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-emerald-700">
                Efekt planu nadpłat ({debtStrategy === 'snowball' ? 'Metoda Śnieżnej Kuli' : 'Metoda Lawiny'})
              </span>
              <h4 className="mt-1 text-base sm:text-lg font-black text-emerald-950">
                Będziesz wolny od długów{' '}
                <span className="underline decoration-emerald-500">{debtPlan.monthsSaved} mies. wcześniej</span>{' '}
                i zaoszczędzisz{' '}
                <span className="text-emerald-700">
                  {debtPlan.interestSaved.toLocaleString('pl-PL')} {currency}
                </span>{' '}
                na odsetkach!
              </h4>
            </div>
            <div className="text-right">
              <span className="block text-xs font-semibold text-emerald-800">Całkowity czas spłaty:</span>
              <strong className="text-xl font-black text-emerald-900">
                {debtPlan.monthsToPayoff} mies.
              </strong>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-emerald-200/70">
            <div className="flex justify-between text-xs font-bold text-emerald-900">
              <span>Miesięczna kwota dodatkowej nadpłaty ponad raty minimalne:</span>
              <strong>+{extraDebtPayment} {currency} / mc</strong>
            </div>
            <input
              type="range"
              min="0"
              max="3000"
              step="50"
              value={extraDebtPayment}
              onChange={e => onConfigChange({ ...config, extraDebtPayment: parseInt(e.target.value, 10) })}
              className="mt-2 w-full accent-emerald-600"
            />
          </div>
        </div>

        {/* Debts List & Payoff Timeline */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="space-y-2.5 lg:col-span-7">
            <span className="block text-xs font-bold uppercase text-slate-400">
              Harmonogram eliminacji długów (Kolejność spłaty):
            </span>
            {debts.map((debt, index) => {
              const orderInfo = debtPlan.payoffOrder.find(p => p.id === debt.id);
              return (
                <div
                  key={debt.id}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50/70 p-3.5"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 text-[10px] font-black text-white">
                        {index + 1}
                      </span>
                      <strong className="text-sm font-bold text-slate-900">{debt.name}</strong>
                      <span className="rounded-md bg-amber-100 px-2 py-0.5 text-[10px] font-extrabold text-amber-800">
                        {debt.interestRate}% RRSO
                      </span>
                    </div>
                    <span className="block mt-1 text-xs text-slate-500">
                      Saldo: <strong>{debt.balance.toLocaleString('pl-PL')} {currency}</strong> • Rata min.: {debt.minPayment} {currency}/mc
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    {orderInfo && (
                      <div className="text-right">
                        <span className="block rounded-lg bg-emerald-100 px-2.5 py-1 text-xs font-black text-emerald-800">
                          Spłacone w {orderInfo.paidOffInMonth}. m-cu
                        </span>
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={() => onDeleteDebt(debt.id)}
                      className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                      title="Usuń zobowiązanie"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add Debt Form */}
          <form onSubmit={handleAddDebtSubmit} className="space-y-3 rounded-xl border border-slate-200 bg-slate-50/50 p-4 lg:col-span-5">
            <span className="block text-xs font-extrabold uppercase text-slate-700">
              Dodaj kredyt / kartę / ratę
            </span>
            <input
              type="text"
              placeholder="Nazwa (np. Karta kredytowa, Raty 0%)"
              value={newDebtName}
              onChange={e => setNewDebtName(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-800"
            />
            <div className="grid grid-cols-3 gap-2">
              <input
                type="number"
                placeholder="Saldo PLN"
                value={newDebtBalance}
                onChange={e => setNewDebtBalance(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs font-bold text-slate-800"
              />
              <input
                type="number"
                step="0.1"
                placeholder="Oproc. %"
                value={newDebtRate}
                onChange={e => setNewDebtRate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs font-bold text-slate-800"
              />
              <input
                type="number"
                placeholder="Rata min."
                value={newDebtMin}
                onChange={e => setNewDebtMin(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs font-bold text-slate-800"
              />
            </div>
            <button
              type="submit"
              className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-blue-600 py-2 text-xs font-bold text-white hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" /> Dodaj do planu spłaty
            </button>
          </form>
        </div>
      </div>

      {/* MODULE 5: Mechanika Monetyzacji & Paywall (Zniżka za Dyscyplinę) */}
      <div className="rounded-2xl border border-amber-300 bg-gradient-to-br from-amber-50/80 via-white to-orange-50/50 p-6 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="max-w-xl space-y-1.5">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-amber-100 px-3 py-0.5 text-xs font-black text-amber-900">
              <Crown className="h-3.5 w-3.5 text-amber-600" />
              WiseWallet Premium • Zniżka za Dyscyplinę
            </div>
            <h3 className="text-lg font-black text-slate-900">
              Twoja passa bez zachcianek ({streakDays} dni) obniża cenę Premium o -{discountInfo.discountPercent}%!
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Każdy dzień trzymania dyscypliny budżetowej (No-Spend Streak) daje Ci <strong>-2% rabatu</strong> (aż do -50%). Utrzymanie 6 miesięcy celów oszczędnościowych odblokowuje <strong>darmowy miesiąc Premium</strong>.
            </p>
          </div>

          <div className="rounded-2xl border border-amber-200 bg-white p-4 text-center shadow-xs min-w-[210px]">
            <span className="block text-[11px] font-bold uppercase text-slate-400">
              Twoja cena z rabatem
            </span>
            <div className="my-1 flex items-baseline justify-center gap-2">
              <span className="text-xs font-bold text-slate-400 line-through">
                {discountInfo.basePriceMonthly} {currency}
              </span>
              <strong className="text-2xl font-black text-amber-600">
                {discountInfo.finalPriceMonthly} {currency}
              </strong>
              <span className="text-xs font-semibold text-slate-500">/ mc</span>
            </div>
            <span className="block text-[11px] font-bold text-emerald-700">
              Oszczędzasz {discountInfo.savedPerMonth} {currency}/mc za samokontrolę!
            </span>
          </div>
        </div>
      </div>

      {/* Detected Vulnerabilities & Praise */}
      <div className="rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs">
        <h3 className="mb-4 flex items-center gap-2 text-base font-bold text-slate-900">
          <Sparkles className="h-5 w-5 text-blue-600" /> Wykryte Szanse i Ryzyka Budżetowe
        </h3>

        <div className="space-y-3">
          {audit.issues.map(issue => {
            const isCrit = issue.type === 'critical';
            const isWarn = issue.type === 'warning';
            const isPraise = issue.type === 'praise';

            const bgClass = isCrit
              ? 'bg-rose-50/70 border-rose-200 text-rose-950'
              : isWarn
              ? 'bg-amber-50/70 border-amber-200 text-amber-950'
              : isPraise
              ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
              : 'bg-blue-50/70 border-blue-200 text-blue-950';

            const Icon = isCrit
              ? AlertCircle
              : isWarn
              ? AlertTriangle
              : isPraise
              ? CheckCircle2
              : Lightbulb;

            return (
              <div key={issue.id} className={`rounded-xl border p-4 ${bgClass}`}>
                <div className="flex items-start gap-3">
                  <Icon className="mt-0.5 h-5 w-5 shrink-0" />
                  <div className="flex-1">
                    <h4 className="text-sm font-bold">{issue.title}</h4>
                    <p className="mt-1 text-xs font-medium opacity-90 leading-relaxed">
                      {issue.message}
                    </p>
                    {issue.actionRecommendation && (
                      <div className="mt-2 rounded-lg bg-white/70 p-2 text-xs font-bold shadow-2xs">
                        👉 <strong>Rekomendowane działanie:</strong> {issue.actionRecommendation}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Scenario Simulator ("Co Jeśli?") */}
      <div className="rounded-2xl border border-indigo-200 bg-gradient-to-br from-indigo-50/50 via-slate-50 to-white p-6 shadow-xs">
        <div className="mb-4">
          <div className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-indigo-600" />
            <h3 className="text-lg font-bold text-indigo-950">
              Symulator Przyszłości („Co Jeśli?”)
            </h3>
          </div>
          <p className="mt-1 text-xs text-indigo-900/80">
            Zobacz, jak nawet drobna zmiana miesięcznych nawyków i procent składany tworzą majątek.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 items-center">
          <div className="space-y-4 lg:col-span-5">
            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>Dodatkowa miesięczna oszczędność:</span>
                <strong className="text-indigo-600">{extraSaveMonthly} {currency}/mc</strong>
              </div>
              <input
                type="range"
                min="50"
                max="2000"
                step="50"
                value={extraSaveMonthly}
                onChange={e => setExtraSaveMonthly(parseInt(e.target.value, 10))}
                className="mt-2 w-full accent-indigo-600"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>Szacowany zysk roczny (np. ETF / Obligacje skarbowe):</span>
                <strong className="text-emerald-600">{investmentReturnRate}% rocznie</strong>
              </div>
              <input
                type="range"
                min="2"
                max="10"
                step="1"
                value={investmentReturnRate}
                onChange={e => setInvestmentReturnRate(parseInt(e.target.value, 10))}
                className="mt-2 w-full accent-emerald-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 lg:col-span-7 sm:grid-cols-4">
            <div className="rounded-xl border border-indigo-100 bg-white p-3.5 shadow-2xs text-center">
              <span className="block text-[11px] font-bold uppercase text-slate-400">Po 1 roku</span>
              <strong className="mt-1 block text-lg font-black text-indigo-950">
                {future1Year.toLocaleString('pl-PL')} {currency}
              </strong>
            </div>

            <div className="rounded-xl border border-indigo-100 bg-white p-3.5 shadow-2xs text-center">
              <span className="block text-[11px] font-bold uppercase text-slate-400">Po 3 latach</span>
              <strong className="mt-1 block text-lg font-black text-indigo-950">
                {future3Years.toLocaleString('pl-PL')} {currency}
              </strong>
            </div>

            <div className="rounded-xl border border-indigo-100 bg-white p-3.5 shadow-2xs text-center">
              <span className="block text-[11px] font-bold uppercase text-slate-400">Po 5 latach</span>
              <strong className="mt-1 block text-lg font-black text-emerald-600">
                {future5Years.toLocaleString('pl-PL')} {currency}
              </strong>
            </div>

            <div className="rounded-xl border border-indigo-100 bg-white p-3.5 shadow-2xs text-center">
              <span className="block text-[11px] font-bold uppercase text-slate-400">Po 10 latach</span>
              <strong className="mt-1 block text-lg font-black text-emerald-700">
                {future10Years.toLocaleString('pl-PL')} {currency}
              </strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

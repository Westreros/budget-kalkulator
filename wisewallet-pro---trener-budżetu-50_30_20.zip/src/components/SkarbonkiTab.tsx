import React, { useState } from 'react';
import { SavingsGoal, BudgetConfig, BudgetDistribution } from '../types/budget';
import { triggerCoinDrop } from '../utils/coinAnimation';
import confetti from 'canvas-confetti';
import {
  PiggyBank,
  ShieldAlert,
  Plus,
  CheckCircle2,
  TrendingUp,
  Minus,
  Pencil,
  Trash2,
  Trophy,
  Zap
} from 'lucide-react';

interface SkarbonkiTabProps {
  goals: SavingsGoal[];
  config: BudgetConfig;
  distribution: BudgetDistribution;
  onAddGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  onUpdateGoal: (id: string, goal: Partial<SavingsGoal>) => void;
  onDeleteGoal: (id: string) => void;
  onFundGoal: (goalId: string, amount: number) => void;
  onWithdrawGoal: (goalId: string, amount: number) => void;
  onFundEmergency: (amount: number) => void;
  onWithdrawEmergency: (amount: number) => void;
  onRequirePremium: (reason: string) => void;
}

export const SkarbonkiTab: React.FC<SkarbonkiTabProps> = ({
  goals,
  config,
  distribution,
  onAddGoal,
  onUpdateGoal,
  onDeleteGoal,
  onFundGoal,
  onWithdrawGoal,
  onFundEmergency,
  onWithdrawEmergency,
  onRequirePremium
}) => {
  const currency = config.currency || 'PLN';
  const isPremium = Boolean(config.isPremium);
  const freeMaxGoals = 2;

  // Goal Form Modal
  const [goalModalOpen, setGoalModalOpen] = useState(false);
  const [editingGoalId, setEditingGoalId] = useState<string | null>(null);
  const [goalName, setGoalName] = useState('');
  const [goalTarget, setGoalTarget] = useState('');
  const [goalSaved, setGoalSaved] = useState('');

  // Transfer Modal (Deposit / Withdraw)
  const [transferModalOpen, setTransferModalOpen] = useState(false);
  const [transferType, setTransferType] = useState<'deposit' | 'withdraw'>('deposit');
  const [targetGoalId, setTargetGoalId] = useState<string>('EMERGENCY');
  const [transferAmount, setTransferAmount] = useState('');

  // Poduszka calculations
  const emergencyTarget = distribution.emergencyFundTarget;
  const currentEmergencySaved = Math.max(0, Number(config.currentSavings) || 0);
  const emergencyPct = emergencyTarget > 0 ? Math.min(100, Math.round((currentEmergencySaved / emergencyTarget) * 100)) : 0;
  const isEmergencyDone = emergencyTarget > 0 && currentEmergencySaved >= emergencyTarget;
  const monthlySavingsSpeed = distribution.savingsTarget;

  let emergencyTimeLeftText = '';
  if (emergencyTarget === 0) {
    emergencyTimeLeftText = 'Uzupełnij zarobki';
  } else if (isEmergencyDone) {
    emergencyTimeLeftText = 'Cel Osiągnięty! 🎉';
  } else if (monthlySavingsSpeed > 0) {
    const months = Math.ceil((emergencyTarget - currentEmergencySaved) / monthlySavingsSpeed);
    emergencyTimeLeftText = `Osiągniesz za: ${months} ${months === 1 ? 'miesiąc' : months > 1 && months < 5 ? 'miesiące' : 'mies.'}`;
  } else {
    emergencyTimeLeftText = 'Zwiększ oszczędności!';
  }

  const handleOpenAddGoal = () => {
    if (!isPremium && goals.length >= freeMaxGoals) {
      onRequirePremium('Więcej niż 2 Skarbonki (Nielimitowane cele oszczędnościowe)');
      return;
    }
    setEditingGoalId(null);
    setGoalName('');
    setGoalTarget('');
    setGoalSaved('');
    setGoalModalOpen(true);
  };

  const handleOpenEditGoal = (goal: SavingsGoal) => {
    setEditingGoalId(goal.id);
    setGoalName(goal.name);
    setGoalTarget(String(goal.target));
    setGoalSaved(String(goal.saved));
    setGoalModalOpen(true);
  };

  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const target = parseFloat(goalTarget);
    const saved = parseFloat(goalSaved) || 0;
    if (!goalName.trim() || isNaN(target) || target <= 0) {
      alert('Podaj prawidłową nazwę i kwotę docelową.');
      return;
    }

    if (editingGoalId) {
      onUpdateGoal(editingGoalId, { name: goalName.trim(), target, saved });
    } else {
      onAddGoal({ name: goalName.trim(), target, saved });
    }
    setGoalModalOpen(false);
  };

  const handleOpenTransfer = (goalId: string, type: 'deposit' | 'withdraw') => {
    setTargetGoalId(goalId);
    setTransferType(type);
    setTransferAmount('');
    setTransferModalOpen(true);
  };

  const handleExecuteTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(transferAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('Podaj prawidłową kwotę.');
      return;
    }

    if (targetGoalId === 'EMERGENCY') {
      if (transferType === 'deposit') {
        const reached = currentEmergencySaved + amt >= emergencyTarget && emergencyTarget > 0;
        onFundEmergency(amt);
        triggerCoinDrop('emergencyBankIcon', amt, reached);
        if (reached) {
          confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
        }
      } else {
        if (amt > currentEmergencySaved) {
          alert('Nie masz tylu środków w Poduszce Finansowej.');
          return;
        }
        onWithdrawEmergency(amt);
      }
    } else {
      const g = goals.find(x => x.id === targetGoalId);
      if (transferType === 'deposit') {
        const reached = Boolean(g && g.saved + amt >= g.target);
        onFundGoal(targetGoalId, amt);
        triggerCoinDrop(`goalIcon-${targetGoalId}`, amt, reached);
        if (reached) {
          confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
        }
      } else {
        if (g && amt > g.saved) {
          alert('Nie masz tylu środków w tej skarbonce.');
          return;
        }
        onWithdrawGoal(targetGoalId, amt);
      }
    }

    setTransferModalOpen(false);
  };

  const getTargetGoalName = () => {
    if (targetGoalId === 'EMERGENCY') return 'Poduszka Finansowa';
    const g = goals.find(x => x.id === targetGoalId);
    return g ? g.name : 'Skarbonka';
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Emergency Cushion Hero (z animacją monet id="emergencyBankIcon") */}
      <div
        id="emergencyBankIcon"
        className={`relative rounded-2xl border p-6 shadow-sm transition-all ${
          isEmergencyDone
            ? 'border-emerald-300 bg-gradient-to-br from-emerald-50 to-teal-50/40'
            : config.rushEmergencyFund
            ? 'border-2 border-amber-300 bg-amber-50/80'
            : 'border-amber-200/90 bg-gradient-to-br from-amber-50/60 to-orange-50/30'
        }`}
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${isEmergencyDone ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'}`}>
              <ShieldAlert className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-slate-900">
                  Poduszka Finansowa (Emergency Fund)
                </h2>
                {isEmergencyDone && (
                  <span className="flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-black text-emerald-800">
                    <Trophy className="h-3.5 w-3.5" /> Ukończona!
                  </span>
                )}
              </div>
              <p className="text-xs font-semibold text-slate-500">
                Twój żelazny bufor bezpieczeństwa. Wpłaty i wypłaty automatycznie lądują w Dzienniku.
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-2xl font-black text-slate-900">
              {currentEmergencySaved.toLocaleString('pl-PL')}{' '}
              <span className="text-sm font-bold text-slate-500">
                / {emergencyTarget.toLocaleString('pl-PL')} {currency}
              </span>
            </span>
            <span className="block text-xs font-extrabold text-slate-400">
              ({emergencyPct}% celu)
            </span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-4 h-3 w-full overflow-hidden rounded-full bg-slate-200/70">
          <div
            className={`h-full transition-all duration-700 ${
              isEmergencyDone ? 'bg-emerald-600' : 'bg-gradient-to-r from-amber-500 to-orange-500'
            }`}
            style={{ width: `${emergencyPct}%` }}
          ></div>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 pt-2 text-xs font-semibold">
          <span className="flex items-center gap-1.5 text-slate-600">
            <TrendingUp className="h-4 w-4 text-emerald-600" />
            Prędkość: <strong>{monthlySavingsSpeed.toLocaleString('pl-PL')} {currency}/mc</strong>
          </span>

          <span className="rounded-full bg-white/80 px-3 py-1 font-bold text-slate-700 shadow-2xs border border-slate-200/60">
            {emergencyTimeLeftText}
          </span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleOpenTransfer('EMERGENCY', 'deposit')}
              className="flex items-center gap-1 rounded-xl bg-emerald-600 px-3.5 py-1.5 font-bold text-white shadow-xs hover:bg-emerald-700"
            >
              <Plus className="h-3.5 w-3.5" /> Wpłać
            </button>
            <button
              type="button"
              onClick={() => handleOpenTransfer('EMERGENCY', 'withdraw')}
              className="flex items-center gap-1 rounded-xl border border-rose-200 bg-rose-50 px-3 py-1.5 font-bold text-rose-700 hover:bg-rose-100"
            >
              <Minus className="h-3.5 w-3.5" /> Wypłać
            </button>
          </div>
        </div>
      </div>

      {/* Custom Goals Section (ukrywana w Trybie Szybkiej Poduszki 1:1 jak w oryginalnym kodzie) */}
      {config.rushEmergencyFund ? (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6 text-center shadow-xs">
          <Zap className="mx-auto mb-2 h-6 w-6 text-emerald-600" />
          <p className="text-sm font-bold text-emerald-950">
            Tryb Szybkiej Poduszki ukrywa inne cele, pomagając Ci skupić się na bezpieczeństwie.
          </p>
          <p className="mt-1 text-xs text-emerald-800/80">
            Wyłącz „Tryb Szybkiej Poduszki” w Planerze, aby zarządzać dodatkowymi skarbonkami.
          </p>
        </div>
      ) : (
        <div className="rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900">
                  <PiggyBank className="h-5 w-5 text-emerald-600" /> Moje Skarbonki
                </h2>
                {!isPremium && (
                  <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-[11px] font-extrabold text-slate-600">
                    Limit Free: {goals.length}/{freeMaxGoals}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                Przypisz swoje zaoszczędzone środki do konkretnych celów. Wpłaty automatycznie lądują w Twoim Dzienniku.
              </p>
            </div>

            <button
              type="button"
              onClick={handleOpenAddGoal}
              className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" /> + Cel
            </button>
          </div>

          {goals.length === 0 ? (
            <div className="rounded-xl border border-dashed border-slate-200 p-12 text-center text-slate-400">
              <PiggyBank className="mx-auto mb-3 h-10 w-10 text-slate-300" />
              <strong className="block text-sm font-bold text-slate-700">Brak celów oszczędnościowych</strong>
              <p className="mt-1 text-xs text-slate-500">
                Stwórz cel (np. Wakacje w Rzymie) i zmotywuj się do odkładania!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {goals.map(goal => {
              const pct = goal.target > 0 ? Math.min(100, Math.round((goal.saved / goal.target) * 100)) : 0;
              const isDone = goal.target > 0 && goal.saved >= goal.target;

              return (
                <div
                  key={goal.id}
                  id={`goalIcon-${goal.id}`}
                  className={`relative flex flex-col justify-between rounded-2xl border p-5 shadow-xs transition-all ${
                    isDone
                      ? 'border-emerald-300 bg-emerald-50/40'
                      : 'border-slate-200/90 bg-slate-50/50 hover:bg-white hover:border-slate-300 hover:shadow-sm'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-extrabold text-slate-900">{goal.name}</h3>
                        {isDone && <CheckCircle2 className="h-4 w-4 text-emerald-600" />}
                      </div>
                      <span className="text-xs font-black text-slate-400">{pct}%</span>
                    </div>

                    <div className="my-3">
                      <div className="flex items-baseline justify-between text-xs font-semibold text-slate-500">
                        <span>Odłożono:</span>
                        <strong className="text-base font-black text-slate-900">
                          {goal.saved.toLocaleString('pl-PL')}{' '}
                          <span className="text-xs font-semibold text-slate-400">/ {goal.target.toLocaleString('pl-PL')} {currency}</span>
                        </strong>
                      </div>

                      <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-200/70">
                        <div
                          className={`h-full transition-all duration-500 ${isDone ? 'bg-emerald-600' : 'bg-emerald-400'}`}
                          style={{ width: `${pct}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between border-t border-slate-200/70 pt-3">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleOpenTransfer(goal.id, 'deposit')}
                        className="rounded-lg bg-emerald-50 border border-emerald-200 px-2.5 py-1 text-xs font-bold text-emerald-700 hover:bg-emerald-100"
                      >
                        + Wpłać
                      </button>
                      <button
                        type="button"
                        onClick={() => handleOpenTransfer(goal.id, 'withdraw')}
                        className="rounded-lg bg-rose-50 border border-rose-200 px-2.5 py-1 text-xs font-bold text-rose-700 hover:bg-rose-100"
                      >
                        - Wypłać
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleOpenEditGoal(goal)}
                        className="rounded-lg border border-slate-200 p-1.5 text-slate-400 hover:bg-slate-100 hover:text-blue-600"
                        title="Edytuj cel"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Na pewno usunąć ten cel ("${goal.name}")?`)) {
                            onDeleteGoal(goal.id);
                          }
                        }}
                        className="rounded-lg border border-rose-200 p-1.5 text-rose-500 hover:bg-rose-50"
                        title="Usuń cel"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        </div>
      )}

      {/* Goal Add / Edit Modal */}
      {goalModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              {editingGoalId ? 'Edytuj Skarbonkę' : 'Nowa Skarbonka'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Zdefiniuj na co chcesz oszczędzać.
            </p>

            <form onSubmit={handleSaveGoal} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Nazwa celu
                </label>
                <input
                  type="text"
                  placeholder="np. Wakacje w Rzymie"
                  value={goalName}
                  onChange={e => setGoalName(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-semibold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Kwota docelowa ({currency})
                </label>
                <input
                  type="number"
                  min="0.01"
                  step="any"
                  placeholder="np. 5000"
                  value={goalTarget}
                  onChange={e => setGoalTarget(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-bold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Już odłożono ({currency})
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  placeholder="0"
                  value={goalSaved}
                  onChange={e => setGoalSaved(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-bold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setGoalModalOpen(false)}
                  className="rounded-xl px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-emerald-600 px-5 py-2 text-xs font-bold text-white shadow-md shadow-emerald-500/20 hover:bg-emerald-700"
                >
                  Zapisz cel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Transfer Funds Modal */}
      {transferModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-xs rounded-2xl bg-white p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              {transferType === 'deposit' ? 'Zasil Skarbonkę' : 'Wypłać Środki'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Cel: <strong className="text-slate-800">{getTargetGoalName()}</strong>
            </p>

            <form onSubmit={handleExecuteTransfer} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  {transferType === 'deposit' ? `Kwota wpłaty (${currency})` : `Kwota wypłaty (${currency})`}
                </label>
                <input
                  type="number"
                  min="0.01"
                  step="any"
                  placeholder="np. 150"
                  value={transferAmount}
                  onChange={e => setTransferAmount(e.target.value)}
                  autoFocus
                  required
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-base font-black text-slate-900 outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setTransferModalOpen(false)}
                  className="rounded-xl px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  className={`rounded-xl px-5 py-2 text-xs font-bold text-white shadow-md ${
                    transferType === 'deposit'
                      ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20'
                      : 'bg-rose-600 hover:bg-rose-700 shadow-rose-500/20'
                  }`}
                >
                  {transferType === 'deposit' ? 'Potwierdź wpłatę' : 'Potwierdź wypłatę'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { Category, BucketType } from '../types/budget';
import { X, Plus, Trash2, Tags, Info } from 'lucide-react';

interface CategoryManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  onAddCategory: (category: Omit<Category, 'id'>) => void;
  onDeleteCategory: (id: string) => void;
}

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  onClose,
  categories,
  onAddCategory,
  onDeleteCategory
}) => {
  const [newCatName, setNewCatName] = useState('');
  const [newCatBucket, setNewCatBucket] = useState<BucketType>('needs');

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) {
      alert('Wpisz nazwę kategorii.');
      return;
    }
    if (categories.some(c => c.name.toLowerCase() === newCatName.trim().toLowerCase())) {
      alert('Kategoria o tej nazwie już istnieje.');
      return;
    }
    onAddCategory({
      name: newCatName.trim(),
      bucket: newCatBucket,
      isDefault: false
    });
    setNewCatName('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Tags className="h-5 w-5 text-blue-600" />
            <h3 className="text-lg font-bold text-slate-900">Zarządzaj Kategoriami</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="mb-4 text-xs text-slate-500">
          Kategorie definiują, do którego filaru budżetu (Potrzeby 50%, Zachcianki 30%, Oszczędności 20%) trafi dany wydatek.
        </p>

        {/* Existing Categories List */}
        <div className="max-h-60 space-y-2 overflow-y-auto pr-1">
          {categories.map(c => {
            const bucketLabel =
              c.bucket === 'needs'
                ? 'Potrzeby (Koszty życia)'
                : c.bucket === 'fun'
                ? 'Zachcianki (Fun Money)'
                : 'Oszczędności / Inwestycje';

            const badgeColor =
              c.bucket === 'needs'
                ? 'bg-blue-50 text-blue-700 border-blue-200'
                : c.bucket === 'fun'
                ? 'bg-purple-50 text-purple-700 border-purple-200'
                : 'bg-emerald-50 text-emerald-700 border-emerald-200';

            return (
              <div
                key={c.id}
                className="flex items-center justify-between rounded-xl border border-slate-200/80 bg-slate-50/60 p-3"
              >
                <div>
                  <strong className="text-sm font-bold text-slate-900">{c.name}</strong>
                  <span className={`ml-2 inline-block rounded-md border px-2 py-0.5 text-[10px] font-extrabold ${badgeColor}`}>
                    {bucketLabel}
                  </span>
                </div>

                {!c.isDefault && (
                  <button
                    type="button"
                    onClick={() => onDeleteCategory(c.id)}
                    className="rounded-lg p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                    title="Usuń kategorię"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Add New Category Form */}
        <form onSubmit={handleAdd} className="mt-5 border-t border-slate-100 pt-4">
          <label className="block text-xs font-bold uppercase text-slate-700 mb-2">
            Dodaj nową kategorię
          </label>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-12">
            <div className="sm:col-span-6">
              <input
                type="text"
                placeholder="np. Kawiarnie, Gry, Siłownia"
                value={newCatName}
                onChange={e => setNewCatName(e.target.value)}
                className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-800 outline-none focus:border-blue-600"
              />
            </div>
            <div className="sm:col-span-4">
              <select
                value={newCatBucket}
                onChange={e => setNewCatBucket(e.target.value as BucketType)}
                className="w-full rounded-xl border border-slate-300 bg-white px-2 py-2 text-xs font-bold text-slate-800 outline-none focus:border-blue-600"
              >
                <option value="needs">Potrzeby (50%)</option>
                <option value="fun">Zachcianki (30%)</option>
                <option value="savings">Oszczędności (20%)</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <button
                type="submit"
                className="w-full flex items-center justify-center rounded-xl bg-blue-600 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
          </div>
        </form>

        <div className="mt-5 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-slate-900 px-5 py-2 text-xs font-bold text-white shadow-xs hover:bg-slate-800"
          >
            Zamknij
          </button>
        </div>
      </div>
    </div>
  );
};

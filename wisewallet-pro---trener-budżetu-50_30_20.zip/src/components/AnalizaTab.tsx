import React, { useState, useMemo } from 'react';
import { HistoryEntry, Subscription, Category, BudgetConfig, BudgetDistribution } from '../types/budget';
import {
  calculateSinkingFundAllocation,
  getCycleLabelPL,
  isSubDueInMonth,
  POLISH_MONTHS
} from '../utils/calculations';
import {
  Eye,
  Snowflake,
  Flame,
  TrendingUp,
  PartyPopper,
  Coffee,
  FileSearch,
  Clock,
  Crown
} from 'lucide-react';

interface AnalizaTabProps {
  entries: HistoryEntry[];
  subscriptions: Subscription[];
  categories: Category[];
  config: BudgetConfig;
  distribution: BudgetDistribution;
  currentYear: number;
  currentMonth: number;
  rolloverAmount: number;
  savingsMonthsStreak?: number;
}

export const AnalizaTab: React.FC<AnalizaTabProps> = ({
  entries,
  subscriptions,
  categories,
  config,
  distribution,
  currentYear,
  currentMonth,
  rolloverAmount,
  savingsMonthsStreak = 0
}) => {
  const currency = config.currency || 'PLN';
  const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;

  // Select period
  const [selectedPeriod, setSelectedPeriod] = useState<string>(curPeriod);

  const categoryBucketMap = useMemo(() => {
    const map = new Map<string, Category['bucket']>();
    categories.forEach(c => map.set(c.name, c.bucket));
    return map;
  }, [categories]);

  // Unique periods
  const uniquePeriods = useMemo(() => {
    const set = new Set<string>();
    entries.forEach(e => set.add(e.month));
    set.add(curPeriod);
    return Array.from(set).sort().reverse();
  }, [entries, curPeriod]);

  const isCurrentMonth = selectedPeriod === curPeriod;
  const parts = selectedPeriod.split('-');
  const repYear = parseInt(parts[0], 10);
  const repMonth = parseInt(parts[1], 10);

  // Build report items including recorded logs + pending subscriptions + sinking reserves
  const reportData = useMemo(() => {
    const filteredEntries = entries.filter(e => e.month === selectedPeriod);
    const items: Array<{
      id: string;
      category: string;
      name: string;
      amount: number;
      isPending?: boolean;
      sinkingNote?: string;
    }> = [];

    // Add logged entries
    filteredEntries.forEach(entry => {
      const copy = {
        id: entry.id,
        category: entry.category,
        name: entry.name,
        amount: entry.amount,
        isPending: false,
        sinkingNote: ''
      };

      // Check if it's a paid irregular sinking subscription
      const matchedSub = subscriptions.find(
        s => s.cycle !== 'monthly' && (entry.name === `${s.name} (Opłata stała)` || entry.name.includes(s.name))
      );

      if (matchedSub) {
        const alloc = calculateSinkingFundAllocation(matchedSub, repYear, repMonth);
        copy.amount = alloc.monthlyAllocation;
        copy.sinkingNote = `Opłacono ${Number(entry.amount).toLocaleString('pl-PL')} ${currency} • w budżecie m-ca liczona rezerwa (${getCycleLabelPL(matchedSub.cycle)})`;
      }

      items.push(copy);
    });

    // If current month, also add pending subscriptions and sinking fund reserves
    if (isCurrentMonth) {
      subscriptions.forEach(sub => {
        if (sub.lastPaidMonth !== curPeriod) {
          const alloc = calculateSinkingFundAllocation(sub, currentYear, currentMonth);
          const dueNow = isSubDueInMonth(sub, currentMonth);

          let note = '';
          if (sub.cycle === 'monthly') {
            note = 'Oczekująca opłata miesięczna';
          } else if (dueNow) {
            note = `Płatność w tym m-cu (${sub.amount.toLocaleString('pl-PL')} ${currency}) • rezerwa budżetowa: ${alloc.monthlyAllocation.toLocaleString('pl-PL')} ${currency}`;
          } else {
            note = `Rezerwa celowa (${getCycleLabelPL(sub.cycle)}: ${sub.amount.toLocaleString('pl-PL')} ${currency} w m-cu: ${
              POLISH_MONTHS[(sub.dueMonth || 1) - 1]
            })`;
          }

          items.push({
            id: `pending-${sub.id}`,
            category: sub.category,
            name: sub.name,
            amount: alloc.monthlyAllocation,
            isPending: true,
            sinkingNote: note
          });
        }
      });
    }

    let realNeeds = 0;
    let realFun = 0;
    let realSavings = 0;
    let grandTotal = 0;

    items.forEach(item => {
      grandTotal += item.amount;
      const b = categoryBucketMap.get(item.category) || 'needs';
      if (b === 'needs') realNeeds += item.amount;
      else if (b === 'fun') realFun += item.amount;
      else realSavings += item.amount;
    });

    return { items, grandTotal, realNeeds, realFun, realSavings };
  }, [entries, subscriptions, selectedPeriod, isCurrentMonth, repYear, repMonth, curPeriod, currentYear, currentMonth, currency, categoryBucketMap]);

  // Daily allowance calculation for today
  const dailyAllowance = useMemo(() => {
    const idealFun = distribution.funTarget;
    const totalFunWithRollover = idealFun + (isCurrentMonth ? rolloverAmount : 0);
    const leftFun = Math.max(0, totalFunWithRollover - reportData.realFun);

    if (isCurrentMonth) {
      const now = new Date();
      const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
      const daysLeft = Math.max(1, daysInMonth - now.getDate() + 1);
      return {
        amount: Math.round(leftFun / daysLeft),
        subtitle: `Na resztę m-ca (${daysLeft} dni)`
      };
    } else {
      const daysInMonth = new Date(repYear, repMonth, 0).getDate();
      return {
        amount: Math.round(idealFun / daysInMonth),
        subtitle: 'Założenie bazowe'
      };
    }
  }, [distribution.funTarget, isCurrentMonth, rolloverAmount, reportData.realFun, repYear, repMonth]);

  const diffNeeds = reportData.realNeeds - distribution.needsTarget;
  const diffSavings = reportData.realSavings - distribution.savingsTarget;
  const idealFunWithRollover = distribution.funTarget + (isCurrentMonth ? rolloverAmount : 0);
  const leftFunMoney = Math.max(0, idealFunWithRollover - reportData.realFun);
  const streakDisplay = Math.min(6, savingsMonthsStreak);

  return (
    <div className="space-y-6">
      {/* Wyzwanie: Mistrz Oszczędzania (1:1 z premiumChallengeBanner w oryginalnym kodzie) */}
      <div className="rounded-2xl border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-amber-100/70 p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-500 text-white shadow-md shadow-amber-500/20">
              <Crown className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-amber-900">
                Wyzwanie: Mistrz Oszczędzania
              </h3>
              <p className="mt-0.5 text-xs font-medium text-amber-800">
                Utrzymaj swój miesięczny cel oszczędnościowy (100%) przez 6 miesięcy z rzędu, aby odblokować{' '}
                <strong>darmowy miesiąc wersji Premium!</strong>
              </p>
            </div>
          </div>

          <span
            className={`rounded-full px-3.5 py-1 text-xs font-black text-white shadow-2xs ${
              streakDisplay >= 6 ? 'bg-emerald-500' : 'bg-amber-500'
            }`}
          >
            {streakDisplay >= 6 ? 'Zakończone!' : `${streakDisplay}/6 m-cy`}
          </span>
        </div>
      </div>

      {/* Brutal Reality Card */}
      <div className="rounded-2xl border border-fuchsia-200 bg-gradient-to-br from-purple-50/80 via-fuchsia-50/40 to-white p-6 shadow-xs">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-fuchsia-800" />
              <h2 className="text-xl font-black text-fuchsia-950">
                Brutalna Rzeczywistość
              </h2>
              <span className="rounded-full bg-fuchsia-100 px-3 py-0.5 text-[10px] font-extrabold uppercase text-fuchsia-800">
                Zderzenie Danych
              </span>
            </div>
            <p className="mt-1.5 text-xs text-fuchsia-900/90 font-medium leading-relaxed">
              Zestawiamy Twój budżet z wybranym miesiącem.{' '}
              <strong>Oczekujące subskrypcje oraz miesięczne rezerwy na opłaty roczne/kwartalne</strong>{' '}
              blokują tutaj Twoje środki automatycznie!
            </p>
          </div>

          {/* Period selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600">Wybierz okres:</span>
            <select
              value={selectedPeriod}
              onChange={e => setSelectedPeriod(e.target.value)}
              className="rounded-xl border border-fuchsia-300 bg-white px-3.5 py-2 text-xs font-black text-fuchsia-950 shadow-2xs outline-none focus:border-fuchsia-600"
            >
              {uniquePeriods.map(p => {
                const [y, m] = p.split('-');
                return (
                  <option key={p} value={p}>
                    {POLISH_MONTHS[parseInt(m, 10) - 1]} {y}
                  </option>
                );
              })}
            </select>
          </div>
        </div>

        {/* Rollover badge */}
        {isCurrentMonth && rolloverAmount > 0 && (
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-purple-200 bg-purple-100/80 px-4 py-1.5 text-xs font-extrabold text-purple-800 shadow-2xs">
            <Snowflake className="h-4 w-4 text-purple-600 shrink-0" />
            <span>
              Zastosowano Rollover z zeszłego miesiąca: +{rolloverAmount.toLocaleString('pl-PL')} {currency} na Zachcianki
            </span>
          </div>
        )}

        {/* 4 Diagnostic Metric Boxes */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {/* Box 1: Koszty przetrwania */}
          <div className="rounded-xl border border-fuchsia-200/80 bg-white p-4 shadow-2xs flex flex-col justify-between">
            <span className="flex items-center gap-1.5 text-xs font-extrabold uppercase text-fuchsia-900">
              <Flame className="h-4 w-4 text-rose-500" /> Koszty przetrwania
            </span>
            <div className="my-2">
              <span className="text-2xl font-black text-fuchsia-950">
                {reportData.realNeeds.toLocaleString('pl-PL')}{' '}
                <span className="text-sm font-bold text-slate-400">{currency}</span>
              </span>
            </div>
            <div className="flex items-center justify-between border-t border-fuchsia-50 pt-2 text-xs font-semibold">
              <span className="text-slate-500">
                Plan idealny: <strong className="text-slate-900">{distribution.needsTarget.toLocaleString('pl-PL')} {currency}</strong>
              </span>
              <span
                className={`rounded-md px-1.5 py-0.5 font-extrabold ${
                  diffNeeds > 0 ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'
                }`}
              >
                {diffNeeds > 0 ? `+${diffNeeds.toLocaleString('pl-PL')}` : `${diffNeeds.toLocaleString('pl-PL')}`} {currency}
              </span>
            </div>
          </div>

          {/* Box 2: Realnie Zaoszczędzisz */}
          <div className="rounded-xl border border-fuchsia-200/80 bg-white p-4 shadow-2xs flex flex-col justify-between">
            <span className="flex items-center gap-1.5 text-xs font-extrabold uppercase text-fuchsia-900">
              <TrendingUp className="h-4 w-4 text-emerald-600" /> Realnie Zaoszczędzisz
            </span>
            <div className="my-2">
              <span className="text-2xl font-black text-emerald-600">
                {reportData.realSavings.toLocaleString('pl-PL')}{' '}
                <span className="text-sm font-bold text-emerald-600/60">{currency}</span>
              </span>
            </div>
            <div className="flex items-center justify-between border-t border-fuchsia-50 pt-2 text-xs font-semibold">
              <span className="text-slate-500">
                Plan idealny: <strong className="text-slate-900">{distribution.savingsTarget.toLocaleString('pl-PL')} {currency}</strong>
              </span>
              <span
                className={`rounded-md px-1.5 py-0.5 font-extrabold ${
                  diffSavings >= 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                }`}
              >
                {diffSavings >= 0 ? `+${diffSavings.toLocaleString('pl-PL')}` : `${diffSavings.toLocaleString('pl-PL')}`} {currency}
              </span>
            </div>
          </div>

          {/* Box 3: Pozostałe Fun Money */}
          <div className="rounded-xl border border-fuchsia-200/80 bg-white p-4 shadow-2xs flex flex-col justify-between">
            <span className="flex items-center gap-1.5 text-xs font-extrabold uppercase text-fuchsia-900">
              <PartyPopper className="h-4 w-4 text-purple-600" /> Pozostałe Fun Money
            </span>
            <div className="my-2">
              <span className="text-2xl font-black text-purple-600">
                {leftFunMoney.toLocaleString('pl-PL')}{' '}
                <span className="text-sm font-bold text-purple-400">{currency}</span>
              </span>
            </div>
            <div className="flex items-center justify-between border-t border-fuchsia-50 pt-2 text-xs font-semibold">
              <span className="text-slate-500">
                Z budżetu: <strong className="text-slate-900">{idealFunWithRollover.toLocaleString('pl-PL')} {currency}</strong>
              </span>
              <span className="rounded-md bg-slate-100 px-1.5 py-0.5 font-extrabold text-slate-600">
                Wydano {reportData.realFun.toLocaleString('pl-PL')} {currency}
              </span>
            </div>
          </div>

          {/* Box 4: Bezpiecznie na dziś */}
          <div className="rounded-xl border border-fuchsia-200/80 bg-white p-4 shadow-2xs flex flex-col justify-between">
            <span className="flex items-center gap-1.5 text-xs font-extrabold uppercase text-fuchsia-900">
              <Coffee className="h-4 w-4 text-blue-600" /> Bezpiecznie na dziś
            </span>
            <div className="my-2">
              <span className="text-2xl font-black text-blue-600">
                {dailyAllowance.amount.toLocaleString('pl-PL')}{' '}
                <span className="text-sm font-bold text-blue-400">{currency} / dzień</span>
              </span>
            </div>
            <div className="border-t border-fuchsia-50 pt-2 text-xs font-semibold text-slate-500">
              {dailyAllowance.subtitle}
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Detailed Ledger */}
      <div className="rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <FileSearch className="h-5 w-5 text-blue-600" />
            <h3 className="text-lg font-bold text-slate-900">Podsumowanie Miesiąca</h3>
          </div>
        </div>

        <div className="mb-5 flex flex-wrap items-baseline justify-between gap-2 rounded-2xl border border-dashed border-slate-200 bg-slate-50 p-4">
          <span className="text-xs sm:text-sm font-semibold text-slate-500">
            Suma poniesionych i rezerw w tym miesiącu:
          </span>
          <strong className="text-2xl font-black text-slate-900">
            {reportData.grandTotal.toLocaleString('pl-PL')} {currency}
          </strong>
        </div>

        {reportData.items.length === 0 ? (
          <p className="py-8 text-center text-xs text-slate-400">
            Brak wydatków w tym miesiącu. Zanotuj coś w Dzienniku.
          </p>
        ) : (
          <div className="overflow-x-auto rounded-2xl border border-slate-200">
            <table className="w-full text-left text-xs">
              <thead className="border-b-2 border-slate-200 bg-slate-50 font-bold uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="py-3.5 px-4">Kategoria</th>
                  <th className="py-3.5 px-4">Opis wydatku / Opłata</th>
                  <th className="py-3.5 px-4 text-right">Kwota w budżecie m-ca</th>
                  <th className="py-3.5 px-4 text-right">Udział</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dashed divide-slate-200 font-semibold text-slate-700">
                {reportData.items.map(item => {
                  const pct = reportData.grandTotal > 0 ? Math.round((item.amount / reportData.grandTotal) * 100) : 0;
                  const b = categoryBucketMap.get(item.category) || 'needs';
                  const badgeColor =
                    b === 'needs'
                      ? 'bg-blue-50 text-blue-800 border-blue-200'
                      : b === 'fun'
                      ? 'bg-purple-50 text-purple-700 border-purple-200'
                      : 'bg-emerald-50 text-emerald-800 border-emerald-200';

                  return (
                    <tr
                      key={item.id}
                      className={item.isPending ? 'bg-amber-50/70' : 'hover:bg-slate-50/70'}
                    >
                      <td className="py-3.5 px-4">
                        <span className={`inline-block rounded-full border px-2.5 py-0.5 text-[10px] uppercase font-extrabold ${badgeColor}`}>
                          {item.category}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          {item.isPending && <Clock className="h-3.5 w-3.5 text-amber-600 shrink-0" />}
                          <strong className="text-slate-900">{item.name}</strong>
                        </div>
                        {item.sinkingNote && (
                          <span
                            className={`block mt-0.5 text-[11px] font-semibold ${
                              item.isPending ? 'text-amber-700' : 'text-blue-600'
                            }`}
                          >
                            {item.sinkingNote}
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right font-black text-slate-900">
                        {item.amount.toLocaleString('pl-PL')} {currency}
                      </td>
                      <td className="py-3.5 px-4 text-right text-slate-500 font-bold">
                        {pct}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

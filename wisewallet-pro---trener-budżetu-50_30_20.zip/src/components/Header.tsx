import React from 'react';
import { BudgetConfig, HealthAudit } from '../types/budget';
import {
  Download,
  RotateCcw,
  Sparkles,
  Cloud,
  Users,
  CheckCircle2,
  Loader2,
  AlertCircle,
  Crown
} from 'lucide-react';

interface HeaderProps {
  config: BudgetConfig;
  onConfigChange: (newConfig: BudgetConfig) => void;
  audit: HealthAudit;
  onOpenAudit: () => void;
  onOpenBackupModal: () => void;
  onOpenAuthCloudModal: () => void;
  onOpenPaywallModal: () => void;
  onResetDemoData: () => void;
  userEmail: string | null;
  userFullName?: string | null;
  cloudSyncStatus?: 'idle' | 'saving' | 'saved' | 'error';
}

export const Header: React.FC<HeaderProps> = ({
  config,
  onConfigChange,
  audit,
  onOpenAudit,
  onOpenBackupModal,
  onOpenAuthCloudModal,
  onOpenPaywallModal,
  onResetDemoData,
  userEmail,
  userFullName,
  cloudSyncStatus = 'idle'
}) => {
  const getGradeBadge = (grade: HealthAudit['grade']) => {
    switch (grade) {
      case 'A+':
      case 'A':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'B':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'C':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      default:
        return 'bg-rose-50 text-rose-700 border-rose-200';
    }
  };

  const isPremium = Boolean(config.isPremium);
  const isShared = isPremium && config.household?.enabled;
  const displayName = userFullName || userEmail || '';

  const getInitials = (name: string) => {
    if (!name) return 'U';
    if (name.includes('@')) return name.charAt(0).toUpperCase();
    const parts = name.trim().split(' ');
    if (parts.length > 1) {
      return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  return (
    <header className="mb-4 sm:mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-slate-200/80 pb-4 sm:pb-5">
      <div className="flex items-center gap-2.5 sm:gap-3.5">
        {/* Oryginalne logo SVG WiseWallet z gradientem i złotą monetą */}
        <svg
          width="40"
          height="40"
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="h-9 w-9 sm:h-11 sm:w-11 shrink-0 drop-shadow-sm"
        >
          <rect width="100" height="100" rx="28" fill="url(#wiseGrad)" />
          <path
            d="M26 38L40 66L50 48L60 66L74 38"
            stroke="white"
            strokeWidth="10"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="50" cy="34" r="6" fill="#fcd34d" />
          <defs>
            <linearGradient id="wiseGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop stopColor="#2563eb" />
              <stop offset="1" stopColor="#9333ea" />
            </linearGradient>
          </defs>
        </svg>

        <div>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <h1 className="text-xl font-black tracking-tight text-slate-900 sm:text-3xl">
              WiseWallet{' '}
              {isPremium && (
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Pro
                </span>
              )}
            </h1>
            <span className="rounded-full bg-blue-100 px-1.5 sm:px-2 py-0.5 text-[10px] sm:text-xs font-extrabold text-blue-700">
              50/20/30
            </span>
          </div>
          <p className="text-[11px] font-semibold text-slate-500 sm:text-sm">
            {isPremium
              ? 'Twój aktywny trener planu 50/20/30 & sinking funds (Pakiet PRO)'
              : 'Twój aktywny trener planu 50/20/30'}
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {/* Status synchronizacji z chmurą Supabase */}
        {cloudSyncStatus !== 'idle' && (
          <span
            className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-extrabold ${
              cloudSyncStatus === 'saving'
                ? 'bg-slate-100 text-slate-600'
                : cloudSyncStatus === 'saved'
                ? 'bg-emerald-50 text-emerald-700'
                : 'bg-rose-50 text-rose-700'
            }`}
          >
            {cloudSyncStatus === 'saving' && <Loader2 className="h-3 w-3 animate-spin" />}
            {cloudSyncStatus === 'saved' && <CheckCircle2 className="h-3 w-3 text-emerald-600" />}
            {cloudSyncStatus === 'error' && <AlertCircle className="h-3 w-3 text-rose-600" />}
            <span>
              {cloudSyncStatus === 'saving'
                ? 'Zapisuję...'
                : cloudSyncStatus === 'saved'
                ? 'Zapisano w chmurze'
                : 'Błąd zapisu'}
            </span>
          </span>
        )}

        {/* Przycisk statusu planu FREE vs PRO */}
        <button
          type="button"
          onClick={onOpenPaywallModal}
          className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-black shadow-2xs transition-all hover:scale-102 ${
            isPremium
              ? 'border-amber-300 bg-gradient-to-r from-amber-100 to-orange-100 text-amber-950'
              : 'border-amber-400 bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-amber-500/20'
          }`}
          title="Zarządzaj pakietem WiseWallet PRO"
        >
          <Crown className={`h-3.5 w-3.5 ${isPremium ? 'text-amber-600' : 'text-white'}`} />
          <span>{isPremium ? 'PLAN PRO AKTYWNY' : 'Odblokuj PRO'}</span>
        </button>

        {/* Zdrowie finansowe badge (widoczny w PRO) */}
        {isPremium && (
          <button
            type="button"
            onClick={onOpenAudit}
            className={`group flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-xs font-bold transition-all hover:scale-102 hover:shadow-sm ${getGradeBadge(
              audit.grade
            )}`}
            title="Kliknij, aby otworzyć szczegółowy audyt finansowy i plan spłaty długów"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Audyt:</span>
            <span className="rounded-md bg-white/80 px-1.5 py-0.5 font-black shadow-2xs">
              {audit.score}/100 ({audit.grade})
            </span>
          </button>
        )}

        {/* Chmura Supabase (& Wspólny Budżet w PRO) */}
        <button
          type="button"
          onClick={onOpenAuthCloudModal}
          className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-xs font-bold shadow-2xs transition-all ${
            userEmail || isShared
              ? 'border-purple-200 bg-white text-slate-800 hover:border-purple-300'
              : 'border-slate-200 bg-slate-900 text-white hover:bg-slate-800'
          }`}
          title="Logowanie do konta w chmurze Supabase"
        >
          {userEmail ? (
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-br from-sky-400 to-blue-600 text-[10px] font-black text-white">
              {getInitials(displayName)}
            </span>
          ) : isShared ? (
            <Users className="h-3.5 w-3.5 text-purple-600" />
          ) : (
            <Cloud className="h-3.5 w-3.5" />
          )}
          <span className="max-w-[140px] truncate">
            {isShared
              ? `${config.household?.myName} & ${config.household?.partnerName}`
              : userEmail
              ? displayName
              : isPremium
              ? 'Chmura / Para'
              : 'Zaloguj się'}
          </span>
        </button>

        {/* Currency selector (w PRO) */}
        {isPremium && (
          <div className="flex items-center rounded-xl border border-slate-200 bg-white p-0.5 shadow-2xs">
            {(['PLN', 'EUR', 'USD'] as const).map(curr => (
              <button
                key={curr}
                type="button"
                onClick={() => onConfigChange({ ...config, currency: curr })}
                className={`rounded-lg px-2 py-1 text-xs font-bold transition-colors ${
                  config.currency === curr
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {curr}
              </button>
            ))}
          </div>
        )}

        {/* Kopia zapasowa / eksport (w PRO) */}
        {isPremium && (
          <button
            type="button"
            onClick={onOpenBackupModal}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-700 shadow-2xs transition-all hover:border-slate-300 hover:bg-slate-50"
            title="Kopia zapasowa, eksport i import danych"
          >
            <Download className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Kopia / Eksport</span>
          </button>
        )}

        {/* Wczytaj / wyczyść dane przykładowe */}
        <button
          type="button"
          onClick={onResetDemoData}
          className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-500 shadow-2xs transition-all hover:border-slate-300 hover:text-slate-800"
          title="Przełącz między czystym formularzem a danymi demonstracyjnymi"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          <span className="hidden xl:inline">{config.income > 0 ? 'Wyczyść' : 'Demo'}</span>
        </button>
      </div>
    </header>
  );
};


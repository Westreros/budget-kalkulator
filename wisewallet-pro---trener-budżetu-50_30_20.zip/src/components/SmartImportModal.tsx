import React, { useState } from 'react';
import { Category, HistoryEntry } from '../types/budget';
import { parseBankNotification } from '../utils/premiumLogic';
import {
  X,
  Camera,
  MessageSquareText,
  Sparkles,
  CheckCircle2,
  Loader2,
  Receipt,
  Split,
  Wand2
} from 'lucide-react';

interface SmartImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  currency: string;
  activeAuthor?: string;
  onAddEntries: (entries: Omit<HistoryEntry, 'id'>[]) => void;
}

interface ScannedItem {
  name: string;
  amount: number;
  bucket: 'needs' | 'fun';
  suggestedCategory: string;
}

interface ScannedReceiptResult {
  storeName: string;
  date: string;
  items: ScannedItem[];
  needsTotal: number;
  funTotal: number;
  grandTotal: number;
}

const SAMPLE_BANK_MESSAGES = [
  'mBank: Transakcja kartą 148,90 PLN w BIEDRONKA WARSZAWA dnia 24.10.2026.',
  'PKO BP: Płatność BLIK 265,00 PLN w STACJA ORLEN KRAKOW dnia 24.10.2026.',
  'Santander: Obciążenie konta 64,00 PLN w STARBUCKS KAWIARNIA dnia 24.10.2026.'
];

const SAMPLE_RECEIPT_TEXT = `BIEDRONKA "CODZIENNIE NISKIE CENY"
Data: 2026-10-24
-----------------------------------
CHLEB ŻYTNI 500G             5,49 A
MLEKO 3.2% 1L x2             7,98 A
PIERŚ Z KURCZAKA 1KG        24,99 A
POMIDORY MALINOWE           12,40 A
PŁYN DO NACZYŃ FAIRY         9,99 B
CHIPSY LAY'S PAPRYKA         8,49 B
CZEKOLADA MILKA OREO        11,99 B
PIWO ŻYWIEC 4-PAK           19,96 C
COLA ORIGINAL 1.5L           7,49 B
-----------------------------------
SUMA PLN:                  108,78`;

export const SmartImportModal: React.FC<SmartImportModalProps> = ({
  isOpen,
  onClose,
  categories,
  currency,
  activeAuthor,
  onAddEntries
}) => {
  const [mode, setMode] = useState<'ocr' | 'sms'>('ocr');

  // OCR state
  const [scanning, setScanning] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);
  const [scannedResult, setScannedResult] = useState<ScannedReceiptResult | null>(null);

  // SMS state
  const [smsText, setSmsText] = useState<string>(SAMPLE_BANK_MESSAGES[0]);

  if (!isOpen) return null;

  const parsedSms = parseBankNotification(smsText, categories);

  const handleRunOcr = async (payload: { base64Image?: string; mimeType?: string; receiptText?: string }) => {
    setScanning(true);
    setScanError(null);
    try {
      const response = await fetch('/api/scan-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...payload,
          availableCategories: categories.map(c => c.name)
        })
      });
      const data = await response.json();
      if (!response.ok || data.error) {
        throw new Error(data.error || 'Błąd skanowania paragonu');
      }
      setScannedResult(data);
    } catch (err: any) {
      setScanError(err?.message || 'Nie udało się odczytać paragonu.');
    } finally {
      setScanning(false);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const resultStr = String(reader.result || '');
      const base64Data = resultStr.split(',')[1];
      if (base64Data) {
        handleRunOcr({ base64Image: base64Data, mimeType: file.type || 'image/jpeg' });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveScannedReceipt = () => {
    if (!scannedResult || scannedResult.items.length === 0) return;
    const date = scannedResult.date || new Date().toISOString().split('T')[0];
    const parts = date.split('-');
    const month = `${parts[0]}-${parts[1]}`;

    const entriesToSave: Omit<HistoryEntry, 'id'>[] = scannedResult.items.map(item => ({
      exactDate: date,
      month,
      category: item.suggestedCategory || categories[0]?.name || 'Jedzenie & Supermarket',
      name: `${scannedResult.storeName}: ${item.name}`,
      amount: Number(item.amount) || 0,
      addedBy: activeAuthor
    }));

    onAddEntries(entriesToSave);
    setScannedResult(null);
    onClose();
  };

  const handleSaveParsedSms = () => {
    if (!parsedSms.amount || parsedSms.amount <= 0) {
      alert('Nie wykryto kwoty w wiadomości SMS.');
      return;
    }
    const parts = parsedSms.date.split('-');
    const month = `${parts[0]}-${parts[1]}`;

    onAddEntries([
      {
        exactDate: parsedSms.date,
        month,
        category: parsedSms.suggestedCategory,
        name: parsedSms.merchant,
        amount: parsedSms.amount,
        addedBy: activeAuthor
      }
    ]);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-xl rounded-2xl bg-white p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-indigo-600" />
            <h3 className="text-lg font-bold text-slate-900">
              Szybki Import AI (Bez łączenia z bankiem)
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Mode Switcher */}
        <div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setMode('ocr')}
            className={`flex items-center justify-center gap-2 rounded-lg py-2 text-xs font-bold transition-all ${
              mode === 'ocr' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Camera className="h-4 w-4" />
            1. Skaner Paragonów AI (OCR)
          </button>
          <button
            type="button"
            onClick={() => setMode('sms')}
            className={`flex items-center justify-center gap-2 rounded-lg py-2 text-xs font-bold transition-all ${
              mode === 'sms' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MessageSquareText className="h-4 w-4" />
            2. Mostek SMS / Powiadomienia
          </button>
        </div>

        {mode === 'ocr' ? (
          <div className="space-y-4">
            <p className="text-xs text-slate-500 leading-relaxed">
              Zrób zdjęcie długiego paragonu z Biedronki lub Lidla. Sztuczna inteligencja automatycznie oddzieli{' '}
              <strong className="text-blue-700">Potrzeby (jedzenie, chemia)</strong> od{' '}
              <strong className="text-purple-700">Zachcianek (słodycze, przekąski, alkohol)</strong>!
            </p>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-indigo-300 bg-indigo-50/50 p-4 text-center transition-all hover:bg-indigo-100/60">
                <Camera className="h-6 w-6 text-indigo-600" />
                <span className="text-xs font-bold text-indigo-900">
                  Zrób zdjęcie lub wgraj paragon
                </span>
                <span className="text-[10px] text-indigo-600">Obsługuje JPG, PNG, WEBP</span>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>

              <button
                type="button"
                onClick={() => handleRunOcr({ receiptText: SAMPLE_RECEIPT_TEXT })}
                disabled={scanning}
                className="flex flex-col items-center justify-center gap-2 rounded-xl border border-slate-200 bg-slate-50 p-4 text-center transition-all hover:border-indigo-300 hover:bg-indigo-50/30"
              >
                <Wand2 className="h-6 w-6 text-purple-600" />
                <span className="text-xs font-bold text-slate-900">
                  Przetestuj przykładowy paragon
                </span>
                <span className="text-[10px] text-slate-500">
                  Biedronka (108,78 PLN: zakupy + słodycze/piwo)
                </span>
              </button>
            </div>

            {scanning && (
              <div className="flex items-center justify-center gap-2 rounded-xl bg-indigo-50 p-5 text-xs font-bold text-indigo-800">
                <Loader2 className="h-5 w-5 animate-spin text-indigo-600" />
                AI analizuje pozycje z paragonu i dzieli na Potrzeby vs Zachcianki...
              </div>
            )}

            {scanError && (
              <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs font-bold text-rose-700">
                {scanError}
              </div>
            )}

            {scannedResult && (
              <div className="space-y-3 rounded-xl border border-indigo-200 bg-indigo-50/30 p-4">
                <div className="flex items-center justify-between border-b border-indigo-100 pb-2">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase text-indigo-600">
                      Rozpoznany sklep
                    </span>
                    <h4 className="text-sm font-black text-slate-900">
                      {scannedResult.storeName} ({scannedResult.date})
                    </h4>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-slate-500">Suma paragonu:</span>
                    <strong className="block text-base font-black text-slate-900">
                      {scannedResult.grandTotal.toFixed(2)} {currency}
                    </strong>
                  </div>
                </div>

                <div className="space-y-2">
                  {scannedResult.items.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-white p-3 border border-slate-200/80"
                    >
                      <div className="flex-1 min-w-[180px]">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`rounded-md px-2 py-0.5 text-[10px] font-extrabold uppercase ${
                              item.bucket === 'needs'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-purple-100 text-purple-800'
                            }`}
                          >
                            {item.bucket === 'needs' ? 'Potrzeby (50%)' : 'Zachcianki (30%)'}
                          </span>
                          <span className="text-xs font-bold text-slate-800">{item.name}</span>
                        </div>
                        <span className="block mt-1 text-[11px] font-semibold text-slate-400">
                          Kategoria: {item.suggestedCategory}
                        </span>
                      </div>
                      <strong className="text-sm font-black text-slate-900">
                        {Number(item.amount).toFixed(2)} {currency}
                      </strong>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleSaveScannedReceipt}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-2.5 text-xs font-bold text-white shadow-md shadow-indigo-500/20 hover:bg-indigo-700"
                >
                  <Split className="h-4 w-4" />
                  Dodaj rozbity paragon do Dziennika ({scannedResult.items.length} poz.)
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-xs text-slate-500 leading-relaxed">
              Skopiuj i wklej treść powiadomienia z aplikacji bankowej lub SMS-a. Aplikacja sama wyciągnie kwotę, sklep, datę i przypisze kategorię!
            </p>

            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_BANK_MESSAGES.map((msg, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setSmsText(msg)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-[11px] font-semibold text-slate-600 hover:border-blue-400 hover:bg-blue-50 hover:text-blue-700"
                >
                  Przykład #{i + 1}
                </button>
              ))}
            </div>

            <textarea
              rows={3}
              value={smsText}
              onChange={e => setSmsText(e.target.value)}
              placeholder="Wklej tutaj SMS lub powiadomienie z banku..."
              className="w-full rounded-xl border border-slate-300 bg-slate-50 p-3 text-xs font-semibold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
            />

            <div className="rounded-xl border border-blue-200 bg-blue-50/40 p-4 space-y-2">
              <span className="block text-[10px] font-extrabold uppercase text-blue-700">
                Automatycznie rozpoznane dane:
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-lg bg-white p-2.5 border border-blue-100">
                  <span className="block text-[10px] text-slate-400 font-bold">KWOTA</span>
                  <strong className="text-sm font-black text-slate-900">
                    {parsedSms.amount !== null ? `${parsedSms.amount.toFixed(2)} ${currency}` : 'Brak'}
                  </strong>
                </div>
                <div className="rounded-lg bg-white p-2.5 border border-blue-100">
                  <span className="block text-[10px] text-slate-400 font-bold">SKLEP / ODBIORCA</span>
                  <strong className="text-sm font-black text-slate-900 truncate block">
                    {parsedSms.merchant}
                  </strong>
                </div>
                <div className="rounded-lg bg-white p-2.5 border border-blue-100">
                  <span className="block text-[10px] text-slate-400 font-bold">DATA</span>
                  <strong className="text-xs font-bold text-slate-800">{parsedSms.date}</strong>
                </div>
                <div className="rounded-lg bg-white p-2.5 border border-blue-100">
                  <span className="block text-[10px] text-slate-400 font-bold">KATEGORIA</span>
                  <strong className="text-xs font-bold text-blue-700">{parsedSms.suggestedCategory}</strong>
                </div>
              </div>

              <button
                type="button"
                onClick={handleSaveParsedSms}
                disabled={!parsedSms.amount}
                className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-xs font-bold text-white shadow-md shadow-blue-500/20 hover:bg-blue-700 disabled:opacity-50"
              >
                <CheckCircle2 className="h-4 w-4" />
                Dodaj wydatek do Dziennika
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

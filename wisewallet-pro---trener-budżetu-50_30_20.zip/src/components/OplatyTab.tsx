import React, { useState } from 'react';
import { Subscription, Category, BudgetConfig } from '../types/budget';
import {
  calculateSinkingFundAllocation,
  getCycleLabelPL,
  getCycleMonthsCount,
  isSubDueInMonth,
  POLISH_MONTHS
} from '../utils/calculations';
import {
  Repeat,
  BellRing,
  Bell,
  CalendarClock,
  Plus,
  CheckCircle2,
  RotateCcw,
  Pencil,
  Trash2,
  PiggyBank,
  Calculator
} from 'lucide-react';

interface OplatyTabProps {
  subscriptions: Subscription[];
  categories: Category[];
  config: BudgetConfig;
  currentYear: number;
  currentMonth: number;
  onAddSubscription: (sub: Omit<Subscription, 'id'>) => void;
  onUpdateSubscription: (id: string, sub: Partial<Subscription>) => void;
  onDeleteSubscription: (id: string) => void;
  onPaySubscription: (sub: Subscription) => void;
  onUnpaySubscription: (sub: Subscription) => void;
}

export const OplatyTab: React.FC<OplatyTabProps> = ({
  subscriptions,
  categories,
  config,
  currentYear,
  currentMonth,
  onAddSubscription,
  onUpdateSubscription,
  onDeleteSubscription,
  onPaySubscription,
  onUnpaySubscription
}) => {
  const currency = config.currency || 'PLN';
  const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
  const todayDay = new Date().getDate();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [pushStatusMsg, setPushStatusMsg] = useState<string | null>(null);

  // Form fields
  const [name, setName] = useState('');
  const [amount, setAmount] = useState<string>('');
  const [category, setCategory] = useState(categories[0]?.name || '');
  const [dayOfMonth, setDayOfMonth] = useState<number>(10);
  const [cycle, setCycle] = useState<Subscription['cycle']>('monthly');
  const [dueMonth, setDueMonth] = useState<number>(currentMonth);
  const [savedSoFar, setSavedSoFar] = useState<string>('');

  const totalMonthlyBurden = subscriptions.reduce((acc, sub) => {
    const alloc = calculateSinkingFundAllocation(sub, currentYear, currentMonth);
    return acc + alloc.monthlyAllocation;
  }, 0);

  const irregularReservesTotal = subscriptions
    .filter(s => s.cycle !== 'monthly')
    .reduce((acc, sub) => {
      const alloc = calculateSinkingFundAllocation(sub, currentYear, currentMonth);
      return acc + alloc.monthlyAllocation;
    }, 0);

  // Powiadomienia PWA (1:1 z window.requestPushPermissions w oryginalnym kodzie)
  const handleRequestPushPermissions = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setPushStatusMsg('Twoja przeglądarka nie wspiera powiadomień systemowych.');
      return;
    }
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        new Notification('Super!', {
          body: 'Powiadomienia WiseWallet są aktywne. Przypomnimy Ci o rachunkach.',
          icon: 'https://cdn-icons-png.flaticon.com/512/3344/3344055.png'
        });
        setPushStatusMsg('Powiadomienia o rachunkach są aktywne! 🔔');
      } else {
        setPushStatusMsg('Zezwól na powiadomienia w ustawieniach przeglądarki.');
      }
    } catch {
      setPushStatusMsg('Powiadomienia wymagają otwarcia aplikacji w pełnej karcie.');
    }
  };

  const handleOpenAdd = () => {
    setEditingId(null);
    setName('');
    setAmount('');
    setCategory(categories[0]?.name || '');
    setDayOfMonth(10);
    setCycle('monthly');
    setDueMonth(currentMonth);
    setSavedSoFar('');
    setModalOpen(true);
  };

  const handleOpenEdit = (sub: Subscription) => {
    setEditingId(sub.id);
    setName(sub.name);
    setAmount(String(sub.amount));
    setCategory(sub.category);
    setDayOfMonth(sub.dayOfMonth);
    setCycle(sub.cycle);
    setDueMonth(sub.dueMonth || currentMonth);
    setSavedSoFar(sub.savedSoFar ? String(sub.savedSoFar) : '');
    setModalOpen(true);
  };

  const handleSaveSub = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amount);
    if (!name.trim() || isNaN(amt) || amt <= 0) {
      alert('Podaj prawidłową nazwę i kwotę opłaty.');
      return;
    }

    const payload = {
      name: name.trim(),
      amount: amt,
      category,
      dayOfMonth: Math.max(1, Math.min(31, dayOfMonth)),
      cycle,
      dueMonth: cycle !== 'monthly' ? dueMonth : undefined,
      savedSoFar: cycle !== 'monthly' ? parseFloat(savedSoFar) || 0 : 0
    };

    if (editingId) {
      onUpdateSubscription(editingId, payload);
    } else {
      onAddSubscription({
        ...payload,
        createdMonth: curPeriod,
        lastPaidMonth: null
      });
    }

    setModalOpen(false);
  };

  // Podgląd wyliczenia Sinking Fund na żywo (1:1 z updateSubModalPreview w oryginalnym kodzie)
  const previewAllocation = (() => {
    const amt = parseFloat(amount) || 0;
    if (cycle === 'monthly' || amt <= 0) return null;
    const saved = parseFloat(savedSoFar) || 0;
    const tempSub: Subscription = {
      id: 'preview',
      name: name || 'Podgląd',
      amount: amt,
      category,
      dayOfMonth,
      cycle,
      dueMonth,
      savedSoFar: saved,
      createdMonth: curPeriod
    };
    const alloc = calculateSinkingFundAllocation(tempSub, currentYear, currentMonth);
    const standardAllocation = Math.round(amt / getCycleMonthsCount(cycle));
    const needed = Math.max(0, amt - saved);
    const monthName = POLISH_MONTHS[(alloc.nextDueMonth || 1) - 1];
    return {
      ...alloc,
      standardAllocation,
      needed,
      monthName
    };
  })();

  return (
    <div className="space-y-6">
      {/* Hero row metrics (1:1 z oryginalną zakładką 3) */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="rounded-2xl bg-gradient-to-br from-blue-900 to-slate-950 p-6 text-white shadow-lg">
          <span className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-blue-300">
            <Repeat className="h-4 w-4 text-blue-400" /> Miesięczne Obciążenie Opłatami
          </span>
          <div className="my-3 text-3xl font-black tracking-tight text-white">
            {totalMonthlyBurden.toLocaleString('pl-PL')}{' '}
            <span className="text-base font-semibold text-blue-300">
              {currency} / mc
            </span>
          </div>
          <p className="text-xs text-blue-200/90">
            {irregularReservesTotal > 0
              ? `W tym ${irregularReservesTotal.toLocaleString('pl-PL')} ${currency} miesięcznej rezerwy na opłaty roczne/kwartalne.`
              : 'Suma wszystkich opłat miesięcznych.'}
          </p>
        </div>

        {/* Karta Powiadomień PWA z oryginalnego kodu */}
        <div className="rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-slate-500">
                <BellRing className="h-4 w-4 text-blue-600" /> Powiadomienia PWA
              </span>
              <span className="rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-extrabold text-blue-700">
                Alerty o terminach
              </span>
            </div>
            <p className="my-3 text-xs sm:text-sm text-slate-600 font-medium leading-relaxed">
              Aplikacja sprawdza płatności każdego dnia. Wymagane zgody na alerty:
            </p>
          </div>

          <div>
            <button
              type="button"
              onClick={handleRequestPushPermissions}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-blue-200 bg-slate-50 px-4 py-2.5 text-xs font-extrabold text-blue-700 transition-all hover:bg-blue-50 hover:border-blue-300"
            >
              <Bell className="h-4 w-4" />
              Włącz Przypomnienia
            </button>
            {pushStatusMsg && (
              <p className="mt-2 text-center text-xs font-bold text-emerald-700">{pushStatusMsg}</p>
            )}
          </div>
        </div>
      </div>

      {/* Subscriptions Grid */}
      <div className="rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900">
              <CalendarClock className="h-5 w-5 text-blue-600" />{' '}
              {config.isPremium
                ? 'Kalendarz Płatności i Rezerw (Sinking Funds)'
                : 'Kalendarz Stałych Opłat Miesięcznych'}
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              {config.isPremium
                ? 'Dodaj czynsz, Netflixa lub roczne ubezpieczenie OC. Dla opłat rocznych i kwartalnych system automatycznie wylicza i blokuje miesięczną rezerwę w „Analizie”, abyś w miesiącu płatności miał gotówkę bez dziury w budżecie.'
                : 'Dodaj stałe rachunki i subskrypcje oraz wskaż dokładny dzień miesiąca (1–31), kiedy przypada termin płatności.'}
            </p>
          </div>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-blue-700"
          >
            <Plus className="h-4 w-4" />
            Nowa Opłata
          </button>
        </div>

        {subscriptions.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-200 p-12 text-center text-slate-400">
            <Repeat className="mx-auto mb-3 h-10 w-10 text-slate-300" />
            <strong className="block text-sm font-bold text-slate-700">Brak stałych opłat</strong>
            <p className="mt-1 text-xs text-slate-500">
              Dodaj czynsz lub subskrypcje, by otrzymywać przypomnienia i kontrolować rachunki.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {subscriptions
              .slice()
              .sort((a, b) => a.dayOfMonth - b.dayOfMonth)
              .map(sub => {
                const alloc = calculateSinkingFundAllocation(sub, currentYear, currentMonth);
                const isPaid = sub.lastPaidMonth === curPeriod;
                const dueNow = isSubDueInMonth(sub, currentMonth);
                const isIrregular = sub.cycle !== 'monthly';

                let dueLabel: React.ReactNode = '';
                if (sub.cycle === 'monthly') {
                  if (sub.dayOfMonth === todayDay && !isPaid) {
                    dueLabel = <strong className="text-rose-600">Płatność dzisiaj!</strong>;
                  } else {
                    dueLabel = `Co miesiąc • dzień: ${sub.dayOfMonth}`;
                  }
                } else {
                  const mName = POLISH_MONTHS[(alloc.nextDueMonth || 1) - 1];
                  if (dueNow && !isPaid) {
                    dueLabel = (
                      <strong className="text-amber-700">
                        Termin w tym miesiącu ({sub.dayOfMonth}. {mName})!
                      </strong>
                    );
                  } else {
                    dueLabel = `Termin: ${sub.dayOfMonth}. ${mName} ${alloc.nextDueYear} (za ${alloc.monthsUntilDue} m-ce)`;
                  }
                }

                return (
                  <div
                    key={sub.id}
                    className={`relative flex flex-col justify-between rounded-2xl border p-4.5 transition-all shadow-xs ${
                      isPaid
                        ? 'border-slate-200 bg-slate-50/70 opacity-85'
                        : dueNow
                        ? 'border-blue-200 bg-white shadow-sm'
                        : 'border-blue-200/80 bg-white hover:border-blue-300 hover:shadow-sm'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="text-base font-extrabold text-slate-900">{sub.name}</h3>
                          <span className="block mt-0.5 text-xs font-medium text-slate-500">
                            {dueLabel}
                          </span>
                        </div>

                        <div className="text-right">
                          <span className={`text-base font-black ${isIrregular ? 'text-blue-600' : 'text-slate-900'}`}>
                            {(isIrregular ? alloc.monthlyAllocation : sub.amount).toLocaleString('pl-PL')}{' '}
                            <span className="text-xs font-semibold text-slate-400">
                              {isIrregular ? `${currency} / mc` : currency}
                            </span>
                          </span>
                          {isIrregular ? (
                            <span className="block text-[11px] font-bold text-slate-400">
                              Cel: {sub.amount.toLocaleString('pl-PL')} {currency}
                            </span>
                          ) : (
                            <span className="block text-[10px] font-semibold text-slate-400">
                              co miesiąc
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="mt-3 flex flex-wrap items-center gap-1.5">
                        <span className="rounded-full bg-blue-50 border border-blue-200 px-2.5 py-0.5 text-[10px] uppercase font-extrabold text-blue-800">
                          {sub.category}
                        </span>
                        <span
                          className={`rounded-md border px-2 py-0.5 text-[10px] font-extrabold ${
                            isIrregular
                              ? 'bg-amber-100 text-amber-800 border-amber-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}
                        >
                          {getCycleLabelPL(sub.cycle)}
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t border-dashed border-slate-200 pt-3">
                      <div>
                        {isPaid ? (
                          <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-700">
                            <span className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 px-2.5 py-1">
                              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                              Opłacono
                            </span>
                            <button
                              type="button"
                              onClick={() => onUnpaySubscription(sub)}
                              className="rounded-md border border-rose-200 p-1 text-rose-500 hover:bg-rose-50"
                              title="Cofnij płatność"
                            >
                              <RotateCcw className="h-3 w-3" />
                            </button>
                          </div>
                        ) : dueNow ? (
                          <button
                            type="button"
                            onClick={() => onPaySubscription(sub)}
                            className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-extrabold text-white shadow-xs hover:bg-amber-600"
                          >
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Opłać ({sub.amount.toLocaleString('pl-PL')} zł)
                          </button>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs font-extrabold text-blue-800 bg-blue-50 px-2.5 py-1 rounded-lg">
                            <PiggyBank className="h-3.5 w-3.5 text-blue-600" />
                            Rezerwuję {alloc.monthlyAllocation.toLocaleString('pl-PL')} zł/mc
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(sub)}
                          className="rounded-lg bg-slate-100 p-1.5 text-slate-500 hover:bg-slate-200 hover:text-blue-600"
                          title="Edytuj"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteSubscription(sub.id)}
                          className="rounded-lg bg-rose-50 p-1.5 text-rose-600 hover:bg-rose-100"
                          title="Usuń"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        )}
      </div>

      {/* Add / Edit Subscription Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <h3 className="text-lg font-extrabold text-slate-900 mb-1">
              {editingId ? 'Edytuj Opłatę' : 'Nowa Stała Opłata'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              {config.isPremium
                ? 'Dodaj rachunek miesięczny lub wydatek roczny/kwartalny (np. OC), a my wyliczymy miesięczną rezerwę.'
                : 'Wpisz nazwę rachunku, kwotę oraz dokładny dzień miesiąca (1–31), w którym przypada płatność.'}
            </p>

            <form onSubmit={handleSaveSub} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Nazwa (np. Czynsz, Netflix, Internet)
                </label>
                <input
                  type="text"
                  placeholder="np. Netflix, Czynsz"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-semibold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>

              <div className={config.isPremium ? 'grid grid-cols-2 gap-3' : 'grid grid-cols-1 gap-3'}>
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Kwota opłaty ({currency})
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0.01"
                    placeholder="np. 850"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-bold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>

                {config.isPremium && (
                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                      Częstotliwość
                    </label>
                    <select
                      value={cycle}
                      onChange={e => setCycle(e.target.value as Subscription['cycle'])}
                      className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                    >
                      <option value="monthly">Co miesiąc</option>
                      <option value="quarterly">Kwartalnie (co 3 m-ce)</option>
                      <option value="semi_annual">Półrocznie (co 6 m-cy)</option>
                      <option value="annual">Rocznie (raz w roku)</option>
                    </select>
                  </div>
                )}
              </div>

              {/* Pola dla opłat nieregularnych (tylko w wersji PRO) */}
              {config.isPremium && cycle !== 'monthly' && (
                <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-3.5 space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Miesiąc płatności
                      </label>
                      <select
                        value={dueMonth}
                        onChange={e => setDueMonth(parseInt(e.target.value, 10))}
                        className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-800 outline-none"
                      >
                        {POLISH_MONTHS.map((mName, i) => (
                          <option key={i} value={i + 1}>
                            {mName}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Już odłożono ({currency})
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        placeholder="0"
                        value={savedSoFar}
                        onChange={e => setSavedSoFar(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-800 outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Kategoria
                  </label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold text-blue-700 outline-none"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Dzień miesiąca (1-31)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    value={dayOfMonth}
                    onChange={e => setDayOfMonth(parseInt(e.target.value, 10) || 1)}
                    required
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-bold text-slate-800 outline-none"
                  />
                </div>
              </div>

              {/* Podgląd wyliczenia Sinking Fund na żywo (1:1 z sinkingFundPreviewBox w oryginale) */}
              {config.isPremium && previewAllocation && (
                <div className="rounded-xl border border-blue-200 bg-blue-50 p-3 text-xs text-blue-950 leading-relaxed">
                  <Calculator className="inline h-3.5 w-3.5 mr-1 -mt-0.5 text-blue-600" />
                  Najbliższy termin:{' '}
                  <strong>
                    {previewAllocation.monthName} {previewAllocation.nextDueYear}
                  </strong>{' '}
                  (zostało m-cy: <strong>{previewAllocation.monthsUntilDue}</strong>).
                  <br />
                  Aby zebrać brakujące{' '}
                  <strong>
                    {previewAllocation.needed.toLocaleString('pl-PL')} {currency}
                  </strong>
                  , system zarezerwuje w budżecie{' '}
                  <strong>
                    {previewAllocation.monthlyAllocation.toLocaleString('pl-PL')} {currency} / mc
                  </strong>{' '}
                  (po opłaceniu spadnie do{' '}
                  {previewAllocation.standardAllocation.toLocaleString('pl-PL')} {currency} / mc).
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="rounded-xl px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-5 py-2 text-xs font-bold text-white shadow-md shadow-blue-500/20 hover:bg-blue-700"
                >
                  Zapisz opłatę
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

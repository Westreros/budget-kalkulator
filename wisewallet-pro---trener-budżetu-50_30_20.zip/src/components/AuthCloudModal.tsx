import React, { useState } from 'react';
import { BudgetConfig } from '../types/budget';
import { getSupabaseClient } from '../utils/supabaseClient';
import {
  X,
  Cloud,
  Users,
  ShieldCheck,
  LogIn,
  UserPlus,
  Copy,
  Check,
  Sparkles,
  LogOut
} from 'lucide-react';

interface AuthCloudModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: BudgetConfig;
  onConfigChange: (newConfig: BudgetConfig) => void;
  userEmail: string | null;
  onAuthSuccess: (email: string) => void;
  onLogout: () => void;
}

export const AuthCloudModal: React.FC<AuthCloudModalProps> = ({
  isOpen,
  onClose,
  config,
  onConfigChange,
  userEmail,
  onAuthSuccess,
  onLogout
}) => {
  const [activeTab, setActiveTab] = useState<'auth' | 'household'>('auth');
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [statusMsg, setStatusMsg] = useState<{ type: 'error' | 'success' | 'info'; text: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  if (!isOpen) return null;

  const household = config.household || {
    enabled: false,
    myName: 'Marcin',
    partnerName: 'Ania',
    partnerNetIncome: 5500,
    shareCode: 'WW-RODZINA-2026',
    activeAuthor: 'Marcin'
  };

  const handleSocialLogin = async (provider: 'google' | 'apple') => {
    setStatusMsg({ type: 'info', text: `Przekierowywanie do logowania ${provider === 'google' ? 'Google' : 'Apple'}...` });
    const supabase = getSupabaseClient();
    if (!supabase) {
      setStatusMsg({ type: 'error', text: 'Klient Supabase niedostępny.' });
      return;
    }
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: window.location.origin
        }
      });
      if (error) {
        setStatusMsg({ type: 'error', text: `Błąd OAuth: ${error.message}` });
      }
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err?.message || 'Błąd połączenia z dostawcą logowania.' });
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setStatusMsg(null);
    const supabase = getSupabaseClient();
    if (!supabase) {
      setLoading(false);
      setStatusMsg({ type: 'error', text: 'Brak połączenia z Supabase.' });
      return;
    }

    try {
      if (isRegister) {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            data: { full_name: fullName.trim() }
          }
        });
        if (error) {
          setStatusMsg({ type: 'error', text: error.message });
        } else if (data.user) {
          setStatusMsg({ type: 'success', text: 'Konto utworzone! Zalogowano do chmury.' });
          onAuthSuccess(data.user.email || email.trim());
        }
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password
        });
        if (error) {
          setStatusMsg({ type: 'error', text: error.message });
        } else if (data.user) {
          setStatusMsg({ type: 'success', text: 'Zalogowano pomyślnie!' });
          onAuthSuccess(data.user.email || email.trim());
        }
      }
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err?.message || 'Wystąpił błąd autoryzacji.' });
    } finally {
      setLoading(false);
    }
  };

  const handleCopyShareCode = () => {
    navigator.clipboard.writeText(household.shareCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cloud className="h-5 w-5 text-blue-600" />
            <h3 className="text-lg font-bold text-slate-900">
              {config.isPremium ? 'Chmura Supabase & Budżet Par' : 'Konto w Chmurze Supabase'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Sub-tabs (Wspólny Budżet tylko dla PRO) */}
        {config.isPremium && (
          <div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setActiveTab('auth')}
              className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-bold transition-all ${
                activeTab === 'auth' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Cloud className="h-3.5 w-3.5 text-blue-600" />
              Konto & Social Login
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('household')}
              className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-bold transition-all ${
                activeTab === 'household' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="h-3.5 w-3.5 text-purple-600" />
              Wspólny Budżet (2 os.)
            </button>
          </div>
        )}

        {activeTab === 'auth' || !config.isPremium ? (
          <div>
            {userEmail ? (
              <div className="space-y-4 rounded-xl border border-emerald-200 bg-emerald-50/50 p-4 text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-600 text-white font-black text-lg">
                  {userEmail.charAt(0).toUpperCase()}
                </div>
                <div>
                  <span className="text-xs font-bold uppercase text-emerald-700">Połączono z chmurą Supabase</span>
                  <p className="text-sm font-black text-slate-900 mt-0.5">{userEmail}</p>
                </div>
                <button
                  type="button"
                  onClick={onLogout}
                  className="mx-auto flex items-center gap-1.5 rounded-xl border border-rose-200 bg-white px-4 py-2 text-xs font-bold text-rose-600 hover:bg-rose-50"
                >
                  <LogOut className="h-3.5 w-3.5" /> Wyloguj się
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* 1-Click Social Logins */}
                <div className="space-y-2.5">
                  <button
                    type="button"
                    onClick={() => handleSocialLogin('google')}
                    className="flex w-full items-center justify-center gap-2.5 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-bold text-slate-800 shadow-2xs transition-all hover:bg-slate-50"
                  >
                    <svg className="h-4 w-4" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96z"
                      />
                    </svg>
                    Kontynuuj przez Google (1-Klik)
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSocialLogin('apple')}
                    className="flex w-full items-center justify-center gap-2.5 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-bold text-white shadow-2xs transition-all hover:bg-slate-800"
                  >
                    <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
                      <path d="M16.365 1.43c0 1.14-.493 2.27-1.177 3.08-.744.9-1.99 1.57-2.987 1.57-.12 0-.23-.02-.3-.03-.01-.06-.04-.22-.04-.39 0-1.15.572-2.27 1.206-2.98.804-.94 2.142-1.64 3.248-1.68.03.13.05.28.05.43zm4.565 15.71c-.03.07-.463 1.58-1.518 3.12-.945 1.34-1.94 2.71-3.43 2.71-1.517 0-1.9-.88-3.63-.88-1.698 0-2.302.91-3.67.91-1.377 0-2.332-1.26-3.428-2.8-1.287-1.82-2.323-4.63-2.323-7.28 0-4.28 2.797-6.55 5.552-6.55 1.448 0 2.675.95 3.6.95.865 0 2.222-1.01 3.902-1.01.613 0 2.886.06 4.374 2.19-.13.09-2.383 1.37-2.383 4.19 0 3.26 2.854 4.42 2.955 4.45z" />
                    </svg>
                    Kontynuuj przez Apple
                  </button>
                </div>

                <div className="relative flex items-center justify-center py-1">
                  <div className="border-t border-slate-200 w-full"></div>
                  <span className="bg-white px-3 text-[11px] font-bold uppercase text-slate-400">lub e-mail</span>
                  <div className="border-t border-slate-200 w-full"></div>
                </div>

                {statusMsg && (
                  <div
                    className={`rounded-xl p-3 text-xs font-bold ${
                      statusMsg.type === 'error'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : statusMsg.type === 'success'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-blue-50 text-blue-700 border border-blue-200'
                    }`}
                  >
                    {statusMsg.text}
                  </div>
                )}

                <form onSubmit={handleEmailAuth} className="space-y-3">
                  {isRegister && (
                    <input
                      type="text"
                      placeholder="Twoje imię"
                      value={fullName}
                      onChange={e => setFullName(e.target.value)}
                      required
                      className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-semibold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                    />
                  )}
                  <input
                    type="email"
                    placeholder="Adres e-mail"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-semibold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                  />
                  <input
                    type="password"
                    placeholder="Hasło (min. 6 znaków)"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-semibold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                  />

                  <button
                    type="submit"
                    disabled={loading}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-xs font-bold text-white shadow-md shadow-blue-500/20 hover:bg-blue-700 disabled:opacity-50"
                  >
                    {isRegister ? <UserPlus className="h-4 w-4" /> : <LogIn className="h-4 w-4" />}
                    {loading ? 'Łączenie...' : isRegister ? 'Załóż darmowe konto' : 'Zaloguj się'}
                  </button>
                </form>

                <button
                  type="button"
                  onClick={() => setIsRegister(!isRegister)}
                  className="w-full text-center text-xs font-bold text-slate-500 hover:text-slate-800"
                >
                  {isRegister ? 'Masz już konto? Zaloguj się' : 'Nie masz konta? Utwórz je'}
                </button>

                <div className="rounded-xl bg-slate-50 p-3 text-[11px] text-slate-500 flex items-start gap-2">
                  <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>Odporność na AdBlockery (Vercel Proxy):</strong> Ruch do bazy idzie przez <code>/baza/*</code> na Twojej własnej domenie (1st-party), więc uBlock Origin i Brave Shields nigdy go nie zablokują.
                  </span>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="rounded-xl border border-purple-200 bg-purple-50/50 p-3.5">
              <label className="flex cursor-pointer items-center justify-between">
                <div>
                  <span className="block text-xs font-black text-purple-950">
                    Wspólny Worek Budżetowy 50/30/20
                  </span>
                  <span className="text-[11px] text-purple-800">
                    Połącz dwa telefony i sumuj zarobki oraz wydatki pary
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={household.enabled}
                  onChange={e =>
                    onConfigChange({
                      ...config,
                      household: { ...household, enabled: e.target.checked }
                    })
                  }
                  className="h-5 w-5 accent-purple-600 rounded"
                />
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Twoje Imię
                </label>
                <input
                  type="text"
                  value={household.myName}
                  onChange={e =>
                    onConfigChange({
                      ...config,
                      household: { ...household, myName: e.target.value, activeAuthor: e.target.value }
                    })
                  }
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Imię Partnera/ki
                </label>
                <input
                  type="text"
                  value={household.partnerName}
                  onChange={e =>
                    onConfigChange({
                      ...config,
                      household: { ...household, partnerName: e.target.value }
                    })
                  }
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                Pensja netto Partnera/ki ({config.currency})
              </label>
              <input
                type="number"
                min="0"
                step="any"
                value={household.partnerNetIncome || ''}
                onChange={e =>
                  onConfigChange({
                    ...config,
                    household: { ...household, partnerNetIncome: parseFloat(e.target.value) || 0 }
                  })
                }
                className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-sm font-black text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                Kto teraz wprowadza wydatki na tym telefonie?
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[household.myName || 'Ja', household.partnerName || 'Partner'].map(person => (
                  <button
                    key={person}
                    type="button"
                    onClick={() =>
                      onConfigChange({
                        ...config,
                        household: { ...household, activeAuthor: person }
                      })
                    }
                    className={`rounded-xl border py-2 text-xs font-bold transition-all ${
                      household.activeAuthor === person
                        ? 'border-purple-600 bg-purple-600 text-white shadow-xs'
                        : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    👤 {person}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
              <span className="block text-[11px] font-bold uppercase text-slate-400">
                Kod Synchronizacji Rodzinnej (Supabase Realtime Room)
              </span>
              <div className="mt-1.5 flex items-center justify-between gap-2">
                <code className="rounded-lg bg-white px-3 py-1.5 text-xs font-black text-indigo-700 border border-slate-200 flex-1">
                  {household.shareCode}
                </code>
                <button
                  type="button"
                  onClick={handleCopyShareCode}
                  className="flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-indigo-700"
                >
                  {copiedCode ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  {copiedCode ? 'Skopiowano' : 'Kopiuj kod'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

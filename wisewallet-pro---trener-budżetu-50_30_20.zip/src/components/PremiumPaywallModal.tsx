import React from 'react';
import { calculateStreakDiscount } from '../utils/premiumLogic';
import {
  Crown,
  X,
  CheckCircle2,
  Lock,
  Sparkles,
  Flame,
  CreditCard,
  ShieldCheck,
  Split,
  PiggyBank,
  CalendarClock,
  Users,
  TrendingDown,
  FileSpreadsheet
} from 'lucide-react';

interface PremiumPaywallModalProps {
  isOpen: boolean;
  onClose: () => void;
  featureReason?: string | null;
  isPremium: boolean;
  onTogglePremium: (activate: boolean) => void;
  streakDays: number;
  savingsMonthsStreak: number;
  currency: string;
  userEmail?: string | null;
}

export const PremiumPaywallModal: React.FC<PremiumPaywallModalProps> = ({
  isOpen,
  onClose,
  featureReason,
  isPremium,
  onTogglePremium,
  streakDays,
  savingsMonthsStreak,
  currency,
  userEmail
}) => {
  if (!isOpen) return null;

  const discount = calculateStreakDiscount(streakDays, savingsMonthsStreak, 29);

  const handleCheckoutClick = () => {
    const stripeLink = (import.meta as any).env?.VITE_STRIPE_PAYMENT_LINK;
    if (stripeLink) {
      const url = new URL(stripeLink);
      if (userEmail) url.searchParams.set('prefilled_email', userEmail);
      window.location.href = url.toString();
      return;
    }
    // W środowisku podglądu / przed podpięciem produkcyjnego linku Stripe aktywujemy pełny pakiet PRO:
    onTogglePremium(true);
    onClose();
  };

  const proFeatures = [
    {
      icon: Split,
      title: 'Rozbijanie długich paragonów na kategorie',
      desc: 'Jeden rachunek z Biedronki czy Lidla podzielisz na Jedzenie (Potrzeby) i Słodycze/Alkohol (Zachcianki).'
    },
    {
      icon: Sparkles,
      title: 'Skaner Paragonów AI (OCR) & Smart SMS z banku',
      desc: 'Zrób zdjęcie paragonu lub wklej powiadomienie SMS z banku — AI samo rozpozna sklep i kwoty.'
    },
    {
      icon: PiggyBank,
      title: 'Nielimitowane Skarbonki (w darmowym max 2)',
      desc: 'Twórz dowolną liczbę celów oszczędnościowych (Wakacje, Auto, Remont, Święta) bez limitu.'
    },
    {
      icon: CalendarClock,
      title: 'Opłaty Kwartalne, Półroczne i Roczne (Sinking Funds)',
      desc: 'W wersji Free dodasz tylko opłaty miesięczne (dzień 1–31). W PRO system sam odkłada ułamek kwoty na roczne OC czy podatki.'
    },
    {
      icon: Users,
      title: 'Wspólny Budżet Domowy dla Par i Rodzin',
      desc: 'Połącz dwa dochody w jeden worek 50/20/30 i oznaczaj kto dodał dany wydatek.'
    },
    {
      icon: TrendingDown,
      title: 'Strategia Spłaty Długów (Śnieżna Kula vs Lawina) + Suwaki %',
      desc: 'Optymalny harmonogram nadpłat kredytów, własne proporcje budżetu oraz eksport raportów PDF i Excel.'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="relative my-auto w-full max-w-2xl rounded-3xl bg-white p-5 sm:p-7 shadow-2xl border border-amber-200/80 max-h-[92vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full bg-slate-100 p-2 text-slate-500 hover:bg-slate-200 hover:text-slate-800"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2.5">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow-md shadow-amber-500/20">
            <Crown className="h-6 w-6" />
          </div>
          <div>
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-0.5 text-[11px] font-black uppercase tracking-wider text-amber-900">
              WiseWallet PRO
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">
              {featureReason
                ? `Odblokuj: ${featureReason}`
                : 'Pełna automatyzacja i brak limitów z WiseWallet PRO'}
            </h2>
          </div>
        </div>

        {featureReason && (
          <div className="mt-3 flex items-center gap-2 rounded-xl border border-amber-200 bg-amber-50/80 px-3.5 py-2.5 text-xs font-bold text-amber-950">
            <Lock className="h-4 w-4 shrink-0 text-amber-600" />
            <span>
              Funkcja <strong>„{featureReason}”</strong> jest dostępna w pakiecie <strong>WiseWallet PRO</strong>.
            </span>
          </div>
        )}

        {/* Streak Discount Banner */}
        <div className="mt-4 rounded-2xl border border-orange-200 bg-gradient-to-r from-amber-50 via-orange-50/70 to-amber-50 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 text-xs font-black uppercase text-orange-700">
                <Flame className="h-4 w-4 fill-orange-500 text-orange-500" />
                Rabat za Twoją dyscyplinę (Passa: {streakDays} dni bez zachcianek)
              </div>
              <p className="text-xs text-slate-600">
                Każdy dzień bez zachcianek obniża cenę subskrypcji o <strong>-2%</strong> (do -50%).
              </p>
            </div>

            <div className="flex items-baseline gap-2 rounded-xl bg-white px-3.5 py-2 shadow-2xs border border-amber-200">
              {discount.discountPercent > 0 && (
                <span className="text-xs font-bold text-slate-400 line-through">
                  {discount.basePriceMonthly} {currency}
                </span>
              )}
              <strong className="text-2xl font-black text-amber-600">
                {discount.finalPriceMonthly} {currency}
              </strong>
              <span className="text-xs font-bold text-slate-500">/ mies.</span>
              {discount.discountPercent > 0 && (
                <span className="rounded-md bg-emerald-100 px-1.5 py-0.5 text-[10px] font-black text-emerald-800">
                  -{discount.discountPercent}%
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {proFeatures.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div
                key={idx}
                className="flex items-start gap-3 rounded-2xl border border-slate-200/90 bg-slate-50/60 p-3.5"
              >
                <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-blue-600/10 text-blue-600">
                  <Icon className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold text-slate-900">{feat.title}</h4>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-slate-500">{feat.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-100 pt-4">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0" />
            <span>Płatność BLIK / Karta / Apple Pay przez Stripe • Anulujesz w każdej chwili</span>
          </div>

          <div className="flex w-full sm:w-auto items-center gap-2">
            {isPremium ? (
              <button
                type="button"
                onClick={() => {
                  onTogglePremium(false);
                  onClose();
                }}
                className="w-full sm:w-auto rounded-xl border border-slate-300 bg-slate-100 px-4 py-2.5 text-xs font-extrabold text-slate-700 hover:bg-slate-200"
              >
                Przełącz na wersję DARMOWĄ (Test)
              </button>
            ) : (
              <button
                type="button"
                onClick={handleCheckoutClick}
                className="flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 px-6 py-3 text-xs sm:text-sm font-black text-white shadow-lg shadow-amber-500/25 transition-all hover:opacity-95"
              >
                <CreditCard className="h-4 w-4" />
                Odblokuj WiseWallet PRO ({discount.finalPriceMonthly} {currency}/mc)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

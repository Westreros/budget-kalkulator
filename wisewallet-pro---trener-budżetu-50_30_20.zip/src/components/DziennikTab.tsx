import React, { useState, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { HistoryEntry, Category, BudgetConfig, Subscription } from '../types/budget';
import { POLISH_MONTHS } from '../utils/calculations';
import {
  Flame,
  Wallet,
  PenTool,
  Tags,
  PlusCircle,
  XCircle,
  Split,
  FileSpreadsheet,
  Trash2,
  Pencil,
  Search,
  Receipt,
  PieChart as PieIcon,
  ShoppingBag,
  Coffee,
  Car,
  UtensilsCrossed,
  Film,
  Sparkles,
  ChevronDown,
  RotateCcw
} from 'lucide-react';

interface DziennikTabProps {
  entries: HistoryEntry[];
  categories: Category[];
  config: BudgetConfig;
  subscriptions: Subscription[];
  currentYear: number;
  currentMonth: number;
  onAddEntries: (entries: Omit<HistoryEntry, 'id'>[]) => void;
  onUpdateEntry: (id: string, entry: Partial<HistoryEntry>) => void;
  onDeleteEntry: (id: string) => void;
  onOpenCategoryManager: () => void;
  onOpenSmartImport: () => void;
  streak: number;
  streakQuality: 'zero' | 'bronze' | 'silver' | 'gold' | 'flame';
  leftoverFunMoney: number;
  totalFunMonthly: number;
}

interface SplitRow {
  category: string;
  amount: number;
}

const BUCKET_PALETTES: Record<'needs' | 'fun' | 'savings', string[]> = {
  needs: ['#2563eb', '#93c5fd', '#1e3a8a', '#60a5fa', '#172554', '#3b82f6', '#bfdbfe', '#1d4ed8', '#1e40af'],
  fun: ['#9333ea', '#d8b4fe', '#4c1d95', '#c084fc', '#3b0764', '#a855f7', '#e9d5ff', '#7e22ce', '#581c87'],
  savings: ['#10b981', '#6ee7b7', '#064e3b', '#34d399', '#022c22', '#059669', '#a7f3d0', '#047857', '#065f46']
};

export const DziennikTab: React.FC<DziennikTabProps> = ({
  entries,
  categories,
  config,
  currentYear,
  currentMonth,
  onAddEntries,
  onUpdateEntry,
  onDeleteEntry,
  onOpenCategoryManager,
  onOpenSmartImport,
  streak,
  leftoverFunMoney,
  totalFunMonthly
}) => {
  const currency = config.currency || 'PLN';
  const todayStr = new Date().toISOString().split('T')[0];

  // Form state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formDate, setFormDate] = useState<string>(todayStr);
  const [formName, setFormName] = useState<string>('');
  const [primaryCategory, setPrimaryCategory] = useState<string>(categories[0]?.name || '');
  const [primaryAmount, setPrimaryAmount] = useState<string>('');
  const [splitRows, setSplitRows] = useState<SplitRow[]>([]);

  // Filter state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterYear, setFilterYear] = useState<string>(String(currentYear));
  const [filterMonth, setFilterMonth] = useState<string>(String(currentMonth).padStart(2, '0'));
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc' | 'amount_desc'>('desc');

  // Accordion & Interactive Doughnut state (1:1 z oryginalnym openAccordionState)
  const [openAccordionBucket, setOpenAccordionBucket] = useState<'needs' | 'fun' | 'savings' | null>(null);

  const categoryBucketMap = useMemo(() => {
    const map = new Map<string, Category['bucket']>();
    categories.forEach(c => map.set(c.name, c.bucket));
    return map;
  }, [categories]);

  // Quick preset shortcuts for fast expense logging
  const quickPresets = [
    { name: 'Biedronka', cat: 'Jedzenie & Supermarket', icon: ShoppingBag },
    { name: 'Lidl', cat: 'Jedzenie & Supermarket', icon: ShoppingBag },
    { name: 'Stacja Paliw Orlen', cat: 'Transport & Paliwo', icon: Car },
    { name: 'Kawiarnia / Espresso', cat: 'Kawiarnie & Restauracje', icon: Coffee },
    { name: 'Restauracja / Obiad', cat: 'Kawiarnie & Restauracje', icon: UtensilsCrossed },
    { name: 'Bilety do Kina', cat: 'Rozrywka & Kino', icon: Film }
  ];

  const handleApplyPreset = (name: string, catName: string) => {
    setFormName(name);
    if (categories.some(c => c.name === catName)) {
      setPrimaryCategory(catName);
    }
  };

  const handleAddSplitRow = () => {
    setSplitRows(prev => [...prev, { category: categories[0]?.name || '', amount: 0 }]);
  };

  const handleRemoveSplitRow = (index: number) => {
    setSplitRows(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpdateSplitRow = (index: number, field: keyof SplitRow, val: any) => {
    setSplitRows(prev =>
      prev.map((row, i) => (i === index ? { ...row, [field]: val } : row))
    );
  };

  const handleStartEdit = (entry: HistoryEntry) => {
    setEditingId(entry.id);
    setFormDate(entry.exactDate || `${entry.month}-01`);
    setFormName(entry.name);
    setPrimaryCategory(entry.category);
    setPrimaryAmount(String(entry.amount));
    setSplitRows([]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setFormDate(todayStr);
    setFormName('');
    setPrimaryAmount('');
    setSplitRows([]);
  };

  const handleSubmitExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      alert('Wpisz nazwę sklepu lub opis wydatku.');
      return;
    }

    const firstAmt = parseFloat(primaryAmount);
    if (isNaN(firstAmt) || firstAmt <= 0) {
      alert('Podaj kwotę wydatku większą od zera.');
      return;
    }

    const parts = formDate.split('-');
    const y = parts[0];
    const m = parts[1];
    const month = `${y}-${m}`;

    if (editingId) {
      onUpdateEntry(editingId, {
        exactDate: formDate,
        month,
        category: primaryCategory,
        name: formName.trim(),
        amount: firstAmt
      });
      handleCancelEdit();
      return;
    }

    const newEntries: Omit<HistoryEntry, 'id'>[] = [
      {
        exactDate: formDate,
        month,
        category: primaryCategory,
        name: formName.trim(),
        amount: firstAmt
      }
    ];

    splitRows.forEach(row => {
      if (row.amount > 0) {
        newEntries.push({
          exactDate: formDate,
          month,
          category: row.category,
          name: formName.trim(),
          amount: row.amount
        });
      }
    });

    onAddEntries(newEntries);
    handleCancelEdit();
  };

  // Pełny parser plików Excel (.xlsx, .xls, .csv) z oryginalnego kodu (SheetJS / XLSX)
  const handleExcelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      try {
        const buffer = evt.target?.result;
        if (!buffer) return;
        const data = new Uint8Array(buffer as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json<any[]>(worksheet, { header: 1 });

        const d = new Date();
        const pYear = d.getFullYear();
        const pMonth = String(d.getMonth() + 1).padStart(2, '0');
        const defaultMonth = `${pYear}-${pMonth}`;
        const defaultExactDate = `${defaultMonth}-${String(d.getDate()).padStart(2, '0')}`;

        const newItems: Omit<HistoryEntry, 'id'>[] = [];

        for (let r = 0; r < jsonData.length; r++) {
          const row = jsonData[r];
          if (!row || row.length < 2) continue;

          let nameCandidate: string | null = null;
          let amountCandidate: number | null = null;
          let dateCandidate: string = defaultExactDate;
          let categoryCandidate: string | null = null;

          for (let c = 0; c < row.length; c++) {
            const cell = row[c];
            if (cell == null) continue;
            const strVal = String(cell).trim();
            if (!strVal) continue;

            // Sprawdź czy to data YYYY-MM-DD lub DD.MM.YYYY
            if (/^\d{4}-\d{2}-\d{2}$/.test(strVal)) {
              dateCandidate = strVal;
              continue;
            } else if (/^\d{2}\.\d{2}\.\d{4}$/.test(strVal)) {
              const p = strVal.split('.');
              dateCandidate = `${p[2]}-${p[1]}-${p[0]}`;
              continue;
            }

            // Sprawdź czy pasuje do istniejącej kategorii
            if (categories.some(cat => cat.name.toLowerCase() === strVal.toLowerCase())) {
              const matchedCat = categories.find(cat => cat.name.toLowerCase() === strVal.toLowerCase());
              if (matchedCat) categoryCandidate = matchedCat.name;
              continue;
            }

            const cleanedNum = parseFloat(
              strVal
                .replace(/\s+/g, '')
                .replace('zł', '')
                .replace('PLN', '')
                .replace(',', '.')
            );

            if (!isNaN(cleanedNum) && Math.abs(cleanedNum) > 0 && amountCandidate === null) {
              amountCandidate = Math.abs(cleanedNum);
            } else if (isNaN(Number(strVal)) && strVal.length > 1 && nameCandidate === null) {
              nameCandidate = strVal;
            }
          }

          if (nameCandidate && amountCandidate !== null) {
            const low = nameCandidate.toLowerCase();
            if (
              low !== 'nazwa' &&
              low !== 'kategoria' &&
              low !== 'kwota' &&
              low !== 'opis' &&
              low !== 'data'
            ) {
              const dateParts = dateCandidate.split('-');
              const mStr = `${dateParts[0]}-${dateParts[1]}`;
              newItems.push({
                exactDate: dateCandidate,
                month: mStr,
                category: categoryCandidate || (categories.length > 0 ? categories[0].name : 'Inne'),
                name: nameCandidate,
                amount: amountCandidate
              });
            }
          }
        }

        if (newItems.length > 0) {
          onAddEntries(newItems);
          alert(`Wgrano ${newItems.length} rachunków z pliku Excel/CSV!`);
        } else {
          alert('Nie rozpoznałem kwot ani opisów. Sprawdź plik Excel (.xlsx, .xls, .csv).');
        }
      } catch (err) {
        alert('Błąd odczytu pliku Excel/CSV.');
      }
      e.target.value = '';
    };
    reader.readAsArrayBuffer(file);
  };

  // Filtered entries
  const filteredEntries = useMemo(() => {
    return entries
      .filter(entry => {
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = entry.name.toLowerCase().includes(q);
          const matchCat = entry.category.toLowerCase().includes(q);
          if (!matchName && !matchCat) return false;
        }

        if (filterYear !== 'ALL' && !entry.month.startsWith(filterYear)) return false;
        if (filterMonth !== 'ALL' && !entry.month.endsWith(`-${filterMonth}`)) return false;
        if (filterCategory !== 'ALL' && entry.category !== filterCategory) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortOrder === 'desc') return (b.exactDate || b.month).localeCompare(a.exactDate || a.month);
        if (sortOrder === 'asc') return (a.exactDate || a.month).localeCompare(b.exactDate || b.month);
        return b.amount - a.amount;
      });
  }, [entries, searchQuery, filterYear, filterMonth, filterCategory, sortOrder]);

  // Aggregated sums for month breakdown & interactive Doughnut chart
  const monthSums = useMemo(() => {
    const periodEntries = entries.filter(e => {
      const matchY = filterYear === 'ALL' || e.month.startsWith(filterYear);
      const matchM = filterMonth === 'ALL' || e.month.endsWith(`-${filterMonth}`);
      return matchY && matchM;
    });

    const bucketTotals = { needs: 0, fun: 0, savings: 0 };
    const catTotals: Record<'needs' | 'fun' | 'savings', Record<string, number>> = {
      needs: {},
      fun: {},
      savings: {}
    };
    let grandTotal = 0;

    periodEntries.forEach(e => {
      const amt = Number(e.amount) || 0;
      if (amt <= 0) return;
      const b = categoryBucketMap.get(e.category) || 'needs';
      bucketTotals[b] += amt;
      catTotals[b][e.category] = (catTotals[b][e.category] || 0) + amt;
      grandTotal += amt;
    });

    return { grandTotal, bucketTotals, catTotals };
  }, [entries, filterYear, filterMonth, categoryBucketMap]);

  // Toggle accordion bucket (1:1 z window.toggleAccordion w oryginale)
  const toggleAccordion = (bucketId: 'needs' | 'fun' | 'savings') => {
    setOpenAccordionBucket(prev => (prev === bucketId ? null : bucketId));
  };

  // Build slices for the SVG Doughnut Chart
  const chartSlices = useMemo(() => {
    const { grandTotal, bucketTotals, catTotals } = monthSums;
    if (grandTotal <= 0) return [];

    const rawItems: Array<{ label: string; value: number; color: string; bucketId?: 'needs' | 'fun' | 'savings' }> = [];

    if (!openAccordionBucket) {
      if (bucketTotals.needs > 0) {
        rawItems.push({ label: 'Koszty Życia', value: bucketTotals.needs, color: '#3b82f6', bucketId: 'needs' });
      }
      if (bucketTotals.fun > 0) {
        rawItems.push({ label: 'Zachcianki', value: bucketTotals.fun, color: '#a855f7', bucketId: 'fun' });
      }
      if (bucketTotals.savings > 0) {
        rawItems.push({ label: 'Oszczędności', value: bucketTotals.savings, color: '#10b981', bucketId: 'savings' });
      }
    } else {
      const subCats = Object.keys(catTotals[openAccordionBucket]).sort(
        (x, y) => catTotals[openAccordionBucket][y] - catTotals[openAccordionBucket][x]
      );
      const palette = BUCKET_PALETTES[openAccordionBucket];
      subCats.forEach((cName, idx) => {
        rawItems.push({
          label: cName,
          value: catTotals[openAccordionBucket][cName],
          color: palette[idx % palette.length],
          bucketId: openAccordionBucket
        });
      });
    }

    const total = rawItems.reduce((acc, item) => acc + item.value, 0) || 1;
    const radius = 72;
    const circumference = 2 * Math.PI * radius;
    let accumulatedPct = 0;

    return rawItems.map(item => {
      const pct = item.value / total;
      const strokeDasharray = `${Math.max(0, pct * circumference - 2)} ${circumference}`;
      const strokeDashoffset = -accumulatedPct * circumference;
      accumulatedPct += pct;
      return {
        ...item,
        pct: Math.round(pct * 100),
        strokeDasharray,
        strokeDashoffset
      };
    });
  }, [monthSums, openAccordionBucket]);

  // Unique years for filter
  const uniqueYears = useMemo(() => {
    const set = new Set<string>();
    entries.forEach(e => set.add(e.month.split('-')[0]));
    set.add(String(currentYear));
    return Array.from(set).sort().reverse();
  }, [entries, currentYear]);

  const funPctLeft =
    totalFunMonthly > 0
      ? Math.max(0, Math.min(100, Math.round((leftoverFunMoney / totalFunMonthly) * 100)))
      : 0;

  // Dynamiczne kolory kafelka Passy (1:1 z renderHistory w oryginalnym kodzie)
  const streakStyle = useMemo(() => {
    if (streak === 0) {
      return {
        border: 'border-slate-200',
        bg: 'bg-slate-50',
        text: 'text-slate-400',
        bar: 'bg-slate-300'
      };
    }
    if (streak <= 3) {
      return {
        border: 'border-orange-300',
        bg: 'bg-gradient-to-br from-amber-50 to-white',
        text: 'text-orange-400',
        bar: 'bg-orange-400'
      };
    }
    if (streak <= 7) {
      return {
        border: 'border-orange-500',
        bg: 'bg-gradient-to-br from-amber-50 to-white',
        text: 'text-orange-600',
        bar: 'bg-orange-600'
      };
    }
    if (streak <= 14) {
      return {
        border: 'border-orange-600',
        bg: 'bg-gradient-to-br from-orange-100/70 to-white',
        text: 'text-orange-700',
        bar: 'bg-orange-700'
      };
    }
    return {
      border: 'border-orange-700',
      bg: 'bg-gradient-to-br from-orange-100 to-white',
      text: 'text-orange-900',
      bar: 'bg-orange-800'
    };
  }, [streak]);

  const bucketConfig: Array<{ id: 'needs' | 'fun' | 'savings'; name: string; color: string }> = [
    { id: 'needs', name: 'Koszty Życia', color: '#3b82f6' },
    { id: 'fun', name: 'Zachcianki', color: '#a855f7' },
    { id: 'savings', name: 'Oszczędności', color: '#10b981' }
  ];

  return (
    <div className="space-y-6">
      {/* Top Gamification & Allowance Badges */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {/* Passa bez zachcianek (Streak) */}
        <div
          className={`relative overflow-hidden rounded-2xl border-2 p-5 shadow-xs transition-all duration-500 ${streakStyle.border} ${streakStyle.bg}`}
        >
          <div className="flex items-center justify-between">
            <span className={`flex items-center gap-1.5 text-xs font-black uppercase tracking-wider ${streakStyle.text}`}>
              <Flame className={`h-4 w-4 ${streak > 0 ? 'fill-orange-500 text-orange-500 animate-pulse' : 'text-slate-400'}`} />
              Passa bez zachcianek
            </span>
            <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-black text-amber-900">
              {streak >= 14 ? '🔥 Super Mistrz' : streak >= 7 ? '⭐ Złota Passa' : streak >= 3 ? '⚡ Dobry start' : 'Buduj nawyk'}
            </span>
          </div>

          <div className="my-2 flex items-baseline gap-2">
            <span className={`text-3xl font-black tracking-tight ${streakStyle.text}`}>
              {streak} {streak === 1 ? 'Dzień' : 'Dni'}
            </span>
            <span className="text-xs font-medium text-slate-500">bez zbędnych mikro-wydatków</span>
          </div>

          <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-black/5">
            <div
              className={`h-full transition-all duration-700 ${streakStyle.bar}`}
              style={{ width: `${Math.min(100, (streak / 30) * 100)}%` }}
            ></div>
          </div>
        </div>

        {/* Pozostało na Fun Money */}
        <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-blue-700">
              <Wallet className="h-4 w-4 text-blue-600" />
              Pozostało na Zachcianki
            </span>
            <span
              className={`rounded-full px-2 py-0.5 text-xs font-extrabold ${
                funPctLeft > 50
                  ? 'bg-blue-50 text-blue-700'
                  : funPctLeft > 20
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-rose-100 text-rose-800'
              }`}
            >
              {funPctLeft}% budżetu
            </span>
          </div>

          <div className="my-2 flex items-baseline gap-2">
            <span className="text-3xl font-black tracking-tight text-slate-900">
              {leftoverFunMoney.toLocaleString('pl-PL')} <span className="text-lg font-bold text-slate-500">{currency}</span>
            </span>
            <span className="text-xs font-medium text-slate-400">
              z {totalFunMonthly.toLocaleString('pl-PL')} {currency}
            </span>
          </div>

          <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
            <div
              className={`h-full transition-all duration-700 ${
                funPctLeft > 50 ? 'bg-blue-600' : funPctLeft > 20 ? 'bg-amber-500' : 'bg-rose-500'
              }`}
              style={{ width: `${funPctLeft}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Main 2-Column Layout matching original history-top-grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 items-start">
        {/* Left Stack: Form + Table (8 cols) */}
        <div className="space-y-6 lg:col-span-8">
          {/* Add / Edit Expense Card */}
          <div
            className={`rounded-2xl border p-6 transition-all shadow-xs ${
              editingId ? 'border-amber-300 bg-amber-50/40' : 'border-slate-200/90 bg-white'
            }`}
          >
            <div className="mb-2 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <PenTool className="h-5 w-5 text-blue-600" />
                <h2 className="text-lg font-bold text-slate-900">
                  {editingId ? 'Edytujesz wydatek' : 'Dodaj wydatek'}
                </h2>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {config.isPremium && (
                  <button
                    type="button"
                    onClick={onOpenSmartImport}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-3 py-1.5 text-xs font-bold text-white shadow-xs transition-all hover:opacity-95"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    Skaner AI / SMS
                  </button>
                )}

                <button
                  type="button"
                  onClick={onOpenCategoryManager}
                  className="flex items-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-extrabold text-blue-700 transition-colors hover:bg-blue-100"
                >
                  <Tags className="h-3.5 w-3.5" />
                  Kategorie
                </button>
              </div>
            </div>

            <p className="mb-4 text-xs font-medium text-slate-500">
              {config.isPremium
                ? 'Masz długi paragon z marketu? Użyj opcji podziału lub Skanera AI, by dokładnie przypisać kwoty.'
                : 'Zanotuj swój wydatek i przypisz go do odpowiedniej kategorii budżetu.'}
            </p>

            {/* Quick presets buttons */}
            {!editingId && (
              <div className="mb-4 flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold uppercase text-slate-400">Szybki wybór:</span>
                {quickPresets.map(preset => {
                  const Icon = preset.icon;
                  return (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => handleApplyPreset(preset.name, preset.cat)}
                      className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-semibold text-slate-700 transition-colors hover:border-blue-400 hover:bg-blue-50 hover:text-blue-700"
                    >
                      <Icon className="h-3 w-3 text-slate-500" />
                      {preset.name}
                    </button>
                  );
                })}
              </div>
            )}

            <form onSubmit={handleSubmitExpense} className="space-y-4">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-12">
                <div className="sm:col-span-3">
                  <label htmlFor="expense-date" className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Data
                  </label>
                  <input
                    id="expense-date"
                    type="date"
                    value={formDate}
                    onChange={e => setFormDate(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-300 bg-slate-50/60 px-3 py-2 text-sm font-bold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>

                <div className="sm:col-span-4">
                  <label htmlFor="expense-name" className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Nazwa sklepu / Opis
                  </label>
                  <input
                    id="expense-name"
                    type="text"
                    placeholder="Nazwa sklepu (np. Biedronka, Opłaty)"
                    value={formName}
                    onChange={e => setFormName(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-300 bg-slate-50/60 px-3 py-2 text-sm font-semibold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="expense-cat" className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Kategoria
                  </label>
                  <select
                    id="expense-cat"
                    value={primaryCategory}
                    onChange={e => setPrimaryCategory(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 bg-slate-50/60 px-3 py-2 text-sm font-bold text-blue-700 outline-none focus:border-blue-600 focus:bg-white"
                  >
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.name}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="expense-amount" className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Kwota ({currency})
                  </label>
                  <input
                    id="expense-amount"
                    type="number"
                    step="any"
                    min="0.01"
                    placeholder="Kwota"
                    value={primaryAmount}
                    onChange={e => setPrimaryAmount(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-300 bg-slate-50/60 px-3 py-2 text-sm font-black text-slate-900 outline-none focus:border-blue-600 focus:bg-white"
                  />
                </div>
              </div>

              {/* Dynamic Split Rows (tylko w wersji PRO) */}
              {config.isPremium && splitRows.map((split, idx) => (
                <div key={idx} className="flex flex-wrap sm:flex-nowrap items-center gap-3 rounded-xl border border-slate-200 bg-slate-50/80 p-3">
                  <span className="text-xs font-bold text-slate-400">Część #{idx + 2}:</span>
                  <select
                    value={split.category}
                    onChange={e => handleUpdateSplitRow(idx, 'category', e.target.value)}
                    className="flex-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold text-blue-700 outline-none"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    step="any"
                    min="0.01"
                    placeholder="Kwota"
                    value={split.amount || ''}
                    onChange={e => handleUpdateSplitRow(idx, 'amount', parseFloat(e.target.value) || 0)}
                    className="w-32 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold text-slate-900 outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveSplitRow(idx)}
                    className="rounded-lg bg-rose-50 p-1.5 text-rose-600 hover:bg-rose-100"
                    title="Usuń część"
                  >
                    <XCircle className="h-4 w-4" />
                  </button>
                </div>
              ))}

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                {config.isPremium && !editingId && (
                  <button
                    type="button"
                    onClick={handleAddSplitRow}
                    className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-100/80 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200/80 hover:text-slate-900"
                  >
                    <Split className="h-3.5 w-3.5 text-blue-600" />
                    Rozbij paragon na kolejną kategorię
                  </button>
                )}

                <div className="ml-auto flex items-center gap-2">
                  {editingId && (
                    <button
                      type="button"
                      onClick={handleCancelEdit}
                      className="rounded-xl border border-slate-200 bg-slate-100 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200"
                    >
                      Anuluj
                    </button>
                  )}
                  <button
                    type="submit"
                    className="flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-blue-500/20 transition-all hover:bg-blue-700"
                  >
                    {editingId ? <Pencil className="h-4 w-4" /> : <PlusCircle className="h-4 w-4" />}
                    {editingId ? 'Zapisz' : 'Zapisz'}
                  </button>
                </div>
              </div>
            </form>

            {/* Oryginalny boks importu plików Excel (.xlsx, .xls, .csv) */}
            <label
              htmlFor="excelFileInput"
              className="mt-4 flex cursor-pointer items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-blue-300 bg-blue-50/70 p-3.5 text-center text-xs sm:text-sm font-extrabold text-blue-700 transition-all hover:-translate-y-0.5 hover:border-blue-500 hover:bg-blue-100/70"
            >
              <FileSpreadsheet className="h-4 w-4 shrink-0 text-blue-600" />
              <span>Masz starsze dane? Wczytaj plik Excel (.xlsx, .xls, .csv)</span>
              <input
                id="excelFileInput"
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleExcelUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* Filter & Entries Table Card */}
          <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200/80 bg-slate-50 p-3.5">
              <div className="relative flex-1 min-w-[180px]">
                <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Szukaj w Dzienniku..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-white py-2 pl-9 pr-3 text-xs font-semibold text-slate-800 outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={filterYear}
                  onChange={e => setFilterYear(e.target.value)}
                  className="rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-800 outline-none"
                >
                  <option value="ALL">Wszystkie lata</option>
                  {uniqueYears.map(y => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>

                <select
                  value={filterMonth}
                  onChange={e => setFilterMonth(e.target.value)}
                  className="rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-800 outline-none"
                >
                  <option value="ALL">Wszystkie miesiące</option>
                  {POLISH_MONTHS.map((mName, idx) => (
                    <option key={idx} value={String(idx + 1).padStart(2, '0')}>
                      {mName}
                    </option>
                  ))}
                </select>

                <select
                  value={filterCategory}
                  onChange={e => setFilterCategory(e.target.value)}
                  className="rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-blue-700 outline-none"
                >
                  <option value="ALL">Wszystkie kategorie</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>

                <select
                  value={sortOrder}
                  onChange={e => setSortOrder(e.target.value as any)}
                  className="rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-800 outline-none"
                >
                  <option value="desc">Od najnowszych</option>
                  <option value="asc">Od najstarszych</option>
                  <option value="amount_desc">Od najwyższej kwoty</option>
                </select>
              </div>
            </div>

            <div className="flex items-baseline justify-between px-1">
              <span className="text-xs sm:text-sm font-semibold text-slate-500">
                Suma widocznych z filtrem ({filteredEntries.length}):
              </span>
              <strong className="text-lg font-black text-slate-900">
                {filteredEntries.reduce((acc, curr) => acc + Number(curr.amount), 0).toLocaleString('pl-PL')} {currency}
              </strong>
            </div>

            {/* Transactions List */}
            <div className="overflow-hidden rounded-2xl border border-slate-200/90 bg-white">
              {filteredEntries.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-12 text-center text-slate-400">
                  <Receipt className="mb-3 h-12 w-12 text-slate-300" />
                  <strong className="text-base font-bold text-slate-700">Brak wydatków na liście</strong>
                  <p className="mt-1 text-xs text-slate-500">Zanotuj swój pierwszy wydatek u góry.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {filteredEntries.map(entry => {
                    const bucket = categoryBucketMap.get(entry.category) || 'needs';
                    const badgeColor =
                      bucket === 'needs'
                        ? 'bg-blue-50 text-blue-800 border-blue-200'
                        : bucket === 'fun'
                        ? 'bg-purple-50 text-purple-700 border-purple-200'
                        : 'bg-emerald-50 text-emerald-800 border-emerald-200';

                    return (
                      <div
                        key={entry.id}
                        className="flex flex-wrap items-center justify-between gap-3 p-4 transition-colors hover:bg-slate-50/70"
                      >
                        <div className="flex items-center gap-3">
                          <div className="text-center font-extrabold min-w-[72px]">
                            <span className="block text-xs text-slate-700">
                              {entry.exactDate || entry.month}
                            </span>
                          </div>

                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-sm font-bold text-slate-900">{entry.name}</span>
                              {entry.isSubscription && (
                                <span className="rounded-md bg-amber-100 px-1.5 py-0.5 text-[10px] font-black text-amber-800">
                                  Opłata stała
                                </span>
                              )}
                              {entry.addedBy && (
                                <span className="rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-600">
                                  👤 {entry.addedBy}
                                </span>
                              )}
                            </div>
                            <span
                              className={`inline-block mt-1 rounded-full border px-2.5 py-0.5 text-[10px] uppercase tracking-wider font-extrabold ${badgeColor}`}
                            >
                              {entry.category}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="text-base font-black text-slate-900">
                            {Number(entry.amount).toLocaleString('pl-PL')} {currency}
                          </span>

                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleStartEdit(entry)}
                              className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition-transform hover:scale-105"
                              title="Edytuj"
                            >
                              <Pencil className="h-4 w-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onDeleteEntry(entry.id)}
                              className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition-transform hover:scale-105"
                              title="Usuń"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Interactive Doughnut Chart & Accordion Legend (1:1 z chart-card-side w oryginale) */}
        <div className="lg:col-span-4">
          <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs">
            <h3 className="mb-1 flex items-center gap-2 text-base font-extrabold text-slate-900">
              <PieIcon className="h-5 w-5 text-blue-600" /> Podsumowanie Budżetu
            </h3>
            <p
              className={`mb-4 text-xs font-medium ${
                openAccordionBucket ? 'text-blue-600 font-bold' : 'text-slate-500'
              }`}
            >
              {openAccordionBucket
                ? 'Kliknij wykres, by wrócić do ogółu.'
                : 'Kliknij wykres, by rozwinąć szczegóły. Wybierz z legendy, by filtrować.'}
            </p>

            {monthSums.grandTotal > 0 ? (
              <div>
                {/* Interactive SVG Doughnut Chart */}
                <div className="relative mx-auto my-2 flex h-52 w-52 items-center justify-center">
                  <svg
                    viewBox="0 0 180 180"
                    className="h-full w-full -rotate-90 transform cursor-pointer"
                    onClick={() => {
                      if (openAccordionBucket) {
                        setOpenAccordionBucket(null);
                      }
                    }}
                  >
                    {chartSlices.map((slice, idx) => (
                      <circle
                        key={slice.label + idx}
                        cx="90"
                        cy="90"
                        r="72"
                        fill="transparent"
                        stroke={slice.color}
                        strokeWidth="24"
                        strokeDasharray={slice.strokeDasharray}
                        strokeDashoffset={slice.strokeDashoffset}
                        className="transition-all duration-300 hover:opacity-85"
                        onClick={e => {
                          e.stopPropagation();
                          if (openAccordionBucket) {
                            setOpenAccordionBucket(null);
                          } else if (slice.bucketId) {
                            toggleAccordion(slice.bucketId);
                          }
                        }}
                      >
                        <title>
                          {slice.label}: {slice.value.toLocaleString('pl-PL')} {currency} ({slice.pct}%)
                        </title>
                      </circle>
                    ))}
                  </svg>

                  {/* Center info inside Doughnut */}
                  <div
                    onClick={() => {
                      if (openAccordionBucket) setOpenAccordionBucket(null);
                    }}
                    className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center px-4"
                  >
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                      {openAccordionBucket === 'needs'
                        ? 'Koszty Życia'
                        : openAccordionBucket === 'fun'
                        ? 'Zachcianki'
                        : openAccordionBucket === 'savings'
                        ? 'Oszczędności'
                        : 'Suma m-ca'}
                    </span>
                    <strong className="text-base font-black text-slate-900">
                      {(openAccordionBucket
                        ? monthSums.bucketTotals[openAccordionBucket]
                        : monthSums.grandTotal
                      ).toLocaleString('pl-PL')}{' '}
                      {currency}
                    </strong>
                    {openAccordionBucket && (
                      <span className="mt-0.5 inline-flex items-center gap-0.5 text-[10px] font-bold text-blue-600">
                        <RotateCcw className="h-2.5 w-2.5" /> Wróć
                      </span>
                    )}
                  </div>
                </div>

                {/* Akordeon Legendy (1:1 z cat-legend-list / bucket-header / bucket-details) */}
                <div className="mt-4 border-t border-dashed border-slate-200 pt-4 space-y-2">
                  {bucketConfig.map(b => {
                    const bTotal = monthSums.bucketTotals[b.id];
                    if (bTotal <= 0) return null;

                    const bPct = Math.round((bTotal / monthSums.grandTotal) * 100);
                    const isOpen = openAccordionBucket === b.id;
                    const subCats = Object.keys(monthSums.catTotals[b.id]).sort(
                      (x, y) => monthSums.catTotals[b.id][y] - monthSums.catTotals[b.id][x]
                    );

                    return (
                      <div key={b.id}>
                        <button
                          type="button"
                          onClick={() => toggleAccordion(b.id)}
                          className="flex w-full items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-3 text-xs font-extrabold text-slate-900 transition-all hover:border-slate-300 hover:bg-slate-100"
                        >
                          <span className="flex items-center gap-2 min-w-0">
                            <span
                              className="h-3 w-3 shrink-0 rounded-full"
                              style={{ backgroundColor: b.color }}
                            />
                            <span className="truncate">{b.name}</span>
                            <span className="text-[11px] font-semibold text-slate-500">({bPct}%)</span>
                          </span>

                          <span className="flex items-center gap-2 shrink-0">
                            <span>
                              {bTotal.toLocaleString('pl-PL')} {currency}
                            </span>
                            <ChevronDown
                              className={`h-4 w-4 text-slate-400 transition-transform duration-300 ${
                                isOpen ? 'rotate-180' : ''
                              }`}
                            />
                          </span>
                        </button>

                        {isOpen && (
                          <div className="mt-2 ml-3 pl-3 border-l-2 border-slate-200 grid grid-cols-2 sm:grid-cols-3 gap-1.5 pb-1">
                            {subCats.map(cName => {
                              const cVal = monthSums.catTotals[b.id][cName];
                              const isActive = filterCategory === cName;
                              return (
                                <button
                                  key={cName}
                                  type="button"
                                  onClick={() =>
                                    setFilterCategory(filterCategory === cName ? 'ALL' : cName)
                                  }
                                  className={`flex flex-col items-start justify-center rounded-lg border p-2 text-left transition-all ${
                                    isActive
                                      ? 'border-blue-300 bg-blue-50 text-blue-700'
                                      : 'border-transparent bg-slate-50 hover:border-slate-200 hover:bg-slate-100'
                                  }`}
                                  title={cName}
                                >
                                  <span
                                    className={`w-full truncate text-[10px] font-bold uppercase tracking-tight ${
                                      isActive ? 'text-blue-600' : 'text-slate-500'
                                    }`}
                                  >
                                    {cName}
                                  </span>
                                  <span className="mt-0.5 text-xs font-extrabold text-slate-900">
                                    {cVal.toLocaleString('pl-PL')} {currency}
                                  </span>
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}

                  {filterCategory !== 'ALL' && (
                    <button
                      type="button"
                      onClick={() => setFilterCategory('ALL')}
                      className="mt-2 w-full rounded-lg bg-blue-50 py-1.5 text-xs font-bold text-blue-700 hover:bg-blue-100"
                    >
                      Wyczyść filtr kategorii ({filterCategory})
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <p className="py-8 text-center text-xs font-medium text-slate-400">
                Brak danych do wykresu w wybranym okresie.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export type BucketType = 'needs' | 'fun' | 'savings';

export interface Category {
  id: string;
  name: string;
  bucket: BucketType;
  icon?: string;
  isDefault?: boolean;
}

export type SubscriptionCycle = 'monthly' | 'quarterly' | 'semi_annual' | 'annual';

export interface Subscription {
  id: string;
  name: string;
  amount: number;
  category: string;
  dayOfMonth: number;
  cycle: SubscriptionCycle;
  dueMonth?: number; // 1-12
  savedSoFar?: number;
  createdMonth?: string; // YYYY-MM
  lastPaidMonth?: string | null; // YYYY-MM
  reminderEnabled?: boolean;
}

export interface SavingsGoal {
  id: string;
  name: string;
  target: number;
  saved: number;
  color?: string;
  deadline?: string;
}

export interface HistoryEntry {
  id: string;
  exactDate: string; // YYYY-MM-DD
  month: string; // YYYY-MM
  category: string;
  name: string;
  amount: number;
  isSubscription?: boolean;
  splitGroupId?: string;
  addedBy?: string; // np. 'Marcin' | 'Ania' dla budżetu współdzielonego
}

export interface HouseholdConfig {
  enabled: boolean;
  myName: string;
  partnerName: string;
  partnerNetIncome: number;
  shareCode: string;
  activeAuthor: string;
}

export interface BudgetConfig {
  income: number;
  benefits800: number;
  benefitsActiveHome: number;
  benefitsActiveWork: number;
  otherIncome: number;
  rushEmergencyFund: boolean;
  currentSavings: number;
  emergencyFundMonths: number; // e.g. 3, 6, 9, 12
  customRatiosEnabled: boolean;
  customNeedsPct: number; // e.g. 50
  customSavingsPct: number; // e.g. 20
  customFunPct: number; // e.g. 30
  currency: string; // 'PLN', 'EUR', 'USD'
  household?: HouseholdConfig;
  extraDebtPayment?: number;
  isPremium?: boolean;
}

export interface BudgetDistribution {
  totalIncome: number;
  baseSalary: number;
  partnerSalary: number;
  benefitsTotal: number;
  needsTarget: number;
  needsPct: number;
  funTarget: number;
  funPct: number;
  savingsTarget: number;
  savingsPct: number;
  housingTarget: number;
  foodTarget: number;
  transportTarget: number;
  loansTarget: number;
  emergencyFundTarget: number;
}

export interface SinkingFundSummary {
  monthlyAllocation: number;
  monthsUntilDue: number;
  nextDueYear: number;
  nextDueMonth: number;
  totalNeeded: number;
  isDueThisMonth: boolean;
  standardMonthly: number;
}

export interface HealthAuditIssue {
  id: string;
  type: 'critical' | 'warning' | 'tip' | 'praise';
  title: string;
  message: string;
  actionRecommendation?: string;
}

export interface HealthAudit {
  score: number; // 0-100
  grade: 'A+' | 'A' | 'B' | 'C' | 'D';
  summary: string;
  issues: HealthAuditIssue[];
  metrics: {
    actualNeedsRatio: number;
    actualFunRatio: number;
    actualSavingsRatio: number;
    emergencyFundCoverMonths: number;
    subscriptionBurdenRatio: number;
  };
}

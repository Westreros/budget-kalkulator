import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  BudgetConfig,
  Category,
  Subscription,
  SavingsGoal,
  HistoryEntry
} from './types/budget';
import {
  loadStoredData,
  saveStoredData,
  APP_CONFIG,
  DEFAULT_CONFIG,
  DEMO_CONFIG,
  DEFAULT_CATEGORIES,
  DEFAULT_GOALS,
  DEMO_GOALS,
  DEFAULT_SUBSCRIPTIONS,
  DEMO_SUBSCRIPTIONS,
  DEFAULT_DEBTS,
  DEMO_DEBTS,
  getInitialEntries,
  getDemoEntries,
  parseLegacySettingsObject,
  mapSupabaseHistoryRowToEntry,
  buildLegacySettingsPayload
} from './utils/storage';
import {
  calculateBudgetDistribution,
  calculateRollover,
  calculateNoSpendStreak,
  calculateSavingsStreak,
  calculateSinkingFundAllocation,
  auditBudgetHealth,
  isSubDueInMonth
} from './utils/calculations';
import { checkGlobalSavingsJackpot } from './utils/coinAnimation';
import { DebtItem } from './utils/premiumLogic';
import { getSupabaseClient } from './utils/supabaseClient';
import { Header } from './components/Header';
import { PlanerTab } from './components/PlanerTab';
import { DziennikTab } from './components/DziennikTab';
import { OplatyTab } from './components/OplatyTab';
import { SkarbonkiTab } from './components/SkarbonkiTab';
import { AnalizaTab } from './components/AnalizaTab';
import { AudytTab } from './components/AudytTab';
import { CategoryManagerModal } from './components/CategoryManagerModal';
import { BackupModal } from './components/BackupModal';
import { AuthCloudModal } from './components/AuthCloudModal';
import { SmartImportModal } from './components/SmartImportModal';
import { PremiumPaywallModal } from './components/PremiumPaywallModal';
import {
  Calculator,
  Receipt,
  Repeat,
  PiggyBank,
  BarChart3,
  Sparkles,
  CloudOff,
  DownloadCloud,
  Lock,
  UserPlus,
  X
} from 'lucide-react';

export default function App() {
  const [data, setData] = useState(() => loadStoredData());
  const [activeTab, setActiveTab] = useState<string>(() => {
    try {
      const legacyTab = localStorage.getItem('walletwise_activeTab');
      if (legacyTab === 'calculatorTab') return 'calculator';
      if (legacyTab === 'historyTab') return 'history';
      if (legacyTab === 'subsTab') return 'subs';
      if (legacyTab === 'reportTab') return 'report';
    } catch {}
    return data.activeTab || 'calculator';
  });

  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [backupModalOpen, setBackupModalOpen] = useState(false);
  const [authCloudModalOpen, setAuthCloudModalOpen] = useState(false);
  const [smartImportModalOpen, setSmartImportModalOpen] = useState(false);
  const [guestLimitModalOpen, setGuestLimitModalOpen] = useState(false);
  const [paywallModalOpen, setPaywallModalOpen] = useState(false);
  const [paywallReason, setPaywallReason] = useState<string | null>(null);

  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userFullName, setUserFullName] = useState<string | null>(null);
  const [cloudSyncStatus, setCloudSyncStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [deferredPwaPrompt, setDeferredPwaPrompt] = useState<any>(null);

  const isLoggedIn = Boolean(userEmail);
  const saveTimeoutRef = useRef<any>(null);
  const initialCloudLoadDoneRef = useRef<boolean>(false);

  // Date helpers
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  const todayDay = now.getDate();

  // PWA Service Worker & beforeinstallprompt (1:1 z oryginalnym kodem)
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPwaPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js').catch(() => {});
      });
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallPwa = async () => {
    if (!deferredPwaPrompt) return;
    deferredPwaPrompt.prompt();
    const { outcome } = await deferredPwaPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPwaPrompt(null);
    }
  };

  // Powiadomienia przypominające o rachunkach płatnych dzisiaj i jutro (1:1 z checkSubReminders)
  const checkSubReminders = (subsList: Subscription[]) => {
    if (typeof window === 'undefined' || !('Notification' in window) || Notification.permission !== 'granted') {
      return;
    }
    const d = new Date();
    const today = d.getDate();
    const tomorrowDate = new Date(d);
    tomorrowDate.setDate(tomorrowDate.getDate() + 1);
    const tmrw = tomorrowDate.getDate();
    const curM = d.getMonth() + 1;
    const curPeriod = `${d.getFullYear()}-${String(curM).padStart(2, '0')}`;

    const dueToday = subsList.filter(
      s => isSubDueInMonth(s, curM) && s.dayOfMonth === today && s.lastPaidMonth !== curPeriod
    );
    const dueTomorrow = subsList.filter(
      s => isSubDueInMonth(s, curM) && s.dayOfMonth === tmrw && s.lastPaidMonth !== curPeriod
    );

    if (dueToday.length > 0) {
      new Notification('WiseWallet - Rachunki', {
        body: `Masz dzisiaj do opłacenia ${dueToday.length} rachunków (m.in. ${dueToday[0].name}). Otwórz aplikację, by zrealizować płatność.`,
        icon: 'https://cdn-icons-png.flaticon.com/512/3344/3344055.png'
      });
    } else if (dueTomorrow.length > 0) {
      new Notification('WiseWallet - Przypomnienie', {
        body: `Jutro mija termin płatności za: ${dueTomorrow[0].name}. Przygotuj środki.`,
        icon: 'https://cdn-icons-png.flaticon.com/512/3344/3344055.png'
      });
    }
  };

  // Load settings from `user_metadata.budget_settings` + `history_logs` table (1:1 z oryginalnym kodem)
  const loadCloudDataFromSession = async (session: any) => {
    const supabase = getSupabaseClient();
    if (!supabase || !session?.user) return;

    setUserEmail(session.user.email || null);
    setUserFullName(session.user.user_metadata?.full_name || null);

    const cloudSettings = session.user.user_metadata?.budget_settings;
    let parsedFromMetadata: Partial<typeof data> = {};
    if (cloudSettings) {
      parsedFromMetadata = parseLegacySettingsObject(cloudSettings, data);
    }

    // Load history_logs table from Supabase
    let cloudEntries: HistoryEntry[] | null = null;
    try {
      const { data: hlData, error: hlErr } = await supabase.from('history_logs').select('*');
      if (!hlErr && Array.isArray(hlData) && hlData.length > 0) {
        cloudEntries = hlData.map((row, idx) => mapSupabaseHistoryRowToEntry(row, idx));
      }
    } catch {}

    setData(prev => {
      const merged = {
        ...prev,
        ...parsedFromMetadata,
        entries: cloudEntries || parsedFromMetadata.entries || prev.entries
      };
      checkSubReminders(merged.subscriptions);
      return merged;
    });

    initialCloudLoadDoneRef.current = true;
  };

  // Check Supabase session on mount
  useEffect(() => {
    const supabase = getSupabaseClient();
    if (!supabase) return;

    supabase.auth.getSession().then(({ data: sessionData }) => {
      if (sessionData?.session) {
        loadCloudDataFromSession(sessionData.session);
      } else {
        checkSubReminders(data.subscriptions);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        loadCloudDataFromSession(session);
      } else {
        setUserEmail(null);
        setUserFullName(null);
        initialCloudLoadDoneRef.current = false;
      }
    });

    return () => {
      listener.subscription.unsubscribe();
    };
  }, []);

  // Save to LocalStorage & debounced save to Supabase `user_metadata.budget_settings` (1:1 z saveSettingsToCloud)
  useEffect(() => {
    saveStoredData({ ...data, activeTab });

    if (!isLoggedIn || !initialCloudLoadDoneRef.current) return;
    const supabase = getSupabaseClient();
    if (!supabase) return;

    setCloudSyncStatus('saving');
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);

    saveTimeoutRef.current = setTimeout(async () => {
      try {
        const settingsPayload = buildLegacySettingsPayload({ ...data, activeTab }, false);
        const { error } = await supabase.auth.updateUser({
          data: { budget_settings: settingsPayload }
        });
        if (!error) {
          setCloudSyncStatus('saved');
          setTimeout(() => setCloudSyncStatus('idle'), 3000);
        } else {
          setCloudSyncStatus('error');
        }
      } catch {
        setCloudSyncStatus('error');
      }
    }, 1000);
  }, [data, activeTab, isLoggedIn]);

  // Derived budget distribution
  const distribution = useMemo(() => {
    return calculateBudgetDistribution(data.config);
  }, [data.config]);

  // Rollover from previous month
  const rolloverAmount = useMemo(() => {
    return calculateRollover(data.entries, data.categories, data.config, currentYear, currentMonth);
  }, [data.entries, data.categories, data.config, currentYear, currentMonth]);

  // Streak
  const streakInfo = useMemo(() => {
    return calculateNoSpendStreak(data.entries, data.categories, currentYear, currentMonth, todayDay);
  }, [data.entries, data.categories, currentYear, currentMonth, todayDay]);

  const savingsMonthsStreak = useMemo(() => {
    return calculateSavingsStreak(data.entries, data.categories, data.config);
  }, [data.entries, data.categories, data.config]);

  // Leftover Fun money (1:1 z oryginalnym renderHistory: uwzględnia opłaty nieregularne i oczekujące subskrypcje Fun)
  const leftoverFunMoney = useMemo(() => {
    const totalFunAvailable = distribution.funTarget + rolloverAmount;
    const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
    const categoryBucketMap = new Map<string, Category['bucket']>();
    data.categories.forEach(c => categoryBucketMap.set(c.name, c.bucket));

    let spentFun = 0;
    data.entries
      .filter(e => e.month === curPeriod)
      .forEach(e => {
        if (categoryBucketMap.get(e.category) === 'fun') {
          const matchedIrregular = data.subscriptions.find(
            s => s.cycle && s.cycle !== 'monthly' && `${s.name} (Opłata stała)` === e.name
          );
          if (matchedIrregular) {
            spentFun += calculateSinkingFundAllocation(matchedIrregular, currentYear, currentMonth).monthlyAllocation;
          } else {
            spentFun += Number(e.amount);
          }
        }
      });

    data.subscriptions.forEach(sub => {
      if (sub.lastPaidMonth !== curPeriod && categoryBucketMap.get(sub.category) === 'fun') {
        spentFun += calculateSinkingFundAllocation(sub, currentYear, currentMonth).monthlyAllocation;
      }
    });

    return Math.max(0, totalFunAvailable - spentFun);
  }, [
    distribution.funTarget,
    rolloverAmount,
    data.entries,
    data.subscriptions,
    data.categories,
    currentYear,
    currentMonth
  ]);

  // Obsługa powrotu z płatności Stripe (?premium=success w adresie URL)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('premium') === 'success') {
      setData(prev => ({
        ...prev,
        config: { ...prev.config, isPremium: true }
      }));
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, []);

  const handleRequirePremium = (reason: string) => {
    setPaywallReason(reason);
    setPaywallModalOpen(true);
  };

  // Financial Health Audit
  const auditReport = useMemo(() => {
    return auditBudgetHealth(
      data.config,
      data.entries,
      data.subscriptions,
      data.categories,
      currentYear,
      currentMonth
    );
  }, [data.config, data.entries, data.subscriptions, data.categories, currentYear, currentMonth]);

  // Configuration change
  const handleConfigChange = (newConfig: BudgetConfig) => {
    setData(prev => ({ ...prev, config: newConfig }));
  };

  // Categories CRUD
  const handleAddCategory = (newCat: Omit<Category, 'id'>) => {
    const id = `cat-${Date.now()}`;
    setData(prev => ({ ...prev, categories: [...prev.categories, { ...newCat, id }] }));
  };

  const handleDeleteCategory = (id: string) => {
    setData(prev => ({ ...prev, categories: prev.categories.filter(c => c.id !== id) }));
  };

  // Goals CRUD
  const handleAddGoal = (newGoal: Omit<SavingsGoal, 'id'>) => {
    if (!isLoggedIn && APP_CONFIG.guestLimitsActive && data.goals.length >= APP_CONFIG.maxGuestGoals) {
      setGuestLimitModalOpen(true);
      return;
    }
    const id = String(Date.now());
    setData(prev => ({ ...prev, goals: [...prev.goals, { ...newGoal, id }] }));
  };

  const handleUpdateGoal = (id: string, updated: Partial<SavingsGoal>) => {
    setData(prev => ({
      ...prev,
      goals: prev.goals.map(g => (g.id === id ? { ...g, ...updated } : g))
    }));
  };

  const handleDeleteGoal = (id: string) => {
    setData(prev => ({ ...prev, goals: prev.goals.filter(g => g.id !== id) }));
  };

  // Debts CRUD
  const handleAddDebt = (newDebt: Omit<DebtItem, 'id'>) => {
    const id = `debt-${Date.now()}`;
    setData(prev => ({ ...prev, debts: [...(prev.debts || []), { ...newDebt, id }] }));
  };

  const handleDeleteDebt = (id: string) => {
    setData(prev => ({
      ...prev,
      debts: (prev.debts || []).filter(d => d.id !== id)
    }));
  };

  // Subscriptions CRUD
  const handleAddSubscription = (newSub: Omit<Subscription, 'id'>) => {
    if (!isLoggedIn && APP_CONFIG.guestLimitsActive && data.subscriptions.length >= APP_CONFIG.maxGuestSubs) {
      setGuestLimitModalOpen(true);
      return;
    }
    const id = String(Date.now());
    setData(prev => ({ ...prev, subscriptions: [...prev.subscriptions, { ...newSub, id }] }));
  };

  const handleUpdateSubscription = (id: string, updated: Partial<Subscription>) => {
    setData(prev => ({
      ...prev,
      subscriptions: prev.subscriptions.map(s => (s.id === id ? { ...s, ...updated } : s))
    }));
  };

  // Usuwanie subskrypcji z pytaniem o wykasowanie powiązanych rachunków z Dziennika (1:1 z deleteSubscription w oryginale)
  const handleDeleteSubscription = async (id: string) => {
    const sub = data.subscriptions.find(s => s.id === id);
    if (!sub) return;

    if (!confirm(`Na pewno usunąć stałą opłatę "${sub.name}"?`)) return;

    const targetName = `${sub.name} (Opłata stała)`;
    const relatedLogs = data.entries.filter(e => e.name === targetName);
    let removeRelated = false;

    if (relatedLogs.length > 0) {
      removeRelated = confirm(
        `Znaleziono opłacone rachunki powiązane z tą subskrypcją (${relatedLogs.length} wpisów). Czy chcesz wykasować je również z Dziennika, aby odzyskać środki w budżecie?`
      );
      if (removeRelated && isLoggedIn) {
        const supabase = getSupabaseClient();
        if (supabase) {
          for (const rel of relatedLogs) {
            await supabase.from('history_logs').delete().eq('id', rel.id);
          }
        }
      }
    }

    const idsToRemove = new Set(relatedLogs.map(l => l.id));
    setData(prev => ({
      ...prev,
      subscriptions: prev.subscriptions.filter(s => s.id !== id),
      entries: removeRelated ? prev.entries.filter(e => !idsToRemove.has(e.id)) : prev.entries
    }));
  };

  // Helper do zapisu rekordu w tabeli `history_logs` w Supabase (1:1 z oryginalnym kodem)
  const insertHistoryRecordsWithCloud = async (newEntries: Omit<HistoryEntry, 'id'>[]) => {
    const author = data.config.household?.activeAuthor || 'Marcin';
    const supabase = getSupabaseClient();

    if (isLoggedIn && supabase) {
      const dbPayloads = newEntries.map(e => {
        const parts = (e.exactDate || `${e.month}-01`).split('-');
        return {
          month: e.month,
          year: parts[0],
          month_num: parts[1],
          exact_date: e.exactDate,
          category: e.category,
          name: e.name,
          amount: e.amount
        };
      });

      const { data: inserted, error } = await supabase.from('history_logs').insert(dbPayloads).select();
      if (!error && Array.isArray(inserted) && inserted.length > 0) {
        const mapped = inserted.map((row, idx) => ({
          ...mapSupabaseHistoryRowToEntry(row, idx),
          addedBy: newEntries[idx]?.addedBy || author
        }));
        setData(prev => ({ ...prev, entries: [...mapped, ...prev.entries] }));
        return;
      }
    }

    const stamped = newEntries.map((e, idx) => ({
      ...e,
      addedBy: e.addedBy || author,
      id: String(Date.now() + idx)
    }));
    setData(prev => ({ ...prev, entries: [...stamped, ...prev.entries] }));
  };

  // Subscriptions pay / unpay (1:1 z paySubscription / unpaySubscription)
  const handlePaySubscription = async (sub: Subscription) => {
    const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
    const today = new Date().toISOString().split('T')[0];

    await insertHistoryRecordsWithCloud([
      {
        exactDate: today,
        month: curPeriod,
        category: sub.category,
        name: `${sub.name} (Opłata stała)`,
        amount: sub.amount,
        isSubscription: true,
        addedBy: data.config.household?.activeAuthor || 'Marcin'
      }
    ]);

    setData(prev => ({
      ...prev,
      subscriptions: prev.subscriptions.map(s =>
        s.id === sub.id ? { ...s, lastPaidMonth: curPeriod, savedSoFar: 0 } : s
      )
    }));
  };

  const handleUnpaySubscription = async (sub: Subscription) => {
    const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
    const expectedName = `${sub.name} (Opłata stała)`;
    const logEntry = data.entries.find(
      e => e.month === curPeriod && e.name === expectedName && Number(e.amount) === Number(sub.amount)
    );

    if (logEntry && isLoggedIn) {
      const supabase = getSupabaseClient();
      if (supabase) {
        await supabase.from('history_logs').delete().eq('id', logEntry.id);
      }
    }

    setData(prev => ({
      ...prev,
      subscriptions: prev.subscriptions.map(s =>
        s.id === sub.id ? { ...s, lastPaidMonth: null } : s
      ),
      entries: logEntry ? prev.entries.filter(e => e.id !== logEntry.id) : prev.entries
    }));
  };

  // Goals fund / withdraw (1:1 z autoLogGoalFund i checkGlobalSavingsJackpot)
  const handleFundGoal = async (goalId: string, amount: number) => {
    const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
    const today = new Date().toISOString().split('T')[0];
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) return;

    checkGlobalSavingsJackpot(amount, data.entries, data.categories, data.config);

    setData(prev => ({
      ...prev,
      goals: prev.goals.map(g => (g.id === goalId ? { ...g, saved: g.saved + amount } : g))
    }));

    await insertHistoryRecordsWithCloud([
      {
        exactDate: today,
        month: curPeriod,
        category: 'Oszczędności',
        name: `Wpłata na cel: ${goal.name}`,
        amount,
        addedBy: data.config.household?.activeAuthor || 'Marcin'
      }
    ]);
  };

  const handleWithdrawGoal = async (goalId: string, amount: number) => {
    const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
    const today = new Date().toISOString().split('T')[0];
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) return;

    setData(prev => ({
      ...prev,
      goals: prev.goals.map(g =>
        g.id === goalId ? { ...g, saved: Math.max(0, g.saved - amount) } : g
      )
    }));

    await insertHistoryRecordsWithCloud([
      {
        exactDate: today,
        month: curPeriod,
        category: 'Oszczędności',
        name: `Wypłata z celu: ${goal.name}`,
        amount: -amount,
        addedBy: data.config.household?.activeAuthor || 'Marcin'
      }
    ]);
  };

  const handleFundEmergency = async (amount: number) => {
    const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
    const today = new Date().toISOString().split('T')[0];

    checkGlobalSavingsJackpot(amount, data.entries, data.categories, data.config);

    setData(prev => ({
      ...prev,
      config: {
        ...prev.config,
        currentSavings: prev.config.currentSavings + amount
      }
    }));

    await insertHistoryRecordsWithCloud([
      {
        exactDate: today,
        month: curPeriod,
        category: 'Poduszka Bezpieczeństwa',
        name: 'Wpłata na cel: Poduszka Finansowa',
        amount,
        addedBy: data.config.household?.activeAuthor || 'Marcin'
      }
    ]);
  };

  const handleWithdrawEmergency = async (amount: number) => {
    const curPeriod = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
    const today = new Date().toISOString().split('T')[0];

    setData(prev => ({
      ...prev,
      config: {
        ...prev.config,
        currentSavings: Math.max(0, prev.config.currentSavings - amount)
      }
    }));

    await insertHistoryRecordsWithCloud([
      {
        exactDate: today,
        month: curPeriod,
        category: 'Poduszka Bezpieczeństwa',
        name: 'Wypłata z celu: Poduszka Finansowa',
        amount: -amount,
        addedBy: data.config.household?.activeAuthor || 'Marcin'
      }
    ]);
  };

  // Entries CRUD
  const handleAddEntries = async (newEntries: Omit<HistoryEntry, 'id'>[]) => {
    if (!isLoggedIn && APP_CONFIG.guestLimitsActive && data.entries.length >= APP_CONFIG.maxGuestExpenses) {
      setGuestLimitModalOpen(true);
      return;
    }

    const bucketMap = new Map<string, Category['bucket']>();
    data.categories.forEach(c => bucketMap.set(c.name, c.bucket));
    let totalAddedToSavings = 0;
    newEntries.forEach(item => {
      if (bucketMap.get(item.category) === 'savings' && item.amount > 0) {
        totalAddedToSavings += item.amount;
      }
    });
    if (totalAddedToSavings > 0) {
      checkGlobalSavingsJackpot(totalAddedToSavings, data.entries, data.categories, data.config);
    }

    await insertHistoryRecordsWithCloud(newEntries);
  };

  const handleUpdateEntry = async (id: string, updated: Partial<HistoryEntry>) => {
    if (isLoggedIn) {
      const supabase = getSupabaseClient();
      if (supabase) {
        const existing = data.entries.find(e => e.id === id);
        const merged = { ...existing, ...updated };
        const parts = (merged.exactDate || `${merged.month}-01`).split('-');
        await supabase
          .from('history_logs')
          .update({
            month: merged.month,
            year: parts[0],
            month_num: parts[1],
            exact_date: merged.exactDate,
            category: merged.category,
            name: merged.name,
            amount: merged.amount
          })
          .eq('id', id);
      }
    }

    setData(prev => ({
      ...prev,
      entries: prev.entries.map(e => (e.id === id ? { ...e, ...updated } : e))
    }));
  };

  // Usuwanie wpisu z automatycznym cofaniem salda Skarbonki / Poduszki Finansowej (1:1 z deleteHistoryEntry w oryginale)
  const handleDeleteEntry = async (id: string) => {
    const entry = data.entries.find(e => e.id === id);

    if (isLoggedIn) {
      const supabase = getSupabaseClient();
      if (supabase) {
        await supabase.from('history_logs').delete().eq('id', id);
      }
    }

    setData(prev => {
      let updatedConfig = prev.config;
      let updatedGoals = prev.goals;

      if (entry) {
        if (entry.name.startsWith('Wpłata na cel: ')) {
          const gName = entry.name.replace('Wpłata na cel: ', '').trim();
          const amt = Math.abs(Number(entry.amount));
          if (gName === 'Poduszka Finansowa') {
            updatedConfig = {
              ...prev.config,
              currentSavings: Math.max(0, (Number(prev.config.currentSavings) || 0) - amt)
            };
          } else {
            updatedGoals = prev.goals.map(g =>
              g.name === gName ? { ...g, saved: Math.max(0, g.saved - amt) } : g
            );
          }
        } else if (entry.name.startsWith('Wypłata z celu: ')) {
          const gName = entry.name.replace('Wypłata z celu: ', '').trim();
          const absAmount = Math.abs(Number(entry.amount));
          if (gName === 'Poduszka Finansowa') {
            updatedConfig = {
              ...prev.config,
              currentSavings: (Number(prev.config.currentSavings) || 0) + absAmount
            };
          } else {
            updatedGoals = prev.goals.map(g =>
              g.name === gName ? { ...g, saved: g.saved + absAmount } : g
            );
          }
        }
      }

      return {
        ...prev,
        config: updatedConfig,
        goals: updatedGoals,
        entries: prev.entries.filter(e => e.id !== id)
      };
    });
  };

  const handleResetDemoData = () => {
    if (data.config.income > 0 || data.entries.length > 0 || data.goals.length > 0) {
      // Wyczyść do czystego formularza z placeholderami
      setData(prev => ({
        config: { ...DEFAULT_CONFIG, isPremium: prev.config.isPremium },
        categories: DEFAULT_CATEGORIES,
        goals: DEFAULT_GOALS,
        subscriptions: DEFAULT_SUBSCRIPTIONS,
        entries: getInitialEntries(),
        debts: DEFAULT_DEBTS,
        activeTab: 'calculator'
      }));
    } else {
      // Wczytaj bogate dane demonstracyjne
      setData(prev => ({
        config: { ...DEMO_CONFIG, isPremium: prev.config.isPremium },
        categories: DEFAULT_CATEGORIES,
        goals: DEMO_GOALS,
        subscriptions: DEMO_SUBSCRIPTIONS,
        entries: getDemoEntries(),
        debts: DEMO_DEBTS,
        activeTab: 'calculator'
      }));
    }
  };

  const handleLogout = async () => {
    try {
      localStorage.removeItem('walletwise_settings');
    } catch {}
    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.auth.signOut();
    }
    setUserEmail(null);
    setUserFullName(null);
  };

  const allTabs = [
    { id: 'calculator', label: 'Planer 50/20/30', mobileLabel: 'Planer', icon: Calculator, proOnly: false },
    { id: 'history', label: 'Dziennik Wydatków', mobileLabel: 'Dziennik', icon: Receipt, proOnly: false },
    { id: 'subs', label: data.config.isPremium ? 'Opłaty & Sinking Funds' : 'Stałe Opłaty', mobileLabel: 'Opłaty', icon: Repeat, proOnly: false },
    { id: 'goals', label: 'Skarbonki & Bufor', mobileLabel: 'Skarbonki', icon: PiggyBank, proOnly: false },
    { id: 'report', label: 'Analiza Miesiąca', mobileLabel: 'Analiza', icon: BarChart3, proOnly: false },
    { id: 'audit', label: 'Audyt & Długi', mobileLabel: 'Audyt', icon: Sparkles, proOnly: true }
  ];

  const tabs = allTabs.filter(t => !t.proOnly || data.config.isPremium);

  return (
    <div className="min-h-screen bg-slate-50/80 text-slate-900 pb-28 lg:pb-12">
      <div className="mx-auto max-w-7xl px-3 py-4 sm:px-6 sm:py-5 lg:px-8">
        <Header
          config={data.config}
          onConfigChange={handleConfigChange}
          audit={auditReport}
          onOpenAudit={() => setActiveTab('audit')}
          onOpenBackupModal={() => setBackupModalOpen(true)}
          onOpenAuthCloudModal={() => setAuthCloudModalOpen(true)}
          onOpenPaywallModal={() => {
            setPaywallReason(null);
            setPaywallModalOpen(true);
          }}
          onResetDemoData={handleResetDemoData}
          userEmail={userEmail}
          userFullName={userFullName}
          cloudSyncStatus={cloudSyncStatus}
        />

        {/* Baner Trybu Gościa (1:1 z guestWarningBanner w oryginalnym kodzie) */}
        {!isLoggedIn && APP_CONFIG.guestBannerActive && (
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-blue-200 bg-blue-50/80 px-4 py-3 text-xs sm:text-sm text-blue-950 shadow-2xs">
            <div className="flex items-center gap-3">
              <CloudOff className="h-5 w-5 shrink-0 text-blue-600" />
              <span className="leading-relaxed">
                <strong>Świetnie planujesz swój budżet! 🚀</strong> Jesteś w Trybie Gościa – Twoje dane są zapisane lokalnie na tym urządzeniu.{' '}
                <button
                  type="button"
                  onClick={() => setAuthCloudModalOpen(true)}
                  className="font-extrabold text-blue-600 underline hover:text-blue-800"
                >
                  Zaloguj się lub utwórz darmowe konto
                </button>
                , by włączyć bezpieczny backup w chmurze Supabase i nigdy nie stracić historii.
              </span>
            </div>
          </div>
        )}

        {/* Baner Instalacji PWA (1:1 z pwaInstallBanner w oryginalnym kodzie) */}
        {deferredPwaPrompt && (
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-blue-200 bg-blue-50 px-4 py-3 shadow-2xs">
            <div className="flex items-center gap-3">
              <DownloadCloud className="h-5 w-5 text-blue-600" />
              <div>
                <strong className="block text-sm font-extrabold text-blue-950">Zainstaluj aplikację WiseWallet</strong>
                <span className="text-xs text-slate-600">Szybszy dostęp z ekranu głównego i powiadomienia offline</span>
              </div>
            </div>
            <button
              type="button"
              onClick={handleInstallPwa}
              className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
            >
              Zainstaluj
            </button>
          </div>
        )}

        {/* Desktop Navigation Tabs (hidden on mobile and tablet, visible on lg screens) */}
        <nav className="mb-6 hidden lg:flex overflow-x-auto border-b border-slate-200/90 pb-2 scrollbar-none gap-2">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 whitespace-nowrap rounded-xl px-4 py-2.5 text-xs sm:text-sm font-bold transition-all ${
                  isActive
                    ? 'bg-white text-blue-600 shadow-sm border border-blue-200/80 ring-2 ring-blue-500/10'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className={`h-4 w-4 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Tab Contents */}
        <main>
          {activeTab === 'calculator' && (
            <PlanerTab
              config={data.config}
              onConfigChange={handleConfigChange}
              distribution={distribution}
              rolloverAmount={rolloverAmount}
              onRequirePremium={handleRequirePremium}
            />
          )}

          {activeTab === 'history' && (
            <DziennikTab
              entries={data.entries}
              categories={data.categories}
              config={data.config}
              subscriptions={data.subscriptions}
              currentYear={currentYear}
              currentMonth={currentMonth}
              onAddEntries={handleAddEntries}
              onUpdateEntry={handleUpdateEntry}
              onDeleteEntry={handleDeleteEntry}
              onOpenCategoryManager={() => setCategoryModalOpen(true)}
              onOpenSmartImport={() => setSmartImportModalOpen(true)}
              streak={streakInfo.streak}
              streakQuality={streakInfo.streakQuality}
              leftoverFunMoney={leftoverFunMoney}
              totalFunMonthly={distribution.funTarget + rolloverAmount}
            />
          )}

          {activeTab === 'subs' && (
            <OplatyTab
              subscriptions={data.subscriptions}
              categories={data.categories}
              config={data.config}
              currentYear={currentYear}
              currentMonth={currentMonth}
              onAddSubscription={handleAddSubscription}
              onUpdateSubscription={handleUpdateSubscription}
              onDeleteSubscription={handleDeleteSubscription}
              onPaySubscription={handlePaySubscription}
              onUnpaySubscription={handleUnpaySubscription}
            />
          )}

          {activeTab === 'goals' && (
            <SkarbonkiTab
              goals={data.goals}
              config={data.config}
              distribution={distribution}
              onAddGoal={handleAddGoal}
              onUpdateGoal={handleUpdateGoal}
              onDeleteGoal={handleDeleteGoal}
              onFundGoal={handleFundGoal}
              onWithdrawGoal={handleWithdrawGoal}
              onFundEmergency={handleFundEmergency}
              onWithdrawEmergency={handleWithdrawEmergency}
              onRequirePremium={handleRequirePremium}
            />
          )}

          {activeTab === 'report' && (
            <AnalizaTab
              entries={data.entries}
              subscriptions={data.subscriptions}
              categories={data.categories}
              config={data.config}
              distribution={distribution}
              currentYear={currentYear}
              currentMonth={currentMonth}
              rolloverAmount={rolloverAmount}
              savingsMonthsStreak={savingsMonthsStreak}
            />
          )}

          {activeTab === 'audit' && data.config.isPremium && (
            <AudytTab
              audit={auditReport}
              config={data.config}
              onConfigChange={handleConfigChange}
              distribution={distribution}
              debts={data.debts || DEFAULT_DEBTS}
              onAddDebt={handleAddDebt}
              onDeleteDebt={handleDeleteDebt}
              streakDays={streakInfo.streak}
              savingsMonthsStreak={savingsMonthsStreak}
            />
          )}
        </main>
      </div>

      {/* Mobile & Tablet Fixed Bottom Navigation Bar (visible below 1024px) */}
      <nav
        aria-label="Nawigacja mobilna i tablet"
        className="fixed bottom-0 left-0 right-0 z-50 lg:hidden border-t border-slate-200/90 bg-white/95 backdrop-blur-md shadow-[0_-4px_25px_rgba(15,23,42,0.08)] pb-[calc(0.5rem+env(safe-area-inset-bottom,0px))] pt-1 px-1 sm:px-4"
      >
        <div className={`mx-auto max-w-2xl grid items-center ${tabs.length === 6 ? 'grid-cols-6' : 'grid-cols-5'}`}>
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setActiveTab(tab.id);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`flex flex-col items-center justify-center py-1.5 px-0.5 sm:py-2 sm:px-2 rounded-xl transition-all relative ${
                  isActive
                    ? 'text-blue-600 font-extrabold'
                    : 'text-slate-400 hover:text-slate-700'
                }`}
                aria-current={isActive ? 'page' : undefined}
                aria-label={tab.label}
              >
                {isActive && (
                  <span className="absolute top-0.5 sm:top-1 h-1 w-6 sm:w-8 rounded-full bg-blue-600 animate-in fade-in zoom-in duration-200" />
                )}
                <Icon className={`h-5 w-5 sm:h-6 sm:w-6 transition-transform ${isActive ? 'scale-110 stroke-[2.5px] text-blue-600' : 'text-slate-400 stroke-[2px]'}`} />
                <span className={`mt-1 text-[10px] sm:text-xs leading-tight truncate max-w-full tracking-tight ${isActive ? 'font-black text-blue-600' : 'font-semibold text-slate-500'}`}>
                  {tab.mobileLabel}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Modal Limitu Trybu Gościa (1:1 z guestLimitModal w oryginalnym kodzie) */}
      {guestLimitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-sm rounded-3xl bg-white p-6 text-center shadow-2xl">
            <button
              type="button"
              onClick={() => setGuestLimitModalOpen(false)}
              className="absolute right-4 top-4 rounded-full bg-slate-100 p-1.5 text-slate-500 hover:bg-slate-200"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-rose-50 text-rose-600">
              <Lock className="h-8 w-8" />
            </div>
            <h3 className="mb-2 text-lg font-extrabold text-slate-900">Limit Trybu Gościa</h3>
            <p className="mb-5 text-xs leading-relaxed text-slate-500">
              Świetnie Ci idzie! Wykorzystałeś jednak darmowy limit akcji w tym trybie. Załóż konto, aby zdjąć blokady i zyskać nielimitowany dostęp.
            </p>
            <button
              type="button"
              onClick={() => {
                setGuestLimitModalOpen(false);
                setAuthCloudModalOpen(true);
              }}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 py-3 text-xs font-extrabold text-white shadow-md hover:bg-blue-700"
            >
              <UserPlus className="h-4 w-4" /> Załóż darmowe konto
            </button>
          </div>
        </div>
      )}

      {/* Modals */}
      <CategoryManagerModal
        isOpen={categoryModalOpen}
        onClose={() => setCategoryModalOpen(false)}
        categories={data.categories}
        onAddCategory={handleAddCategory}
        onDeleteCategory={handleDeleteCategory}
      />

      <BackupModal
        isOpen={backupModalOpen}
        onClose={() => setBackupModalOpen(false)}
        currentState={{ ...data, activeTab }}
        onRestoreState={restored => {
          setData(restored);
          if (restored.activeTab) setActiveTab(restored.activeTab);
        }}
        onResetDefault={handleResetDemoData}
      />

      <AuthCloudModal
        isOpen={authCloudModalOpen}
        onClose={() => setAuthCloudModalOpen(false)}
        config={data.config}
        onConfigChange={handleConfigChange}
        userEmail={userEmail}
        onAuthSuccess={email => {
          setUserEmail(email);
          setAuthCloudModalOpen(false);
        }}
        onLogout={handleLogout}
      />

      <SmartImportModal
        isOpen={smartImportModalOpen}
        onClose={() => setSmartImportModalOpen(false)}
        categories={data.categories}
        currency={data.config.currency}
        activeAuthor={data.config.household?.activeAuthor || 'Marcin'}
        onAddEntries={handleAddEntries}
      />

      <PremiumPaywallModal
        isOpen={paywallModalOpen}
        onClose={() => setPaywallModalOpen(false)}
        featureReason={paywallReason}
        isPremium={Boolean(data.config.isPremium)}
        onTogglePremium={activate => {
          handleConfigChange({
            ...data.config,
            isPremium: activate,
            customRatiosEnabled: activate ? data.config.customRatiosEnabled : false
          });
          if (!activate && activeTab === 'audit') {
            setActiveTab('calculator');
          }
        }}
        streakDays={streakInfo.streak}
        savingsMonthsStreak={savingsMonthsStreak}
        currency={data.config.currency}
        userEmail={userEmail}
      />
    </div>
  );
}
